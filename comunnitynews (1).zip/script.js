/* ---- parte: login ---- */
(function(){'use strict';if(document.documentElement.dataset.pg!=='login')return;

'use strict';

/* =====================================================
   HELPERS
   ===================================================== */
function notif(txt, tipo){
    tipo = tipo || 'info';
    const el = document.getElementById('notificacao');
    el.textContent = txt;
    el.classList.remove('erro','sucesso');
    if (tipo === 'erro') el.classList.add('erro');
    else if (tipo === 'sucesso') el.classList.add('sucesso');
    el.classList.add('ativa');
    clearTimeout(el._t);
    el._t = setTimeout(() => el.classList.remove('ativa'), 3500);
}
function statusTxt(txt){
    const el = document.getElementById('status-txt');
    if (el) el.textContent = txt;
}

function injetarEfeitosBrilho(){
    document.querySelectorAll('.cartao-animado').forEach(card => {
        if (!card.querySelector('.efeito-brilho')) {
            const brilho = document.createElement('span');
            brilho.className = 'efeito-brilho';
            brilho.setAttribute('aria-hidden', 'true');
            card.appendChild(brilho);
        }
    });
}

/* =====================================================
   TELA DE CARREGAMENTO
   ===================================================== */
(function iniciarCarregamento(){
    const frases = [
        'Carregando...',
        'Preparando tudo com carinho...',
        'Conectando ao servidor Community News...',
        'Verificando sessão do usuário...',
        'Ajustando cores e detalhes...',
        'Carregando avatares e emojis...',
        'Sincronizando dados...',
        'Quase pronto...',
        'Bem-vindo ao Community News! 🔐'
    ];
    const tela = document.getElementById('tela-carregamento');
    const barra = document.getElementById('preenchimento');
    const txt = document.getElementById('texto-carregando');
    if (!tela || !barra || !txt) return;

    let p = 0, idx = 0, ativo = true;
    let lastFrame = performance.now();
    const PASSO_BASE = 12;
    const DURACAO_MIN = 1500;
    const inicio = performance.now();

    function frame(now){
        if (!ativo) return;
        const dt = Math.min((now - lastFrame) / 1000, 0.1);
        lastFrame = now;
        const acel = p < 20 ? 0.6 : p < 70 ? 1 : p < 92 ? 0.85 : 0.5;
        p = Math.min(p + PASSO_BASE * dt * acel, 100);
        barra.style.width = p + '%';

        const novoIdx = Math.min(Math.floor(p / 12), frases.length - 1);
        if (novoIdx !== idx) {
            idx = novoIdx;
            txt.style.opacity = '0';
            setTimeout(() => { txt.textContent = frases[idx]; txt.style.opacity = '1'; }, 120);
        }
        if (p >= 100) {
            ativo = false;
            const esperar = Math.max(0, DURACAO_MIN - (now - inicio));
            setTimeout(() => {
                tela.classList.add('escondido');
                setTimeout(() => { tela.style.display = 'none'; }, 600);
            }, esperar + 400);
            return;
        }
        requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
})();

/* =====================================================
   MODAIS
   ===================================================== */
function abrirModal(id){
    const m = document.getElementById(id);
    if (!m) return;
    m.classList.add('ativo');
    document.body.style.overflow = 'hidden';
    setTimeout(injetarEfeitosBrilho, 50);
}
function fecharModal(id){
    const m = document.getElementById(id);
    if (!m) return;
    m.classList.remove('ativo');
    document.body.style.overflow = '';
}
function fecharTodosModais(){
    document.querySelectorAll('.modal').forEach(m => m.classList.remove('ativo'));
    document.body.style.overflow = '';
}

document.querySelectorAll('[data-fechar]').forEach(b => {
    b.addEventListener('click', () => {
        const m = b.closest('.modal');
        if (m) fecharModal(m.id);
    }, { passive:true });
});

document.querySelectorAll('.modal').forEach(m => {
    m.addEventListener('click', (e) => { if (e.target === m) fecharModal(m.id); }, { passive:true });
});

document.addEventListener('keydown', (e) => { if (e.key === 'Escape') fecharTodosModais(); });

/* =====================================================
   BOTÕES FLUTUANTES
   ===================================================== */
document.getElementById('btn-feedback').addEventListener('click', () => { abrirModal('modal-feedback'); }, { passive:true });
document.getElementById('btn-info').addEventListener('click', () => {
    abrirModal('modal-info');
}, { passive:true });
document.getElementById('info-link-feedback').addEventListener('click', (e) => {
    e.preventDefault();
    fecharModal('modal-info');
    setTimeout(() => abrirModal('modal-feedback'), 200);
}, { passive:true });

/* =====================================================
   FEEDBACK
   ===================================================== */
let feedbackTipoSelecionado = 'sugestao';
let feedbackNotaSelecionada = 0;

document.querySelectorAll('.feedback-tipo').forEach(b => {
    b.addEventListener('click', () => {
        document.querySelectorAll('.feedback-tipo').forEach(x => x.classList.remove('ativo'));
        b.classList.add('ativo');
        feedbackTipoSelecionado = b.dataset.tipo;
    }, { passive:true });
});

const estrelas = document.querySelectorAll('#feedback-estrelas button');
estrelas.forEach((b) => {
    const n = parseInt(b.dataset.nota, 10);
    b.addEventListener('mouseenter', () => pintarEstrelas(n), { passive:true });
    b.addEventListener('click', () => { feedbackNotaSelecionada = n; pintarEstrelas(n); }, { passive:true });
});
document.getElementById('feedback-estrelas').addEventListener('mouseleave', () => { pintarEstrelas(feedbackNotaSelecionada); }, { passive:true });

function pintarEstrelas(ate){ estrelas.forEach((b, i) => b.classList.toggle('on', i < ate)); }

document.getElementById('feedback-enviar').addEventListener('click', () => {
    const msg = document.getElementById('feedback-msg').value.trim();
    const email = document.getElementById('feedback-email').value.trim();
    if (!msg && !feedbackNotaSelecionada) { notif('⚠️ Escreva uma mensagem ou dê uma nota', 'erro'); return; }

    const registro = {
        tipo: feedbackTipoSelecionado,
        nota: feedbackNotaSelecionada,
        mensagem: msg.slice(0, 500),
        email: email || null,
        quando: new Date().toISOString()
    };

    try {
        const lista = JSON.parse(localStorage.getItem('feedbackCommunityNews') || '[]');
        lista.push(registro);
        if (lista.length > 100) lista.shift();
        localStorage.setItem('feedbackCommunityNews', JSON.stringify(lista));
    } catch(e){}

    notif('✅ Valeu pelo feedback! 💙', 'sucesso');
    document.getElementById('feedback-msg').value = '';
    document.getElementById('feedback-email').value = '';
    feedbackNotaSelecionada = 0;
    pintarEstrelas(0);
    document.querySelectorAll('.feedback-tipo').forEach((x, i) => x.classList.toggle('ativo', i === 0));
    feedbackTipoSelecionado = 'sugestao';
    setTimeout(() => fecharModal('modal-feedback'), 400);
}, { passive:true });

/* =====================================================
   ABAS
   ===================================================== */
function trocarAba(nome){
    document.querySelectorAll('.aba').forEach(x => {
        const on = x.dataset.aba === nome;
        x.classList.toggle('ativa', on);
        x.setAttribute('aria-selected', String(on));
    });
    document.querySelectorAll('.conteudo').forEach(x => x.classList.remove('ativa'));
    const alvo = document.getElementById('aba-' + nome);
    if (alvo) alvo.classList.add('ativa');
}
document.querySelectorAll('.aba').forEach(a => { a.addEventListener('click', () => trocarAba(a.dataset.aba), { passive:true }); });
document.querySelectorAll('[data-aba-dest]').forEach(el => {
    el.addEventListener('click', (e) => { e.preventDefault(); trocarAba(el.dataset.abaDest); }, { passive:true });
});

/* =====================================================
   MOSTRAR SENHA
   ===================================================== */
document.querySelectorAll('.mostrar-senha').forEach(b => {
    b.addEventListener('click', () => {
        const inp = document.getElementById(b.dataset.alvo);
        if (!inp) return;
        const ver = inp.type === 'text';
        inp.type = ver ? 'password' : 'text';
        b.querySelector('i').className = ver ? 'fas fa-eye' : 'fas fa-eye-slash';
    }, { passive:true });
});

/* =====================================================
   VALIDAÇÃO
   ===================================================== */
function emailValido(e){ return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(String(e).trim()); }
function marcarCampo(wrapId, erroId, ok){
    const w = document.getElementById(wrapId);
    const e = document.getElementById(erroId);
    if (!w || !e) return;
    w.classList.toggle('valido', ok === true);
    w.classList.toggle('invalido', ok === false);
    e.classList.toggle('ativo', ok === false);
}

/* =====================================================
   FORÇA DA SENHA
   ===================================================== */
function avaliarSenha(s){
    const req = { len: s.length >= 6, letra: /[a-zA-Z]/.test(s), num: /\d/.test(s), simb: /[^a-zA-Z0-9]/.test(s) };
    let forca = 0;
    if (s.length >= 6) forca++;
    if (req.letra && req.num) forca++;
    if (req.letra && req.num && req.simb && s.length >= 8) forca++;
    return { req, forca };
}
function atualizarForcaSenha(){
    const s = document.getElementById('cad-senha').value;
    const { req, forca } = avaliarSenha(s);
    const segs = document.querySelectorAll('#forca-senha .forca-seg');
    const txt = document.getElementById('forca-texto');
    segs.forEach((el, i) => {
        el.classList.remove('fraca','media','forte');
        if (i < forca) {
            if (forca === 1) el.classList.add('fraca');
            else if (forca === 2) el.classList.add('media');
            else el.classList.add('forte');
        }
    });
    txt.classList.remove('fraca','media','forte');
    if (!s) txt.textContent = 'Digite uma senha';
    else if (forca === 1) { txt.textContent = 'Fraca'; txt.classList.add('fraca'); }
    else if (forca === 2) { txt.textContent = 'Média'; txt.classList.add('media'); }
    else { txt.textContent = 'Forte'; txt.classList.add('forte'); }
    document.getElementById('req-len').classList.toggle('ok', req.len);
    document.getElementById('req-letra').classList.toggle('ok', req.letra);
    document.getElementById('req-num').classList.toggle('ok', req.num);
    document.getElementById('req-simb').classList.toggle('ok', req.simb);
}

document.getElementById('cad-senha').addEventListener('input', e => {
    document.getElementById('campo-confirmar').style.display = e.target.value.length > 0 ? 'block' : 'none';
    atualizarForcaSenha();
    marcarCampo('wrap-cad-senha','erro-cad-senha', null);
}, { passive:true });

/* =====================================================
   CAPTCHA
   ===================================================== */
let captchaVerificado = false;
const captchaBox = document.getElementById('captcha-box');
function verificarCaptcha(){
    if (captchaVerificado) return;
    const check = document.getElementById('captcha-check');
    const texto = document.getElementById('captcha-texto');
    texto.textContent = 'Verificando...';
    setTimeout(() => {
        captchaVerificado = true;
        captchaBox.classList.add('verificado');
        check.innerHTML = '<i class="fas fa-check"></i>';
        texto.textContent = 'Verificado ✓';
    }, 700);
}
captchaBox.addEventListener('click', verificarCaptcha, { passive:true });
captchaBox.addEventListener('keydown', (e) => { if (e.key === ' ' || e.key === 'Enter') { e.preventDefault(); verificarCaptcha(); } });

/* =====================================================
   LOGIN COM GOOGLE — MODO LOCAL
   ===================================================== */
function loginGoogle(){
    const nome = prompt('Digite seu nome de usuário:') || 'Usuário';
    if (!nome.trim()) return;
    localStorage.setItem('user', JSON.stringify({
        nome: nome.trim(),
        uid: 'local_' + Date.now(),
        criadoEm: Date.now()
    }));
    notif('✅ Bem-vindo, ' + nome.trim() + '!', 'sucesso');
    statusTxt('Logado: ' + nome.trim());
    setTimeout(() => { window.location.href = 'index2.html'; }, 900);
}
document.getElementById('btn-google-login').addEventListener('click', loginGoogle);
document.getElementById('btn-google-cadastro').addEventListener('click', loginGoogle);

/* =====================================================
   LOGIN COM E-MAIL
   ===================================================== */
document.getElementById('form-login').addEventListener('submit', e => {
    e.preventDefault();
    const email = document.getElementById('login-email').value.trim();
    const senha = document.getElementById('login-senha').value;

    let ok = true;
    if (!emailValido(email)) { marcarCampo('wrap-login-email','erro-login-email', false); ok = false; }
    else marcarCampo('wrap-login-email','erro-login-email', true);
    if (!senha) { marcarCampo('wrap-login-senha','erro-login-senha', false); ok = false; }
    else marcarCampo('wrap-login-senha','erro-login-senha', true);
    if (!ok) { notif('⚠️ Preencha os campos corretamente', 'erro'); return; }

    const btn = document.getElementById('btn-login');
    btn.disabled = true;
    btn.classList.add('carregando');
    statusTxt('Entrando...');

    setTimeout(() => {
        const usuarios = JSON.parse(localStorage.getItem('usuariosLocais') || '[]');
        const user = usuarios.find(u => u.email === email && u.senha === senha);
        btn.disabled = false;
        btn.classList.remove('carregando');

        if (user) {
            localStorage.setItem('user', JSON.stringify({
                nome: user.apelido,
                email: email,
                uid: 'local_' + Date.now()
            }));
            notif('✅ Bem-vindo, ' + user.apelido, 'sucesso');
            statusTxt('Logado: ' + user.apelido);
            setTimeout(() => { window.location.href = 'index2.html'; }, 800);
        } else {
            notif('❌ E-mail ou senha incorretos', 'erro');
            statusTxt('Tente novamente');
        }
    }, 800);
});

/* =====================================================
   CADASTRO
   ===================================================== */
document.getElementById('form-cadastro').addEventListener('submit', e => {
    e.preventDefault();
    const apelido = document.getElementById('cad-apelido').value.trim();
    const email = document.getElementById('cad-email').value.trim();
    const senha = document.getElementById('cad-senha').value;
    const senha2 = document.getElementById('cad-senha2').value;
    const aceitou = document.getElementById('aceito-termos').checked;

    let ok = true;
    if (apelido.length < 3) { marcarCampo('wrap-cad-apelido','erro-cad-apelido', false); ok = false; }
    else marcarCampo('wrap-cad-apelido','erro-cad-apelido', true);
    if (!emailValido(email)) { marcarCampo('wrap-cad-email','erro-cad-email', false); ok = false; }
    else marcarCampo('wrap-cad-email','erro-cad-email', true);
    if (senha.length < 6) { marcarCampo('wrap-cad-senha','erro-cad-senha', false); ok = false; }
    else marcarCampo('wrap-cad-senha','erro-cad-senha', true);
    if (senha && senha2 && senha !== senha2) { marcarCampo('wrap-cad-senha2','erro-cad-senha2', false); ok = false; }
    else if (senha && senha2) { marcarCampo('wrap-cad-senha2','erro-cad-senha2', true); }

    if (!ok) { notif('⚠️ Corrija os campos em vermelho', 'erro'); return; }
    if (!aceitou) { notif('⚠️ Aceite os Termos para continuar', 'erro'); return; }
    if (!captchaVerificado) { notif('⚠️ Confirme que não é um robô', 'erro'); return; }

    const btn = document.getElementById('btn-cadastro');
    btn.disabled = true;
    btn.classList.add('carregando');
    statusTxt('Criando conta...');

    setTimeout(() => {
        const usuarios = JSON.parse(localStorage.getItem('usuariosLocais') || '[]');
        btn.disabled = false;
        btn.classList.remove('carregando');

        if (usuarios.some(u => u.email === email)) {
            notif('❌ Esse e-mail já está em uso', 'erro');
            statusTxt('Tente novamente');
            return;
        }

        usuarios.push({ apelido, email, senha, criadoEm: Date.now() });
        localStorage.setItem('usuariosLocais', JSON.stringify(usuarios));
        notif('✅ Conta criada! Faça login.', 'sucesso');
        statusTxt('Conta criada');
        setTimeout(() => {
            trocarAba('login');
            document.getElementById('login-email').value = email;
            document.getElementById('login-senha').focus();
        }, 800);
    }, 900);
});

/* =====================================================
   RECUPERAR SENHA
   ===================================================== */
document.getElementById('form-recuperar').addEventListener('submit', e => {
    e.preventDefault();
    const email = document.getElementById('rec-email').value.trim();
    if (!emailValido(email)) { marcarCampo('wrap-rec-email','erro-rec-email', false); notif('⚠️ E-mail inválido', 'erro'); return; }
    marcarCampo('wrap-rec-email','erro-rec-email', true);

    const btn = document.getElementById('btn-recuperar');
    btn.disabled = true;
    btn.classList.add('carregando');

    setTimeout(() => {
        btn.disabled = false;
        btn.classList.remove('carregando');
        const usuarios = JSON.parse(localStorage.getItem('usuariosLocais') || '[]');
        if (usuarios.some(u => u.email === email)) {
            notif('✅ Se existir uma conta, enviaremos o link', 'sucesso');
            setTimeout(() => trocarAba('login'), 1500);
        } else {
            notif('✅ Se existir uma conta, enviaremos o link', 'sucesso');
            setTimeout(() => trocarAba('login'), 1500);
        }
    }, 1000);
});

/* =====================================================
   VALIDAÇÃO EM TEMPO REAL
   ===================================================== */
document.getElementById('login-email').addEventListener('blur', e => { const v = e.target.value.trim(); if (v) marcarCampo('wrap-login-email','erro-login-email', emailValido(v)); }, { passive:true });
document.getElementById('cad-email').addEventListener('blur', e => { const v = e.target.value.trim(); if (v) marcarCampo('wrap-cad-email','erro-cad-email', emailValido(v)); }, { passive:true });
document.getElementById('cad-apelido').addEventListener('input', e => { const v = e.target.value.trim(); if (v) marcarCampo('wrap-cad-apelido','erro-cad-apelido', v.length >= 3); }, { passive:true });
document.getElementById('cad-senha2').addEventListener('input', e => { const s = document.getElementById('cad-senha').value; const v = e.target.value; if (v) marcarCampo('wrap-cad-senha2','erro-cad-senha2', v === s); }, { passive:true });
document.getElementById('rec-email').addEventListener('blur', e => { const v = e.target.value.trim(); if (v) marcarCampo('wrap-rec-email','erro-rec-email', emailValido(v)); }, { passive:true });

/* =====================================================
   ATALHO Ctrl/Cmd + Enter
   ===================================================== */
document.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
        const ativo = document.querySelector('.conteudo.ativa form');
        if (ativo) ativo.requestSubmit();
    }
});

/* =====================================================
   INJETA EFEITOS AO CARREGAR
   ===================================================== */
document.addEventListener('DOMContentLoaded', injetarEfeitosBrilho);
window.addEventListener('load', injetarEfeitosBrilho);

try{window.notif=notif}catch(e){}
})();
/* ---- parte: app ---- */
(function(){'use strict';if(document.documentElement.dataset.pg!=='app')return;

'use strict';
(function () {

const $ = (id) => document.getElementById(id);
const $$ = (sel, ctx = document) => Array.from(ctx.querySelectorAll(sel));

const EL = { body: document.body, nav: null, navBola: null, telaCarr: null, barraCarr: null, textoCarr: null, snackbar: null, toast: null, sidebar: null, a11yStatus: null };

let _idCounter = 0;
function gerarId() { return 'id_' + Date.now().toString(36) + '_' + (++_idCounter).toString(36) + Math.random().toString(36).slice(2, 5); }
const _escapeDiv = document.createElement('div');
function escapeHtml(t) { _escapeDiv.textContent = String(t); return _escapeDiv.innerHTML; }
function formatarTamanho(b) { if (b < 1024) return b + ' B'; if (b < 1048576) return (b/1024).toFixed(1)+' KB'; return (b/1048576).toFixed(1)+' MB'; }
function base64(blob) { return new Promise(res => { const r = new FileReader(); r.onload = e => res(e.target.result); r.readAsDataURL(blob); }); }

function anunciar(txt) {
    if (!EL.a11yStatus) EL.a11yStatus = $('a11y-status');
    if (!EL.a11yStatus) return;
    EL.a11yStatus.textContent = '';
    setTimeout(() => { EL.a11yStatus.textContent = txt; }, 60);
}

function injetarEfeitosBrilho() {
    $$('.cartao-animado').forEach(card => {
        if (!card.querySelector('.efeito-brilho')) {
            const brilho = document.createElement('span');
            brilho.className = 'efeito-brilho';
            brilho.setAttribute('aria-hidden', 'true');
            card.appendChild(brilho);
        }
    });
}

const STORAGE = 'community_app_v22';
const STORAGE_TEMA = 'community_tema_v5';
const STORAGE_SEG = 'community_seg_v1';
const STORAGE_ONB = 'community_onb_done_v1';
const STORAGE_VIP = 'community_vip_v1';
const STORAGE_BACKUP = 'community_perfil_backup_v1';
const STORAGE_IDIOMA = 'community_idioma_v1';
const TEMAS_LIBERADOS = ['escuro','padrao','claro'].concat((Date.now() >= new Date('2026-10-16T00:00:00').getTime() && Date.now() < new Date('2026-11-01T00:00:00').getTime()) ? ['halloween'] : []);
const IDIOMAS_LIBERADOS = ['pt','en','es'];

const TRADUCOES = {
    pt: {
        'a11y.skip': 'Pular para o conteúdo principal',
        'loading.txt': 'Carregando...', 'loading.f1': 'Carregando...', 'loading.f2': 'Preparando interface...',
        'loading.f3': 'Sincronizando dados...', 'loading.f4': 'Quase pronto...', 'loading.f5': 'Finalizando...',
        'onb.bem_vindo': 'Bem-vindo ao', 'onb.bem_vindo_html': 'Bem-vindo ao',
        'onb.subtitulo': 'Vamos criar seu perfil em 3 passos rápidos',
        'onb.passo': 'Passo', 'onb.de': 'de', 'onb.apelido': 'Apelido', 'onb.avatar': 'Avatar', 'onb.personalizar': 'Personalizar',
        'onb.seu_apelido': 'Seu apelido', 'onb.sem_bio': 'Sem bio ainda',
        'onb.p1.titulo': 'Como podemos te chamar?',
        'onb.p1.desc': 'Escolha um apelido único — é assim que os outros vão te ver no app. Você pode mudar depois nas configurações.',
        'onb.p1.label': 'Apelido', 'onb.p1.ph': 'Ex: Player_Pro, Lunar, GhostZ...',
        'onb.p2.titulo': 'Escolha seu avatar',
        'onb.p2.desc': 'Role para ver todos os ícones ou envie uma foto sua da galeria.',
        'onb.p2.upload_tit': 'Escolher uma foto', 'onb.p2.upload_sub': 'Da galeria, Google Fotos ou câmera', 'onb.p2.hint': 'Role para ver mais ícones',
        'onb.p3.titulo': 'Deixe do seu jeito',
        'onb.p3.desc_a': 'Personalize com sua cor, bio e interesses.', 'onb.p3.desc_b': 'Todos os campos são opcionais', 'onb.p3.desc_c': '— você pode mudar depois!',
        'onb.p3.cor': 'Cor do perfil', 'onb.p3.bio': 'Bio', 'onb.p3.opc': '(opcional)', 'onb.p3.bio_ph': 'Ex: Gamer, streamer, amo FPS...',
        'onb.p3.interesses': 'Interesses', 'onb.p3.frase': 'Frase favorita', 'onb.p3.frase_ph': 'Ex: No pain, no gain',
        'onb.p3.pronto': 'Tudo pronto? Clique abaixo para', 'onb.p3.criar_avatar': 'criar seu avatar', 'onb.p3.e_comecar': 'e começar!',
        'onb.p3.btn_criar': 'Criar meu Avatar', 'onb.voltar': 'Voltar', 'onb.continuar': 'Continuar',
        'lock.sub': 'Digite sua senha para continuar', 'lock.esqueci': 'Esqueci a senha',
        'sb.bem_vindo': 'Bem-vindo! 👋', 'sb.navegacao': 'Navegação', 'sb.aparencia': 'Aparência', 'sb.meus_grupos': 'Meus grupos',
        'sb.seguranca': 'Segurança', 'sb.suporte': 'Suporte', 'sb.copyright': 'Community News © 2026',
        'nav.inicio': 'Início', 'nav.jogos': 'Jogos & Lojas', 'nav.eventos': 'Eventos', 'nav.chat': 'Chat', 'nav.perfil': 'Meu Perfil',
        'nav.config': 'Configurações', 'nav.vip': 'Seja VIP', 'nav.seguranca': 'Segurança', 'nav.feedback': 'Enviar Feedback',
        'nav.sobre': 'Sobre o App', 'nav.sair': 'Sair',
        'tema.escuro': 'Escuro', 'tema.padrao': 'Padrão', 'tema.claro': 'Claro', 'tema.halloween': 'Halloween',
        'home.bem_vindo': 'Bem-vindo de volta! 👋', 'home.subtitulo': 'Notícias • Jogos • Chat em Tempo Real',
        'home.halloween_titulo': '🎃 Contagem Regressiva — Halloween 2026', 'home.dias': 'Dias', 'home.horas': 'Horas', 'home.min': 'Min', 'home.seg': 'Seg',
        'home.halloween_data': '16 de Outubro de 2026 — Salve a data!',
        'card.chat_titulo': '💬 Chat Real', 'card.chat_desc': 'Mensagens, áudio, imagens e chamadas em tempo real!',
        'card.perfil_titulo': '👤 Meu Perfil', 'card.perfil_desc': 'Cor, capa e avatar totalmente personalizáveis',
        'card.vip_titulo': '⭐ Seja VIP', 'card.vip_desc': 'Desbloqueie tudo por R$ 4, R$ 8 ou R$ 12',
        'card.abrir': 'Abrir →', 'card.ver': 'Ver planos →',
        'aval.titulo': 'Como foi a sua experiência?', 'aval.dica': 'Passe o mouse nas estrelas e veja o rostinho reagir.',
        'aval.toca': 'Toque numa estrela', 'aval.conta': 'CONTA PRA GENTE (SE QUISER)', 'aval.ph': 'O que fez a diferença?',
        'aval.enviar': 'Enviar avaliação', 'aval.obrigado': 'Obrigado! Sua avaliação foi salva neste aparelho.',
        'jogos.titulo': '🎮 Jogos & Lojas', 'jogos.subtitulo': 'Histórias completas + links oficiais',
        'jogos.destaques': '✨ Destaques da semana', 'jogos.dica': 'Arraste o carrossel ou use as setas.',
        'jogos.site': 'Visitar site oficial', 'jogos.completos': 'Jogos completos', 'jogos.lojas': 'Lojas oficiais',
        'eventos.titulo': '🔥 Eventos', 'eventos.fortnite_titulo': '🎮 Fortnite x Poppy Playtime',
        'eventos.fortnite_desc': 'Evento crossover especial — ilha temática com os personagens do jogo!',
        'eventos.ilha': 'Ilha:', 'eventos.fortnite_oficial': 'Fortnite oficial',
        'config.titulo': '⚙️ Configurações', 'config.subtitulo': 'Personalize o app do seu jeito',
        'config.idioma.titulo': 'Idioma / Language / Idioma',
        'config.idioma.desc': 'Escolha o idioma da interface. A mudança é aplicada imediatamente em todo o app.',
        'config.idioma.atual_a': 'Idioma atual:',
        'config.tema.titulo': 'Tema', 'config.tema.desc': 'Escolha o visual da interface',
        'config.sobre.titulo': 'Sobre', 'config.sobre.desc': 'Informações do aplicativo',
        'config.versao': 'Versão', 'config.ano': '© 2026 Community News',
        'vip.titulo': '⭐ Seja Membro VIP', 'vip.subtitulo': 'Desbloqueie todo o poder do Community News',
        'vip.unico': '/ único', 'vip.mes': '/ mês',
        'vip.base.titulo': '🟢 Plano Base', 'vip.base.desc_a': 'Apenas', 'vip.base.desc_b': '2 usos', 'vip.base.desc_c': 'inclusos — sem recarga adicional.',
        'vip.base.b1': 'Perfil personalizado', 'vip.base.b2': 'Postar imagens e vídeos', 'vip.base.b3': 'Comentar e reagir',
        'vip.base.b4': 'Limite de 2 usos', 'vip.base.b5': 'Recarga adicional', 'vip.base.b6': 'Chat de mensagens VIP',
        'vip.base.b7': 'Canal de membros', 'vip.base.b8': 'Emblemas exclusivos', 'vip.base.btn': 'Assinar Base →',
        'vip.senior.titulo': '🟡 Plano Sênior', 'vip.senior.desc_a': 'Recarregue', 'vip.senior.desc_b': 'quantas vezes quiser', 'vip.senior.desc_c': '. Sem limite de uso!',
        'vip.senior.b1': 'Tudo do Plano Base', 'vip.senior.b2': 'Recarga ilimitada', 'vip.senior.b3': 'Perfil VIP com visual diferente',
        'vip.senior.b4': 'Canal de membros', 'vip.senior.b5': 'Postagens ilimitadas', 'vip.senior.b6': 'Receber doações de membros',
        'vip.senior.b7': 'Chat de voz ilimitado', 'vip.senior.b8': 'Emblemas colecionáveis', 'vip.senior.btn': 'Assinar Sênior →',
        'vip.pro.tag': '👑 Recomendado', 'vip.pro.titulo': '👑 Plano Pro', 'vip.pro.desc': 'Tudo liberado, sem limites. A experiência completa!',
        'vip.pro.b1': 'Tudo do Sênior', 'vip.pro.b2': 'Acesso total, sem limites', 'vip.pro.b3': 'Recarga ilimitada',
        'vip.pro.b4': 'Chat ilimitado — texto, áudio e arquivos', 'vip.pro.b5': 'Emblemas exclusivos e conquistas',
        'vip.pro.b6': 'Gravação e envio de voz', 'vip.pro.b7': 'Suporte prioritário', 'vip.pro.b8': 'Acesso antecipado a novidades',
        'vip.pro.btn': 'Assinar Pro →',
        'vip.idade.titulo': 'Verificação de idade',
        'vip.idade.desc_a': 'Para assinar um plano VIP, informe sua data de nascimento. É necessário ter',
        'vip.idade.desc_b': '16 anos ou mais', 'vip.idade.label': 'Data de nascimento',
        'vip.idade.erro': 'Data inválida. Use o formato dd/mm/aaaa.', 'vip.idade.ok': 'Idade confirmada! Você já pode assinar.',
        'chat.titulo': '💬 Chat & Comunidade', 'chat.subtitulo': 'Mensagens, chamadas e grupos',
        'chat.conversas': 'Conversas', 'chat.pesquisar': '🔍 Pesquisar...', 'chat.vazio_titulo': 'Selecione uma conversa', 'chat.vazio_desc': 'Ou toque no + abaixo',
        'chat.conversa': 'Conversa', 'chat.digitando': 'está digitando...', 'chat.gravando': 'Gravando...',
        'chat.cancelar': 'Cancelar envio', 'chat.msg_ph': 'Mensagem...',
        'perfil.titulo': '👤 Meu Perfil', 'perfil.trocar_capa': 'Trocar capa', 'perfil.online': '● Online', 'perfil.sem_bio': 'Sem bio ainda.',
        'perfil.grupos': 'Grupos', 'perfil.comunidades': 'Comunidades', 'perfil.amigos': 'Amigos',
        'perfil.editar': 'Editar', 'perfil.compartilhar': 'Compartilhar', 'perfil.copiar': 'Copiar',
        'perfil.apagar.titulo': 'Apagar Perfil',
        'perfil.apagar.desc': 'Esta ação remove permanentemente seu perfil, avatar, bio, interesses e histórico. Você pode',
        'perfil.apagar.desc_b': 'guardar um backup', 'perfil.apagar.desc_c': 'antes para restaurar depois.',
        'perfil.apagar.btn': 'Apagar Meu Perfil', 'perfil.apagar.backup': 'Backup encontrado — você pode restaurar seu perfil quando quiser.',
        'perfil.apagar.atencao': 'Atenção:',
        'perfil.apagar.modal_desc': 'apagar o perfil remove permanentemente seu apelido, avatar, bio, frase, interesses e histórico. Você pode guardar um backup antes para poder restaurar depois.',
        'perfil.apagar.confirmar': 'Confirmar Apagamento', 'perfil.apagar.guardar': 'Guardar Perfil', 'perfil.apagar.restaurar': 'Restaurar Perfil',
        'sheet.titulo': '✦ Criar', 'sheet.comu': 'Comunidade', 'sheet.comu_desc': 'Grupo grande',
        'sheet.grupo': 'Grupo', 'sheet.grupo_desc': 'Chat em grupo', 'sheet.link': 'Entrar por Link', 'sheet.link_desc': 'Cole um link',
        'sheet.contato': 'Nova Conversa', 'sheet.contato_desc': '1-a-1',
        'modal.grupo.titulo': 'Novo Grupo', 'modal.comu.titulo': 'Nova Comunidade', 'modal.link.titulo': 'Entrar por Link', 'modal.contato.titulo': 'Nova Conversa',
        'modal.grupo.nome': 'Nome', 'modal.grupo.icone': 'Ícone', 'modal.grupo.desc': 'Descrição', 'modal.link.cole': 'Cole o link',
        'modal.perfil.titulo': 'Editar Perfil', 'modal.perfil.cor': 'Cor do Perfil',
        'modal.fb.titulo': 'Enviar Feedback', 'modal.fb.desc': 'Conta pra gente o que achou!',
        'modal.fb.sugestao': 'Sugestão', 'modal.fb.bug': 'Bug', 'modal.fb.elogio': 'Elogio', 'modal.fb.outro': 'Outro',
        'modal.fb.nota': 'Que nota você dá?', 'modal.fb.msg': 'Sua mensagem', 'modal.fb.msg_ph': 'Escreva com detalhes...',
        'modal.fb.btn': 'Enviar Feedback', 'modal.fb.obrigado': 'Obrigado! 💙', 'modal.fb.sucesso': 'Seu feedback foi enviado com sucesso!', 'modal.fb.fechar': 'Fechar',
        'modal.sobre.titulo': 'Sobre o Community News', 'modal.sobre.desc': 'O',
        'modal.sobre.desc_b': 'é uma plataforma gamer: notícias, chat, chamadas, comunidades, jogos e lojas.',
        'modal.sobre.info': 'Informações', 'modal.sobre.versao': 'Versão', 'modal.sobre.plataforma': 'Plataforma', 'modal.sobre.status': 'Status', 'modal.sobre.status_val': '🟢 Online',
        'modal.sobre.recursos': 'Recursos',
        'modal.sobre.r1': 'Tela de carregamento na entrada', 'modal.sobre.r2': 'Onboarding de perfil em 3 passos',
        'modal.sobre.r3': '40+ ícones de avatar personalizados', 'modal.sobre.r4': 'Upload de foto da galeria',
        'modal.sobre.r5': 'Chat com áudio e imagens', 'modal.sobre.r6': 'Chamadas de voz e vídeo',
        'modal.sobre.r7': '3 planos VIP (Base, Sênior e Pro)', 'modal.sobre.r8': 'Suporte a 3 idiomas (PT, EN, ES)',
        'modal.sobre.r9': 'Backup e restauração de perfil', 'modal.sobre.r10': 'Cartões com borda animada no hover',
        'seg.titulo': 'Segurança', 'seg.sem_senha': 'SEM SENHA', 'seg.senha': 'Senha', 'seg.privacidade': 'Privacidade',
        'seg.sessoes': 'Sessões', 'seg.log': 'Log',
        'seg.ocultar_prev': 'Ocultar prévia das mensagens', 'seg.ocultar_prev_desc': 'Notificações aparecem como "Nova mensagem"',
        'seg.modo_discreto': 'Modo discreto', 'seg.modo_discreto_desc': 'Sem som e sem vibração',
        'seg.ocultar_online': 'Ocultar status online', 'seg.ocultar_online_desc': 'Outros não veem quando online',
        'seg.encerrar_outras': 'Encerrar todas as outras', 'seg.limpar_hist': 'Limpar histórico',
        'pin.titulo': 'Digite a senha', 'pin.sub': 'Digite de 4 a 6 dígitos',
        'assinatura.titulo': 'Assinatura — Plano', 'assinatura.pagar': 'Pagar pelo Nubank →',
        'assinatura.prazo': 'Prazo de pagamento:', 'assinatura.cancelar': 'Cancelar Assinatura',
        'chamada.chamando': 'Chamando...', 'chamada.conectando': 'Conectando...',
        'toast.nova_msg': 'Nova mensagem',
        'btn.cancelar': 'Cancelar', 'btn.criar': 'Criar', 'btn.entrar': 'Entrar', 'btn.salvar': 'Salvar'
    },
    en: {
        'a11y.skip': 'Skip to main content',
        'loading.txt': 'Loading...', 'loading.f1': 'Loading...', 'loading.f2': 'Preparing interface...', 'loading.f3': 'Syncing data...', 'loading.f4': 'Almost ready...', 'loading.f5': 'Finishing...',
        'onb.bem_vindo': 'Welcome to', 'onb.bem_vindo_html': 'Welcome to',
        'onb.subtitulo': "Let's create your profile in 3 quick steps",
        'onb.passo': 'Step', 'onb.de': 'of', 'onb.apelido': 'Nickname', 'onb.avatar': 'Avatar', 'onb.personalizar': 'Customize',
        'onb.seu_apelido': 'Your nickname', 'onb.sem_bio': 'No bio yet',
        'onb.p1.titulo': 'What should we call you?',
        'onb.p1.desc': "Choose a unique nickname — that's how others will see you in the app. You can change it later in settings.",
        'onb.p1.label': 'Nickname', 'onb.p1.ph': 'Ex: Player_Pro, Lunar, GhostZ...',
        'onb.p2.titulo': 'Choose your avatar', 'onb.p2.desc': 'Scroll to see all icons or upload a photo from your gallery.',
        'onb.p2.upload_tit': 'Choose a photo', 'onb.p2.upload_sub': 'From gallery, Google Photos or camera', 'onb.p2.hint': 'Scroll to see more icons',
        'onb.p3.titulo': 'Make it your own', 'onb.p3.desc_a': 'Customize with your color, bio and interests.',
        'onb.p3.desc_b': 'All fields are optional', 'onb.p3.desc_c': '— you can change them later!',
        'onb.p3.cor': 'Profile color', 'onb.p3.bio': 'Bio', 'onb.p3.opc': '(optional)', 'onb.p3.bio_ph': 'Ex: Gamer, streamer, love FPS...',
        'onb.p3.interesses': 'Interests', 'onb.p3.frase': 'Favorite quote', 'onb.p3.frase_ph': 'Ex: No pain, no gain',
        'onb.p3.pronto': 'All set? Click below to', 'onb.p3.criar_avatar': 'create your avatar', 'onb.p3.e_comecar': 'and get started!',
        'onb.p3.btn_criar': 'Create my Avatar', 'onb.voltar': 'Back', 'onb.continuar': 'Continue',
        'lock.sub': 'Enter your password to continue', 'lock.esqueci': 'Forgot password',
        'sb.bem_vindo': 'Welcome! 👋', 'sb.navegacao': 'Navigation', 'sb.aparencia': 'Appearance', 'sb.meus_grupos': 'My groups',
        'sb.seguranca': 'Security', 'sb.suporte': 'Support', 'sb.copyright': 'Community News © 2026',
        'nav.inicio': 'Home', 'nav.jogos': 'Games & Stores', 'nav.eventos': 'Events', 'nav.chat': 'Chat', 'nav.perfil': 'My Profile',
        'nav.config': 'Settings', 'nav.vip': 'Go VIP', 'nav.seguranca': 'Security', 'nav.feedback': 'Send Feedback',
        'nav.sobre': 'About the App', 'nav.sair': 'Sign out',
        'tema.escuro': 'Dark', 'tema.padrao': 'Default', 'tema.claro': 'Light', 'tema.halloween': 'Halloween',
        'home.bem_vindo': 'Welcome back! 👋', 'home.subtitulo': 'News • Games • Real-time Chat',
        'home.halloween_titulo': '🎃 Countdown — Halloween 2026', 'home.dias': 'Days', 'home.horas': 'Hours', 'home.min': 'Min', 'home.seg': 'Sec',
        'home.halloween_data': 'October 16, 2026 — Save the date!',
        'card.chat_titulo': '💬 Real Chat', 'card.chat_desc': 'Messages, audio, images and real-time calls!',
        'card.perfil_titulo': '👤 My Profile', 'card.perfil_desc': 'Color, cover and avatar fully customizable',
        'card.vip_titulo': '⭐ Go VIP', 'card.vip_desc': 'Unlock everything for R$ 4, R$ 8 or R$ 12',
        'card.abrir': 'Open →', 'card.ver': 'See plans →',
        'aval.titulo': 'How was your experience?', 'aval.dica': 'Hover over the stars and watch the face react.',
        'aval.toca': 'Tap a star', 'aval.conta': 'TELL US (IF YOU WANT)', 'aval.ph': 'What made the difference?',
        'aval.enviar': 'Send rating', 'aval.obrigado': 'Thanks! Your rating was saved on this device.',
        'jogos.titulo': '🎮 Games & Stores', 'jogos.subtitulo': 'Complete stories + official links',
        'jogos.destaques': '✨ Weekly highlights', 'jogos.dica': 'Drag the carousel or use the arrows.',
        'jogos.site': 'Visit official site', 'jogos.completos': 'Full games', 'jogos.lojas': 'Official stores',
        'eventos.titulo': '🔥 Events', 'eventos.fortnite_titulo': '🎮 Fortnite x Poppy Playtime',
        'eventos.fortnite_desc': 'Special crossover event — themed island with the game characters!',
        'eventos.ilha': 'Island:', 'eventos.fortnite_oficial': 'Official Fortnite',
        'config.titulo': '⚙️ Settings', 'config.subtitulo': 'Customize the app your way',
        'config.idioma.titulo': 'Language / Idioma / Language',
        'config.idioma.desc': 'Choose the interface language. The change is applied immediately across the app.',
        'config.idioma.atual_a': 'Current language:',
        'config.tema.titulo': 'Theme', 'config.tema.desc': 'Choose the interface look',
        'config.sobre.titulo': 'About', 'config.sobre.desc': 'Application information',
        'config.versao': 'Version', 'config.ano': '© 2026 Community News',
        'vip.titulo': '⭐ Become a VIP Member', 'vip.subtitulo': 'Unlock the full power of Community News',
        'vip.unico': '/ one-time', 'vip.mes': '/ month',
        'vip.base.titulo': '🟢 Base Plan', 'vip.base.desc_a': 'Only', 'vip.base.desc_b': '2 uses', 'vip.base.desc_c': 'included — no additional reload.',
        'vip.base.b1': 'Custom profile', 'vip.base.b2': 'Post images and videos', 'vip.base.b3': 'Comment and react',
        'vip.base.b4': 'Limit of 2 uses', 'vip.base.b5': 'Additional reload', 'vip.base.b6': 'VIP chat messages',
        'vip.base.b7': 'Members channel', 'vip.base.b8': 'Exclusive badges', 'vip.base.btn': 'Subscribe Base →',
        'vip.senior.titulo': '🟡 Senior Plan', 'vip.senior.desc_a': 'Reload', 'vip.senior.desc_b': 'as many times as you want', 'vip.senior.desc_c': '. No usage limit!',
        'vip.senior.b1': 'Everything from Base', 'vip.senior.b2': 'Unlimited reload', 'vip.senior.b3': 'VIP profile with unique look',
        'vip.senior.b4': 'Members channel', 'vip.senior.b5': 'Unlimited posts', 'vip.senior.b6': 'Receive member donations',
        'vip.senior.b7': 'Unlimited voice chat', 'vip.senior.b8': 'Collectible badges', 'vip.senior.btn': 'Subscribe Senior →',
        'vip.pro.tag': '👑 Recommended', 'vip.pro.titulo': '👑 Pro Plan', 'vip.pro.desc': 'Everything unlocked, no limits. The complete experience!',
        'vip.pro.b1': 'Everything from Senior', 'vip.pro.b2': 'Full access, no limits', 'vip.pro.b3': 'Unlimited reload',
        'vip.pro.b4': 'Unlimited chat — text, audio and files', 'vip.pro.b5': 'Exclusive badges and achievements',
        'vip.pro.b6': 'Voice recording and sending', 'vip.pro.b7': 'Priority support', 'vip.pro.b8': 'Early access to new features',
        'vip.pro.btn': 'Subscribe Pro →',
        'vip.idade.titulo': 'Age verification',
        'vip.idade.desc_a': 'To subscribe to a VIP plan, enter your date of birth. You must be',
        'vip.idade.desc_b': '16 years or older', 'vip.idade.label': 'Date of birth',
        'vip.idade.erro': 'Invalid date. Use the format dd/mm/yyyy.', 'vip.idade.ok': 'Age confirmed! You can now subscribe.',
        'chat.titulo': '💬 Chat & Community', 'chat.subtitulo': 'Messages, calls and groups',
        'chat.conversas': 'Conversations', 'chat.pesquisar': '🔍 Search...', 'chat.vazio_titulo': 'Select a conversation', 'chat.vazio_desc': 'Or tap the + below',
        'chat.conversa': 'Conversation', 'chat.digitando': 'is typing...', 'chat.gravando': 'Recording...',
        'chat.cancelar': 'Cancel upload', 'chat.msg_ph': 'Message...',
        'perfil.titulo': '👤 My Profile', 'perfil.trocar_capa': 'Change cover', 'perfil.online': '● Online', 'perfil.sem_bio': 'No bio yet.',
        'perfil.grupos': 'Groups', 'perfil.comunidades': 'Communities', 'perfil.amigos': 'Friends',
        'perfil.editar': 'Edit', 'perfil.compartilhar': 'Share', 'perfil.copiar': 'Copy',
        'perfil.apagar.titulo': 'Delete Profile',
        'perfil.apagar.desc': 'This action permanently removes your profile, avatar, bio, interests and history. You can',
        'perfil.apagar.desc_b': 'save a backup', 'perfil.apagar.desc_c': 'before to restore later.',
        'perfil.apagar.btn': 'Delete My Profile', 'perfil.apagar.backup': 'Backup found — you can restore your profile anytime.',
        'perfil.apagar.atencao': 'Warning:',
        'perfil.apagar.modal_desc': 'deleting the profile permanently removes your nickname, avatar, bio, quote, interests and history. You can save a backup first to restore later.',
        'perfil.apagar.confirmar': 'Confirm Deletion', 'perfil.apagar.guardar': 'Save Profile', 'perfil.apagar.restaurar': 'Restore Profile',
        'sheet.titulo': '✦ Create', 'sheet.comu': 'Community', 'sheet.comu_desc': 'Large group',
        'sheet.grupo': 'Group', 'sheet.grupo_desc': 'Group chat', 'sheet.link': 'Join by Link', 'sheet.link_desc': 'Paste a link',
        'sheet.contato': 'New Chat', 'sheet.contato_desc': '1-on-1',
        'modal.grupo.titulo': 'New Group', 'modal.comu.titulo': 'New Community', 'modal.link.titulo': 'Join by Link', 'modal.contato.titulo': 'New Chat',
        'modal.grupo.nome': 'Name', 'modal.grupo.icone': 'Icon', 'modal.grupo.desc': 'Description', 'modal.link.cole': 'Paste the link',
        'modal.perfil.titulo': 'Edit Profile', 'modal.perfil.cor': 'Profile Color',
        'modal.fb.titulo': 'Send Feedback', 'modal.fb.desc': 'Tell us what you think!',
        'modal.fb.sugestao': 'Suggestion', 'modal.fb.bug': 'Bug', 'modal.fb.elogio': 'Compliment', 'modal.fb.outro': 'Other',
        'modal.fb.nota': 'What score do you give?', 'modal.fb.msg': 'Your message', 'modal.fb.msg_ph': 'Write in detail...',
        'modal.fb.btn': 'Send Feedback', 'modal.fb.obrigado': 'Thank you! 💙', 'modal.fb.sucesso': 'Your feedback was sent successfully!', 'modal.fb.fechar': 'Close',
        'modal.sobre.titulo': 'About Community News', 'modal.sobre.desc': '',
        'modal.sobre.desc_b': 'is a gaming platform: news, chat, calls, communities, games and stores.',
        'modal.sobre.info': 'Information', 'modal.sobre.versao': 'Version', 'modal.sobre.plataforma': 'Platform', 'modal.sobre.status': 'Status', 'modal.sobre.status_val': '🟢 Online',
        'modal.sobre.recursos': 'Features',
        'modal.sobre.r1': 'Loading screen on entry', 'modal.sobre.r2': '3-step profile onboarding',
        'modal.sobre.r3': '40+ custom avatar icons', 'modal.sobre.r4': 'Photo upload from gallery',
        'modal.sobre.r5': 'Chat with audio and images', 'modal.sobre.r6': 'Voice and video calls',
        'modal.sobre.r7': '3 VIP plans (Base, Senior, Pro)', 'modal.sobre.r8': 'Supports 3 languages (PT, EN, ES)',
        'modal.sobre.r9': 'Profile backup and restore', 'modal.sobre.r10': 'Cards with animated hover border',
        'seg.titulo': 'Security', 'seg.sem_senha': 'NO PASSWORD', 'seg.senha': 'Password', 'seg.privacidade': 'Privacy',
        'seg.sessoes': 'Sessions', 'seg.log': 'Log',
        'seg.ocultar_prev': 'Hide message preview', 'seg.ocultar_prev_desc': 'Notifications show as "New message"',
        'seg.modo_discreto': 'Discreet mode', 'seg.modo_discreto_desc': 'No sound and no vibration',
        'seg.ocultar_online': 'Hide online status', 'seg.ocultar_online_desc': 'Others cannot see when online',
        'seg.encerrar_outras': 'End all other sessions', 'seg.limpar_hist': 'Clear history',
        'pin.titulo': 'Enter password', 'pin.sub': 'Enter 4 to 6 digits',
        'assinatura.titulo': 'Subscription — Plan', 'assinatura.pagar': 'Pay with Nubank →',
        'assinatura.prazo': 'Payment deadline:', 'assinatura.cancelar': 'Cancel Subscription',
        'chamada.chamando': 'Calling...', 'chamada.conectando': 'Connecting...',
        'toast.nova_msg': 'New message',
        'btn.cancelar': 'Cancel', 'btn.criar': 'Create', 'btn.entrar': 'Enter', 'btn.salvar': 'Save'
    },
    es: {
        'a11y.skip': 'Saltar al contenido principal',
        'loading.txt': 'Cargando...', 'loading.f1': 'Cargando...', 'loading.f2': 'Preparando interfaz...', 'loading.f3': 'Sincronizando datos...', 'loading.f4': 'Casi listo...', 'loading.f5': 'Finalizando...',
        'onb.bem_vindo': 'Bienvenido a', 'onb.bem_vindo_html': 'Bienvenido a',
        'onb.subtitulo': 'Vamos a crear tu perfil en 3 pasos rápidos',
        'onb.passo': 'Paso', 'onb.de': 'de', 'onb.apelido': 'Apodo', 'onb.avatar': 'Avatar', 'onb.personalizar': 'Personalizar',
        'onb.seu_apelido': 'Tu apodo', 'onb.sem_bio': 'Sin bio aún',
        'onb.p1.titulo': '¿Cómo podemos llamarte?',
        'onb.p1.desc': 'Elige un apodo único — así es como los demás te verán en la app. Puedes cambiarlo después en la configuración.',
        'onb.p1.label': 'Apodo', 'onb.p1.ph': 'Ej: Player_Pro, Lunar, GhostZ...',
        'onb.p2.titulo': 'Elige tu avatar', 'onb.p2.desc': 'Desplázate para ver todos los iconos o sube una foto de tu galería.',
        'onb.p2.upload_tit': 'Elegir una foto', 'onb.p2.upload_sub': 'De la galería, Google Fotos o cámara', 'onb.p2.hint': 'Desplázate para ver más iconos',
        'onb.p3.titulo': 'Hazlo a tu manera', 'onb.p3.desc_a': 'Personaliza con tu color, bio e intereses.',
        'onb.p3.desc_b': 'Todos los campos son opcionales', 'onb.p3.desc_c': '— ¡puedes cambiarlos después!',
        'onb.p3.cor': 'Color del perfil', 'onb.p3.bio': 'Bio', 'onb.p3.opc': '(opcional)', 'onb.p3.bio_ph': 'Ej: Gamer, streamer, amo FPS...',
        'onb.p3.interesses': 'Intereses', 'onb.p3.frase': 'Frase favorita', 'onb.p3.frase_ph': 'Ej: No pain, no gain',
        'onb.p3.pronto': '¿Todo listo? Haz clic abajo para', 'onb.p3.criar_avatar': 'crear tu avatar', 'onb.p3.e_comecar': '¡y comenzar!',
        'onb.p3.btn_criar': 'Crear mi Avatar', 'onb.voltar': 'Atrás', 'onb.continuar': 'Continuar',
        'lock.sub': 'Ingresa tu contraseña para continuar', 'lock.esqueci': 'Olvidé mi contraseña',
        'sb.bem_vindo': '¡Bienvenido! 👋', 'sb.navegacao': 'Navegación', 'sb.aparencia': 'Apariencia', 'sb.meus_grupos': 'Mis grupos',
        'sb.seguranca': 'Seguridad', 'sb.suporte': 'Soporte', 'sb.copyright': 'Community News © 2026',
        'nav.inicio': 'Inicio', 'nav.jogos': 'Juegos y Tiendas', 'nav.eventos': 'Eventos', 'nav.chat': 'Chat', 'nav.perfil': 'Mi Perfil',
        'nav.config': 'Configuración', 'nav.vip': 'Ser VIP', 'nav.seguranca': 'Seguridad', 'nav.feedback': 'Enviar Comentarios',
        'nav.sobre': 'Acerca de la App', 'nav.sair': 'Salir',
        'tema.escuro': 'Oscuro', 'tema.padrao': 'Predeterminado', 'tema.claro': 'Claro', 'tema.halloween': 'Halloween',
        'home.bem_vindo': '¡Bienvenido de nuevo! 👋', 'home.subtitulo': 'Noticias • Juegos • Chat en Tiempo Real',
        'home.halloween_titulo': '🎃 Cuenta Regresiva — Halloween 2026', 'home.dias': 'Días', 'home.horas': 'Horas', 'home.min': 'Min', 'home.seg': 'Seg',
        'home.halloween_data': '16 de octubre de 2026 — ¡Guarda la fecha!',
        'card.chat_titulo': '💬 Chat Real', 'card.chat_desc': '¡Mensajes, audio, imágenes y llamadas en tiempo real!',
        'card.perfil_titulo': '👤 Mi Perfil', 'card.perfil_desc': 'Color, portada y avatar totalmente personalizables',
        'card.vip_titulo': '⭐ Ser VIP', 'card.vip_desc': 'Desbloquea todo por R$ 4, R$ 8 o R$ 12',
        'card.abrir': 'Abrir →', 'card.ver': 'Ver planes →',
        'aval.titulo': '¿Cómo fue tu experiencia?', 'aval.dica': 'Pasa el mouse por las estrellas y mira la carita reaccionar.',
        'aval.toca': 'Toca una estrella', 'aval.conta': 'CUÉNTANOS (SI QUIERES)', 'aval.ph': '¿Qué marcó la diferencia?',
        'aval.enviar': 'Enviar evaluación', 'aval.obrigado': '¡Gracias! Tu evaluación fue guardada en este dispositivo.',
        'jogos.titulo': '🎮 Juegos y Tiendas', 'jogos.subtitulo': 'Historias completas + enlaces oficiales',
        'jogos.destaques': '✨ Destacados de la semana', 'jogos.dica': 'Arrastra el carrusel o usa las flechas.',
        'jogos.site': 'Visitar sitio oficial', 'jogos.completos': 'Juegos completos', 'jogos.lojas': 'Tiendas oficiales',
        'eventos.titulo': '🔥 Eventos', 'eventos.fortnite_titulo': '🎮 Fortnite x Poppy Playtime',
        'eventos.fortnite_desc': '¡Evento crossover especial — isla temática con los personajes del juego!',
        'eventos.ilha': 'Isla:', 'eventos.fortnite_oficial': 'Fortnite oficial',
        'config.titulo': '⚙️ Configuración', 'config.subtitulo': 'Personaliza la app a tu manera',
        'config.idioma.titulo': 'Idioma / Language / Idioma',
        'config.idioma.desc': 'Elige el idioma de la interfaz. El cambio se aplica inmediatamente en toda la app.',
        'config.idioma.atual_a': 'Idioma actual:',
        'config.tema.titulo': 'Tema', 'config.tema.desc': 'Elige el aspecto de la interfaz',
        'config.sobre.titulo': 'Acerca de', 'config.sobre.desc': 'Información de la aplicación',
        'config.versao': 'Versión', 'config.ano': '© 2026 Community News',
        'vip.titulo': '⭐ Ser Miembro VIP', 'vip.subtitulo': 'Desbloquea todo el poder de Community News',
        'vip.unico': '/ único', 'vip.mes': '/ mes',
        'vip.base.titulo': '🟢 Plan Base', 'vip.base.desc_a': 'Solo', 'vip.base.desc_b': '2 usos', 'vip.base.desc_c': 'incluidos — sin recarga adicional.',
        'vip.base.b1': 'Perfil personalizado', 'vip.base.b2': 'Publicar imágenes y videos', 'vip.base.b3': 'Comentar y reaccionar',
        'vip.base.b4': 'Límite de 2 usos', 'vip.base.b5': 'Recarga adicional', 'vip.base.b6': 'Chat de mensajes VIP',
        'vip.base.b7': 'Canal de miembros', 'vip.base.b8': 'Emblemas exclusivos', 'vip.base.btn': 'Suscribir Base →',
        'vip.senior.titulo': '🟡 Plan Sénior', 'vip.senior.desc_a': 'Recarga', 'vip.senior.desc_b': 'cuantas veces quieras', 'vip.senior.desc_c': '. ¡Sin límite de uso!',
        'vip.senior.b1': 'Todo del Plan Base', 'vip.senior.b2': 'Recarga ilimitada', 'vip.senior.b3': 'Perfil VIP con estilo diferente',
        'vip.senior.b4': 'Canal de miembros', 'vip.senior.b5': 'Publicaciones ilimitadas', 'vip.senior.b6': 'Recibir donaciones de miembros',
        'vip.senior.b7': 'Chat de voz ilimitado', 'vip.senior.b8': 'Emblemas coleccionables', 'vip.senior.btn': 'Suscribir Sénior →',
        'vip.pro.tag': '👑 Recomendado', 'vip.pro.titulo': '👑 Plan Pro', 'vip.pro.desc': '¡Todo desbloqueado, sin límites. La experiencia completa!',
        'vip.pro.b1': 'Todo del Sénior', 'vip.pro.b2': 'Acceso total, sin límites', 'vip.pro.b3': 'Recarga ilimitada',
        'vip.pro.b4': 'Chat ilimitado — texto, audio y archivos', 'vip.pro.b5': 'Emblemas exclusivos y logros',
        'vip.pro.b6': 'Grabación y envío de voz', 'vip.pro.b7': 'Soporte prioritario', 'vip.pro.b8': 'Acceso anticipado a novedades',
        'vip.pro.btn': 'Suscribir Pro →',
        'vip.idade.titulo': 'Verificación de edad',
        'vip.idade.desc_a': 'Para suscribirte a un plan VIP, ingresa tu fecha de nacimiento. Debes tener',
        'vip.idade.desc_b': '16 años o más', 'vip.idade.label': 'Fecha de nacimiento',
        'vip.idade.erro': 'Fecha inválida. Usa el formato dd/mm/aaaa.', 'vip.idade.ok': '¡Edad confirmada! Ya puedes suscribirte.',
        'chat.titulo': '💬 Chat y Comunidad', 'chat.subtitulo': 'Mensajes, llamadas y grupos',
        'chat.conversas': 'Conversaciones', 'chat.pesquisar': '🔍 Buscar...', 'chat.vazio_titulo': 'Selecciona una conversación', 'chat.vazio_desc': 'O toca el + abajo',
        'chat.conversa': 'Conversación', 'chat.digitando': 'está escribiendo...', 'chat.gravando': 'Grabando...',
        'chat.cancelar': 'Cancelar envío', 'chat.msg_ph': 'Mensaje...',
        'perfil.titulo': '👤 Mi Perfil', 'perfil.trocar_capa': 'Cambiar portada', 'perfil.online': '● En línea', 'perfil.sem_bio': 'Sin bio aún.',
        'perfil.grupos': 'Grupos', 'perfil.comunidades': 'Comunidades', 'perfil.amigos': 'Amigos',
        'perfil.editar': 'Editar', 'perfil.compartilhar': 'Compartir', 'perfil.copiar': 'Copiar',
        'perfil.apagar.titulo': 'Eliminar Perfil',
        'perfil.apagar.desc': 'Esta acción elimina permanentemente tu perfil, avatar, bio, intereses e historial. Puedes',
        'perfil.apagar.desc_b': 'guardar un respaldo', 'perfil.apagar.desc_c': 'antes para restaurar después.',
        'perfil.apagar.btn': 'Eliminar Mi Perfil', 'perfil.apagar.backup': 'Respaldo encontrado — puedes restaurar tu perfil cuando quieras.',
        'perfil.apagar.atencao': 'Atención:',
        'perfil.apagar.modal_desc': 'eliminar el perfil elimina permanentemente tu apodo, avatar, bio, frase, intereses e historial. Puedes guardar un respaldo antes para restaurarlo después.',
        'perfil.apagar.confirmar': 'Confirmar Eliminación', 'perfil.apagar.guardar': 'Guardar Perfil', 'perfil.apagar.restaurar': 'Restaurar Perfil',
        'sheet.titulo': '✦ Crear', 'sheet.comu': 'Comunidad', 'sheet.comu_desc': 'Grupo grande',
        'sheet.grupo': 'Grupo', 'sheet.grupo_desc': 'Chat grupal', 'sheet.link': 'Unirse por Enlace', 'sheet.link_desc': 'Pega un enlace',
        'sheet.contato': 'Nueva Conversación', 'sheet.contato_desc': '1-a-1',
        'modal.grupo.titulo': 'Nuevo Grupo', 'modal.comu.titulo': 'Nueva Comunidad', 'modal.link.titulo': 'Unirse por Enlace', 'modal.contato.titulo': 'Nueva Conversación',
        'modal.grupo.nome': 'Nombre', 'modal.grupo.icone': 'Icono', 'modal.grupo.desc': 'Descripción', 'modal.link.cole': 'Pega el enlace',
        'modal.perfil.titulo': 'Editar Perfil', 'modal.perfil.cor': 'Color del Perfil',
        'modal.fb.titulo': 'Enviar Comentarios', 'modal.fb.desc': '¡Cuéntanos qué piensas!',
        'modal.fb.sugestao': 'Sugerencia', 'modal.fb.bug': 'Error', 'modal.fb.elogio': 'Elogio', 'modal.fb.outro': 'Otro',
        'modal.fb.nota': '¿Qué puntuación das?', 'modal.fb.msg': 'Tu mensaje', 'modal.fb.msg_ph': 'Escribe con detalle...',
        'modal.fb.btn': 'Enviar Comentarios', 'modal.fb.obrigado': '¡Gracias! 💙', 'modal.fb.sucesso': '¡Tu comentario fue enviado con éxito!', 'modal.fb.fechar': 'Cerrar',
        'modal.sobre.titulo': 'Acerca de Community News', 'modal.sobre.desc': '',
        'modal.sobre.desc_b': 'es una plataforma gamer: noticias, chat, llamadas, comunidades, juegos y tiendas.',
        'modal.sobre.info': 'Información', 'modal.sobre.versao': 'Versión', 'modal.sobre.plataforma': 'Plataforma', 'modal.sobre.status': 'Estado', 'modal.sobre.status_val': '🟢 En línea',
        'modal.sobre.recursos': 'Recursos',
        'modal.sobre.r1': 'Pantalla de carga al entrar', 'modal.sobre.r2': 'Onboarding de perfil en 3 pasos',
        'modal.sobre.r3': '40+ iconos de avatar personalizados', 'modal.sobre.r4': 'Subir foto desde la galería',
        'modal.sobre.r5': 'Chat con audio e imágenes', 'modal.sobre.r6': 'Llamadas de voz y video',
        'modal.sobre.r7': '3 planes VIP (Base, Sénior y Pro)', 'modal.sobre.r8': 'Soporte para 3 idiomas (PT, EN, ES)',
        'modal.sobre.r9': 'Respaldo y restauración de perfil', 'modal.sobre.r10': 'Tarjetas con borde animado al pasar el mouse',
        'seg.titulo': 'Seguridad', 'seg.sem_senha': 'SIN CONTRASEÑA', 'seg.senha': 'Contraseña', 'seg.privacidade': 'Privacidad',
        'seg.sessoes': 'Sesiones', 'seg.log': 'Registro',
        'seg.ocultar_prev': 'Ocultar vista previa de mensajes', 'seg.ocultar_prev_desc': 'Las notificaciones aparecen como "Nuevo mensaje"',
        'seg.modo_discreto': 'Modo discreto', 'seg.modo_discreto_desc': 'Sin sonido ni vibración',
        'seg.ocultar_online': 'Ocultar estado en línea', 'seg.ocultar_online_desc': 'Otros no ven cuando estás en línea',
        'seg.encerrar_outras': 'Cerrar todas las demás', 'seg.limpar_hist': 'Limpiar historial',
        'pin.titulo': 'Ingresa la contraseña', 'pin.sub': 'Ingresa de 4 a 6 dígitos',
        'assinatura.titulo': 'Suscripción — Plan', 'assinatura.pagar': 'Pagar con Nubank →',
        'assinatura.prazo': 'Plazo de pago:', 'assinatura.cancelar': 'Cancelar Suscripción',
        'chamada.chamando': 'Llamando...', 'chamada.conectando': 'Conectando...',
        'toast.nova_msg': 'Nuevo mensaje',
        'btn.cancelar': 'Cancelar', 'btn.criar': 'Crear', 'btn.entrar': 'Entrar', 'btn.salvar': 'Guardar'
    }
};

const NOMES_IDIOMA = { pt: 'Português (Brasil)', en: 'English', es: 'Español' };
const BANDEIRAS = { pt: '🇧🇷', en: '🇺🇸', es: '🇪🇸' };

let idiomaAtual = 'pt';
let idiomaChannel = null;
try { idiomaChannel = new BroadcastChannel('community-idioma-sync'); } catch (e) {}

function aplicarIdioma(lang, mostrarToastAviso) {
    if (!lang || IDIOMAS_LIBERADOS.indexOf(lang) === -1) lang = 'pt';
    const anterior = idiomaAtual;
    idiomaAtual = lang;
    const t = TRADUCOES[lang] || TRADUCOES.pt;

    document.documentElement.setAttribute('data-idioma', lang);
    document.documentElement.setAttribute('lang', lang === 'pt' ? 'pt-BR' : lang);
    document.body.setAttribute('data-idioma', lang);

    $$('[data-i18n]').forEach(el => {
        const key = el.getAttribute('data-i18n');
        if (t[key] !== undefined) {
            const hasIcon = el.querySelector('i, svg, .bandeira, .flag-mini');
            if (hasIcon) {
                Array.from(el.childNodes).forEach(n => {
                    if (n.nodeType === 3 && n.textContent.trim()) n.textContent = t[key];
                });
                if (!Array.from(el.childNodes).some(n => n.nodeType === 3 && n.textContent.trim())) {
                    el.appendChild(document.createTextNode(t[key]));
                }
            } else {
                el.textContent = t[key];
            }
        }
    });

    $$('[data-i18n-ph]').forEach(el => {
        const key = el.getAttribute('data-i18n-ph');
        if (t[key] !== undefined) el.placeholder = t[key];
    });

    $$('.idioma-op').forEach(b => {
        const ativo = b.dataset.lang === lang;
        b.classList.toggle('ativo', ativo);
        b.setAttribute('aria-checked', ativo ? 'true' : 'false');
    });

    const atualTxt = $('idioma-atual-txt');
    if (atualTxt) atualTxt.textContent = NOMES_IDIOMA[lang];

    const flagTopo = $('flag-mini-topo');
    const lblTopo = $('lbl-mini-topo');
    if (flagTopo) flagTopo.textContent = BANDEIRAS[lang];
    if (lblTopo) lblTopo.textContent = NOMES_IDIOMA[lang].split(' ')[0];

    atualizarBoasVindas();
    atualizarListaContatos($('busca-conv')?.value);
    renderSessoes();
    renderLog();
    atualizarUISeg();

    try { localStorage.setItem(STORAGE_IDIOMA, lang); } catch (e) {}

    if (idiomaChannel) {
        try { idiomaChannel.postMessage({ idioma: lang, ts: Date.now() }); } catch (e) {}
    }

    if (mostrarToastAviso !== false && anterior !== lang) {
        mostrarToastIdioma(lang);
    }
}

function mostrarToastIdioma(lang) {
    const toast = $('toast-idioma');
    const emoji = $('toast-idioma-emoji');
    const txt = $('toast-idioma-txt');
    if (!toast || !emoji || !txt) return;
    emoji.textContent = BANDEIRAS[lang];
    txt.textContent = 'Idioma: ' + NOMES_IDIOMA[lang];
    toast.classList.add('ativo');
    anunciar('Idioma alterado para ' + NOMES_IDIOMA[lang]);
    clearTimeout(toast._t);
    toast._t = setTimeout(() => toast.classList.remove('ativo'), 2000);
}

function carregarIdiomaSalvo() {
    let l = 'pt';
    try {
        const s = localStorage.getItem(STORAGE_IDIOMA);
        if (s && IDIOMAS_LIBERADOS.indexOf(s) !== -1) l = s;
    } catch (e) {}
    idiomaAtual = l;
    aplicarIdioma(l, false);
}

function configurarIdiomas() {
    $$('.idioma-op').forEach(btn => {
        btn.addEventListener('click', () => {
            const lang = btn.dataset.lang;
            if (!lang || lang === idiomaAtual) return;
            aplicarIdioma(lang, true);
        });
    });

    const btnTopo = $('btn-idioma-topo');
    if (btnTopo) {
        btnTopo.addEventListener('click', () => {
            mostrarAba('config');
            const bloco = document.querySelector('.bloco-config-idioma');
            if (bloco) bloco.scrollIntoView({ behavior: 'smooth', block: 'center' });
        });
    }

    window.addEventListener('storage', (e) => {
        if (e.key === STORAGE_IDIOMA && e.newValue && IDIOMAS_LIBERADOS.indexOf(e.newValue) !== -1 && e.newValue !== idiomaAtual) {
            aplicarIdioma(e.newValue, false);
        }
    });
    if (idiomaChannel) {
        idiomaChannel.addEventListener('message', (e) => {
            if (e.data && e.data.idioma && IDIOMAS_LIBERADOS.indexOf(e.data.idioma) !== -1 && e.data.idioma !== idiomaAtual) {
                aplicarIdioma(e.data.idioma, false);
            }
        });
    }
}

/* RESTANTE DO APP */
const AVATARES = [
    { id:'user', ic:'fa-user', cor:'#3b82f6', label:'Usuário' },
    { id:'astronaut', ic:'fa-user-astronaut', cor:'#0891b2', label:'Astronauta' },
    { id:'ninja', ic:'fa-user-ninja', cor:'#1f2937', label:'Ninja' },
    { id:'secret', ic:'fa-user-secret', cor:'#374151', label:'Agente' },
    { id:'cat', ic:'fa-cat', cor:'#8b5cf6', label:'Gato' },
    { id:'dog', ic:'fa-dog', cor:'#ec4899', label:'Cachorro' },
    { id:'dragon', ic:'fa-dragon', cor:'#22c55e', label:'Dragão' },
    { id:'robot', ic:'fa-robot', cor:'#00c3ff', label:'Robô' },
    { id:'ghost', ic:'fa-ghost', cor:'#a855f7', label:'Fantasma' },
    { id:'rocket', ic:'fa-rocket', cor:'#ef4444', label:'Foguete' },
    { id:'crown', ic:'fa-crown', cor:'#eab308', label:'Coroa' },
    { id:'meteor', ic:'fa-meteor', cor:'#f97316', label:'Meteoro' },
    { id:'fire', ic:'fa-fire', cor:'#dc2626', label:'Fogo' },
    { id:'bolt', ic:'fa-bolt', cor:'#06b6d4', label:'Raio' },
    { id:'gem', ic:'fa-gem', cor:'#a855f7', label:'Gema' },
    { id:'gamepad', ic:'fa-gamepad', cor:'#10b981', label:'Controle' },
    { id:'dice', ic:'fa-dice', cor:'#f59e0b', label:'Dado' },
    { id:'chess', ic:'fa-chess-knight', cor:'#4b5563', label:'Cavalo' },
    { id:'wizard', ic:'fa-hat-wizard', cor:'#8b5cf6', label:'Mago' },
    { id:'spider', ic:'fa-spider', cor:'#111827', label:'Aranha' },
    { id:'fish', ic:'fa-fish', cor:'#06b6d4', label:'Peixe' },
    { id:'frog', ic:'fa-frog', cor:'#22c55e', label:'Sapo' },
    { id:'hippo', ic:'fa-hippo', cor:'#8b5cf6', label:'Hipopótamo' },
    { id:'otter', ic:'fa-otter', cor:'#92400e', label:'Lontra' },
    { id:'dove', ic:'fa-dove', cor:'#f3f4f6', label:'Pomba' },
    { id:'skull', ic:'fa-skull', cor:'#374151', label:'Caveira' },
    { id:'heart', ic:'fa-heart', cor:'#ec4899', label:'Coração' },
    { id:'star', ic:'fa-star', cor:'#facc15', label:'Estrela' },
    { id:'moon', ic:'fa-moon', cor:'#1e40af', label:'Lua' },
    { id:'sun', ic:'fa-sun', cor:'#f59e0b', label:'Sol' },
    { id:'snowflake', ic:'fa-snowflake', cor:'#60a5fa', label:'Floco de neve' },
    { id:'leaf', ic:'fa-leaf', cor:'#16a34a', label:'Folha' },
    { id:'anchor', ic:'fa-anchor', cor:'#0e7490', label:'Âncora' },
    { id:'camera', ic:'fa-camera', cor:'#525252', label:'Câmera' },
    { id:'headphones', ic:'fa-headphones', cor:'#7c3aed', label:'Fones' },
    { id:'microphone', ic:'fa-microphone', cor:'#db2777', label:'Microfone' },
    { id:'glasses', ic:'fa-glasses', cor:'#4b5563', label:'Óculos' },
    { id:'mask', ic:'fa-mask', cor:'#dc2626', label:'Máscara' },
    { id:'guitar', ic:'fa-guitar', cor:'#b45309', label:'Guitarra' },
    { id:'palette', ic:'fa-palette', cor:'#a855f7', label:'Paleta' }
];

function obterAvatar(id) { return AVATARES.find(a => a.id === id) || AVATARES[0]; }

let dados = {
    eu: { nome:'Você', avatarId:'user', avatarFoto:null, cor:'#3b82f6', bio:'', frase:'', interesses:[], capa:null, link:'communitynews.app/@voce', uid:null },
    grupos: [], comunidades: [], contatos: [], notificacoes: [], ativo: null
};

let seg = {
    pinHash: null, pedirAoAbrir: false, bloquearAoSair: false, bloqueioAuto: 5,
    ocultarPrevia: false, modoDiscreto: false, ocultarOnline: false, log: []
};

let vip = { plano: null, expiraEm: null, usosRestantes: 0, recarregavel: false };

const onb = { passo: 1, totalPassos: 3, nome: '', avatarId: 'user', avatarFoto: null, cor: '#3b82f6', bio: '', frase: '', interesses: [] };

function salvar() { try { localStorage.setItem(STORAGE, JSON.stringify(dados)); } catch (e) {} }
function salvarSeg() { try { localStorage.setItem(STORAGE_SEG, JSON.stringify(seg)); } catch (e) {} }
function salvarVip() { try { localStorage.setItem(STORAGE_VIP, JSON.stringify(vip)); } catch (e) {} }
function carregarVip() { try { const v = JSON.parse(localStorage.getItem(STORAGE_VIP) || 'null'); if (v) vip = Object.assign(vip, v); } catch (e) {} }

function carregar() {
    try { const s = JSON.parse(localStorage.getItem(STORAGE) || 'null'); if (s) dados = Object.assign({}, dados, s); } catch (e) {}
    try {
        const user = JSON.parse(localStorage.getItem('user') || 'null');
        if (user) {
            dados.eu.nome = user.nome || dados.eu.nome;
            dados.eu.uid = user.uid || null;
            if (user.foto) dados.eu.avatarFoto = user.foto;
            if (user.email) dados.eu.link = 'communitynews.app/@' + user.email.split('@')[0];
        }
    } catch (e) {}
}
function carregarSeg() { try { const s = JSON.parse(localStorage.getItem(STORAGE_SEG) || 'null'); if (s) seg = Object.assign({}, seg, s); } catch (e) {} }
function todosItens() { return dados.grupos.concat(dados.comunidades, dados.contatos); }

const PLANOS_VIP = {
    base:   { nome:'Base',    valor:4,  desc:'Apenas 2 usos — sem recarga.' },
    senior: { nome:'Sênior',  valor:8,  desc:'Recarregue quando quiser.' },
    pro:    { nome:'Pro',     valor:12, desc:'Tudo liberado, sem limites.' }
};

function aplicarMascaraData(input) {
    input.addEventListener('input', () => {
        let v = input.value.replace(/\D/g, '').slice(0, 8);
        let out = '';
        if (v.length > 0) out = v.slice(0, 2);
        if (v.length >= 3) out += '/' + v.slice(2, 4);
        if (v.length >= 5) out += '/' + v.slice(4, 8);
        input.value = out;
        if (out.length === 10) {
            const ok = validarDataNascimento(out, false);
            input.classList.toggle('ok', ok);
            input.classList.toggle('erro', !ok);
        } else {
            input.classList.remove('ok','erro');
            const err = $('aviso-idade'); if (err) err.classList.remove('ativo');
            const suc = $('sucesso-idade'); if (suc) suc.classList.remove('ativo');
        }
    });
}

function parseDataBR(str) {
    if (!/^\d{2}\/\d{2}\/\d{4}$/.test(str)) return null;
    const [d, m, a] = str.split('/').map(Number);
    if (d < 1 || d > 31 || m < 1 || m > 12 || a < 1900 || a > new Date().getFullYear()) return null;
    const dt = new Date(a, m - 1, d);
    if (dt.getFullYear() !== a || dt.getMonth() !== m - 1 || dt.getDate() !== d) return null;
    return dt;
}

function calcularIdade(dt) {
    const hoje = new Date();
    let idade = hoje.getFullYear() - dt.getFullYear();
    const m = hoje.getMonth() - dt.getMonth();
    if (m < 0 || (m === 0 && hoje.getDate() < dt.getDate())) idade--;
    return idade;
}

function validarDataNascimento(str, mostrarUI) {
    const err = $('aviso-idade');
    const errTxt = $('aviso-idade-txt');
    const suc = $('sucesso-idade');
    const dt = parseDataBR(str);
    if (!dt) {
        if (mostrarUI !== false) {
            const t = TRADUCOES[idiomaAtual] || TRADUCOES.pt;
            if (errTxt) errTxt.textContent = t['vip.idade.erro'];
            if (err) err.classList.add('ativo');
            if (suc) suc.classList.remove('ativo');
        }
        return false;
    }
    const idade = calcularIdade(dt);
    if (idade < 16 || idade > 120) {
        if (mostrarUI !== false) {
            if (err) err.classList.add('ativo');
            if (suc) suc.classList.remove('ativo');
        }
        return false;
    }
    if (mostrarUI !== false) {
        if (err) err.classList.remove('ativo');
        if (suc) suc.classList.add('ativo');
    }
    return true;
}

function validarIdade() {
    const inp = $('data-nascimento');
    if (!inp) return false;
    if (!inp.value.trim()) {
        $('aviso-idade')?.classList.add('ativo');
        $('sucesso-idade')?.classList.remove('ativo');
        return false;
    }
    return validarDataNascimento(inp.value.trim(), true);
}

function abrirModalAssinatura(planoKey) {
    const plano = PLANOS_VIP[planoKey];
    if (!plano) return;
    $('titulo-plano').textContent = (TRADUCOES[idiomaAtual]['assinatura.titulo'] || 'Assinatura — Plano') + ' ' + plano.nome;
    $('mensagem-plano').innerHTML = '<b>' + plano.nome + '</b> — <b>R$ ' + plano.valor.toFixed(2) + '</b><br><span style="opacity:.8;font-size:.9rem">' + plano.desc + '</span>';
    const prazo = new Date(Date.now() + 3 * 24 * 60 * 60 * 1000);
    atualizarContadorPrazo(prazo);
    abrirModal('modal-assinatura');
    $('botao-cancelar-assinatura').onclick = () => fecharModal('modal-assinatura');
    $('modal-assinatura').dataset.plano = planoKey;
}

let prazoTimer = null;
function atualizarContadorPrazo(dataAlvo) {
    if (prazoTimer) clearInterval(prazoTimer);
    const el = $('contador-prazo');
    if (!el) return;
    function tick() {
        const diff = dataAlvo.getTime() - Date.now();
        if (diff <= 0) { el.textContent = 'Expired'; return; }
        const d = Math.floor(diff / 86400000);
        const h = Math.floor((diff % 86400000) / 3600000);
        const m = Math.floor((diff % 3600000) / 60000);
        const s = Math.floor((diff % 60000) / 1000);
        const f = n => String(n).padStart(2, '0');
        el.textContent = d + 'd, ' + f(h) + ':' + f(m) + ':' + f(s);
    }
    tick();
    prazoTimer = setInterval(tick, 1000);
}

function confirmarAssinatura(planoKey) {
    const plano = PLANOS_VIP[planoKey];
    if (!plano) return;
    vip.plano = planoKey;
    vip.expiraEm = Date.now() + 30 * 24 * 60 * 60 * 1000;
    if (planoKey === 'base') { vip.usosRestantes = 2; vip.recarregavel = false; }
    else { vip.usosRestantes = -1; vip.recarregavel = true; }
    salvarVip();
    fecharModal('modal-assinatura');
    snack('👑 ' + plano.nome + ' VIP');
    anunciar('Plano ' + plano.nome + ' ativado com sucesso');
}

function configurarVip() {
    const inpData = $('data-nascimento');
    if (inpData) {
        aplicarMascaraData(inpData);
        inpData.addEventListener('blur', () => { if (inpData.value.trim().length > 0) validarDataNascimento(inpData.value.trim(), true); });
        inpData.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); validarDataNascimento(inpData.value.trim(), true); } });
    }
    $$('.btn-vip-assinar').forEach(btn => {
        btn.addEventListener('click', () => {
            if (!validarIdade()) { snack('⚠️ Verifique sua data'); return; }
            const plano = btn.dataset.plano;
            if (!plano) return;
            abrirModalAssinatura(plano);
        });
    });
    document.addEventListener('click', (e) => {
        const link = e.target.closest('#modal-assinatura a[href*="nubank"]');
        if (link) {
            const planoKey = $('modal-assinatura').dataset.plano;
            setTimeout(() => { if (planoKey) confirmarAssinatura(planoKey); }, 400);
        }
    });
}

function existeBackup() { try { return !!localStorage.getItem(STORAGE_BACKUP); } catch (e) { return false; } }
function salvarBackup() {
    try {
        const backup = { eu: JSON.parse(JSON.stringify(dados.eu)), salvoEm: Date.now() };
        localStorage.setItem(STORAGE_BACKUP, JSON.stringify(backup));
        return true;
    } catch (e) { return false; }
}
function lerBackup() { try { const b = JSON.parse(localStorage.getItem(STORAGE_BACKUP) || 'null'); return b && b.eu ? b : null; } catch (e) { return null; } }
function atualizarInfoBackup() {
    const el = $('perfil-backup-info');
    if (!el) return;
    el.classList.toggle('ativo', existeBackup());
    const btnRest = $('restaurar-perfil');
    if (btnRest) btnRest.disabled = !existeBackup();
}
function apagarPerfilAgora() {
    dados.eu = { nome:'Você', avatarId:'user', avatarFoto:null, cor:'#3b82f6', bio:'', frase:'', interesses:[], capa:null, link:'communitynews.app/@voce', uid:null };
    salvar();
    try { localStorage.removeItem(STORAGE_ONB); } catch (e) {}
    fecharModal('modal-apagar-perfil');
    onb.passo = 1; onb.nome = ''; onb.avatarId = 'user';
    onb.avatarFoto = null; onb.cor = '#3b82f6';
    onb.bio = ''; onb.frase = ''; onb.interesses = [];
    mostrarAba('inicio');
    snack('🗑️ Perfil apagado');
    anunciar('Perfil apagado. Iniciando novo cadastro.');
    setTimeout(() => { abrirOnboarding(); }, 400);
}
function restaurarPerfilDoBackup() {
    const b = lerBackup();
    if (!b) { snack('⚠️ Nenhum backup encontrado'); return; }
    dados.eu = Object.assign({}, dados.eu, b.eu);
    salvar();
    marcarOnboardingCompleto();
    fecharModal('modal-apagar-perfil');
    atualizarPerfil();
    atualizarBoasVindas();
    snack('🔄 Perfil restaurado');
    anunciar('Perfil restaurado com sucesso');
}

function configurarApagarPerfil() {
    atualizarInfoBackup();
    $('btn-apagar-perfil')?.addEventListener('click', () => { atualizarInfoBackup(); abrirModal('modal-apagar-perfil'); });
    $('cancelar-apagar')?.addEventListener('click', () => { fecharModal('modal-apagar-perfil'); });
    $('guardar-perfil')?.addEventListener('click', () => { if (salvarBackup()) { atualizarInfoBackup(); snack('💾 Perfil guardado'); } else snack('⚠️ Falha ao guardar'); });
    $('restaurar-perfil')?.addEventListener('click', () => { if (!existeBackup()) { snack('⚠️ Nenhum backup'); return; } restaurarPerfilDoBackup(); });
    $('confirmar-apagar')?.addEventListener('click', () => { if (!confirm('Confirmar apagamento definitivo?')) return; apagarPerfilAgora(); });
}

let themeChannel = null;
try { themeChannel = new BroadcastChannel('community-theme-sync'); } catch (e) {}

function aplicarTema(nome, propagar) {
    if (!nome || TEMAS_LIBERADOS.indexOf(nome) === -1) nome = 'padrao';
    document.documentElement.setAttribute('data-tema', nome);
    document.body.setAttribute('data-tema', nome);
    $$('.tema-btn').forEach(b => {
        const ativo = b.dataset.tema === nome;
        b.classList.toggle('ativo', ativo);
        if (b.hasAttribute('role')) b.setAttribute('aria-checked', ativo ? 'true' : 'false');
    });
    try { localStorage.setItem(STORAGE_TEMA, nome); } catch (e) {}
    if (propagar !== false && themeChannel) {
        try { themeChannel.postMessage({ tema: nome, ts: Date.now() }); } catch (e) {}
    }
}
function carregarTemaSalvo() {
    let t = 'padrao';
    try { const s = localStorage.getItem(STORAGE_TEMA); if (s && TEMAS_LIBERADOS.indexOf(s) !== -1) t = s; } catch (e) {}
    aplicarTema(t, false);
}
function configurarSyncTema() {
    window.addEventListener('storage', (e) => {
        if (e.key === STORAGE_TEMA && e.newValue && TEMAS_LIBERADOS.indexOf(e.newValue) !== -1) {
            aplicarTema(e.newValue, false);
        }
    });
    if (themeChannel) {
        themeChannel.addEventListener('message', (e) => {
            if (e.data && e.data.tema && TEMAS_LIBERADOS.indexOf(e.data.tema) !== -1) {
                aplicarTema(e.data.tema, false);
            }
        });
    }
}
function configurarTemas() {
    $$('.tema-btn').forEach(b => {
        b.addEventListener('click', () => {
            const nome = b.dataset.tema; if (!nome) return;
            if (nome === 'halloween' && TEMAS_LIBERADOS.indexOf('halloween') === -1) { snack('🎃 Bloqueado'); return; }
            aplicarTema(nome);
            const labels = { escuro:'🌙 Tema escuro ativado', padrao:'🎨 Tema padrão ativado', claro:'☀️ Tema claro ativado' };
            snack(labels[nome] || '');
            anunciar(labels[nome] || '');
        });
    });
}

function onboardingCompleto() { try { return localStorage.getItem(STORAGE_ONB) === '1'; } catch (e) { return false; } }
function marcarOnboardingCompleto() { try { localStorage.setItem(STORAGE_ONB, '1'); } catch (e) {} }

const ONB_NOMES_KEYS = { 1: 'onb.apelido', 2: 'onb.avatar', 3: 'onb.personalizar' };

function renderAvGrid() {
    const wrap = $('onb-avs'); if (!wrap) return;
    wrap.innerHTML = AVATARES.map(a =>
        '<button type="button" class="onb-av-op" data-avid="' + a.id + '" style="background:' + a.cor + '" role="radio" aria-checked="false" aria-label="' + a.label + '">' +
            '<i class="fas ' + a.ic + '" aria-hidden="true"></i>' +
        '</button>'
    ).join('');
    wrap.querySelectorAll('.onb-av-op').forEach(op => {
        op.addEventListener('click', () => {
            wrap.querySelectorAll('.onb-av-op').forEach(x => { x.classList.remove('ativo'); x.setAttribute('aria-checked', 'false'); });
            op.classList.add('ativo');
            op.setAttribute('aria-checked', 'true');
            onb.avatarId = op.dataset.avid;
            onb.avatarFoto = null;
            const upBtn = $('onb-upload-btn');
            if (upBtn) upBtn.classList.remove('tem-foto');
            const tit = $('onb-upload-titulo');
            if (tit) tit.textContent = (TRADUCOES[idiomaAtual]['onb.p2.upload_tit']);
            const sub = $('onb-upload-sub');
            if (sub) sub.textContent = (TRADUCOES[idiomaAtual]['onb.p2.upload_sub']);
            renderOnbPreview();
        });
    });
    const inicial = wrap.querySelector('[data-avid="' + onb.avatarId + '"]');
    if (inicial) { inicial.classList.add('ativo'); inicial.setAttribute('aria-checked', 'true'); }
}

function renderOnbPreview() {
    const cx = $('onb-cx');
    if (cx) cx.setAttribute('data-cor-prev', onb.cor);
    const pn = $('onb-prev-nome'), pb = $('onb-prev-bio'), pa = $('onb-prev-av'), lg = $('onb-logo'), tags = $('onb-prev-tags');
    if (pn) pn.textContent = onb.nome.trim() || TRADUCOES[idiomaAtual]['onb.seu_apelido'];
    if (pb) pb.textContent = onb.bio.trim() || TRADUCOES[idiomaAtual]['onb.sem_bio'];
    function renderAvatarInto(el) {
        if (!el) return;
        if (onb.avatarFoto) { el.innerHTML = '<img src="' + onb.avatarFoto + '" alt="">'; el.style.background = '#222'; }
        else {
            const av = obterAvatar(onb.avatarId);
            el.innerHTML = '<i class="fas ' + av.ic + '" aria-hidden="true"></i>';
            el.style.background = av.cor;
        }
    }
    renderAvatarInto(pa); renderAvatarInto(lg);
    if (tags) tags.innerHTML = onb.interesses.length ? onb.interesses.map(t => '<span class="onb-prev-tag">' + escapeHtml(t) + '</span>').join('') : '';
}

function irPasso(p, direcao) {
    if (p < 1 || p > onb.totalPassos) return;
    const atual = document.querySelector('.onb-passo.ativo');
    const alvo = document.querySelector('.onb-passo[data-passo="' + p + '"]');
    if (!alvo) return;
    if (!direcao) direcao = p > onb.passo ? 'proximo' : 'voltar';
    onb.passo = p;
    if (atual && atual !== alvo) atual.classList.remove('ativo');
    alvo.classList.add('ativo');
    $$('.onb-pstep').forEach(el => {
        const n = Number(el.dataset.step);
        el.classList.toggle('ativo', n === p);
        el.classList.toggle('completo', n < p);
        el.setAttribute('aria-selected', n === p ? 'true' : 'false');
    });
    const fill = $('onb-progress-fill');
    if (fill) fill.style.width = ((p - 1) / (onb.totalPassos - 1)) * 100 + '%';
    const barraAria = $('onb-progress-bar');
    if (barraAria) barraAria.setAttribute('aria-valuenow', p);
    const atualEl = $('onb-passo-atual');
    if (atualEl) atualEl.textContent = p;
    const nomeEl = $('onb-passo-nome');
    if (nomeEl) nomeEl.textContent = TRADUCOES[idiomaAtual][ONB_NOMES_KEYS[p]] || '';
    const footer = $('onb-footer');
    if (footer) footer.classList.toggle('hidden', p === 3);
    const voltar = $('onb-voltar');
    if (voltar) voltar.style.display = p > 1 ? 'inline-flex' : 'none';
    const err = $('onb-erro-' + p); if (err) err.textContent = '';
    const onbTela = $('onb-tela');
    if (onbTela) onbTela.scrollTo({ top: 0, behavior: 'smooth' });
    if (p === 1) setTimeout(() => { $('onb-nome')?.focus(); }, 300);
    anunciar((TRADUCOES[idiomaAtual]['onb.passo'] || 'Passo') + ' ' + p + ': ' + (TRADUCOES[idiomaAtual][ONB_NOMES_KEYS[p]] || ''));
}

function validarPasso(p) {
    if (p === 1) {
        const nome = $('onb-nome').value.trim();
        if (nome.length < 3) { $('onb-erro-1').textContent = '⚠️ O apelido precisa ter pelo menos 3 caracteres.'; $('onb-nome').setAttribute('aria-invalid', 'true'); return false; }
        if (nome.length > 20) { $('onb-erro-1').textContent = '⚠️ O apelido pode ter no máximo 20 caracteres.'; $('onb-nome').setAttribute('aria-invalid', 'true'); return false; }
        $('onb-nome').removeAttribute('aria-invalid');
        onb.nome = nome;
        return true;
    }
    if (p === 2) return true;
    if (p === 3) {
        onb.cor = onb.cor || '#3b82f6';
        onb.bio = $('onb-bio').value.trim().slice(0, 120);
        onb.frase = $('onb-frase').value.trim().slice(0, 50);
        return true;
    }
    return true;
}

function proxPasso() {
    if (!validarPasso(onb.passo)) { anunciar($('onb-erro-' + onb.passo).textContent); return; }
    if (onb.passo < onb.totalPassos) irPasso(onb.passo + 1, 'proximo');
    else concluirOnboarding();
}
function passoAnterior() { if (onb.passo > 1) irPasso(onb.passo - 1, 'voltar'); }

function concluirOnboarding() {
    dados.eu.nome = onb.nome.trim() || 'Você';
    dados.eu.avatarId = onb.avatarId;
    dados.eu.avatarFoto = onb.avatarFoto;
    dados.eu.cor = onb.cor;
    dados.eu.bio = onb.bio;
    dados.eu.frase = onb.frase;
    dados.eu.interesses = onb.interesses.slice();
    dados.eu.link = 'communitynews.app/@' + (onb.nome.trim().toLowerCase().replace(/[^a-z0-9_]/g, '_') || 'voce');
    salvar();
    marcarOnboardingCompleto();
    $('onb-tela').classList.remove('ativo');
    document.body.style.overflow = '';
    mostrarLoading(() => {
        atualizarPerfil();
        atualizarBoasVindas();
        atualizarInfoBackup();
        if (seg.pinHash && seg.pedirAoAbrir) setTimeout(() => mostrarLock(), 500);
        anunciar('Perfil criado com sucesso!');
    });
}

function configurarOnboarding() {
    renderAvGrid();
    const inpNome = $('onb-nome'), contNome = $('onb-nome-cont');
    if (inpNome) {
        inpNome.value = dados.eu.nome && dados.eu.nome !== 'Você' ? dados.eu.nome : '';
        onb.nome = inpNome.value;
        if (contNome) contNome.textContent = inpNome.value.length;
        inpNome.addEventListener('input', () => { onb.nome = inpNome.value.trim(); if (contNome) contNome.textContent = inpNome.value.length; renderOnbPreview(); $('onb-erro-1').textContent = ''; inpNome.removeAttribute('aria-invalid'); });
        inpNome.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); proxPasso(); } });
    }
    const upBtn = $('onb-upload-btn'), upInput = $('onb-foto');
    if (upBtn && upInput) {
        upBtn.addEventListener('click', () => upInput.click());
        upInput.addEventListener('change', (e) => {
            const f = e.target.files[0]; if (!f) return;
            if (!f.type.startsWith('image/')) return;
            if (f.size > 5242880) return;
            const r = new FileReader();
            r.onload = (ev) => {
                onb.avatarFoto = ev.target.result;
                $$('#onb-avs .onb-av-op').forEach(x => { x.classList.remove('ativo'); x.setAttribute('aria-checked', 'false'); });
                upBtn.classList.add('tem-foto');
                const sub = $('onb-upload-sub');
                if (sub) sub.textContent = f.name.length > 30 ? f.name.slice(0, 27) + '...' : f.name;
                renderOnbPreview();
            };
            r.readAsDataURL(f);
        });
    }
    $$('.onb-cor').forEach(c => c.addEventListener('click', () => {
        $$('.onb-cor').forEach(x => { x.classList.remove('ativo'); x.setAttribute('aria-checked', 'false'); });
        c.classList.add('ativo');
        c.setAttribute('aria-checked', 'true');
        onb.cor = c.dataset.cor;
        renderOnbPreview();
    }));
    const bioEl = $('onb-bio'), bioCont = $('onb-bio-cont');
    if (bioEl) bioEl.addEventListener('input', () => { onb.bio = bioEl.value.trim().slice(0, 120); if (bioCont) bioCont.textContent = bioEl.value.length; renderOnbPreview(); });
    const fraseEl = $('onb-frase'), fraseCont = $('onb-frase-cont');
    if (fraseEl) fraseEl.addEventListener('input', () => { onb.frase = fraseEl.value.trim().slice(0, 50); if (fraseCont) fraseCont.textContent = fraseEl.value.length; });
    $$('.onb-chip').forEach(chip => chip.addEventListener('click', () => {
        const tag = chip.dataset.tag;
        const idx = onb.interesses.indexOf(tag);
        if (idx >= 0) { onb.interesses.splice(idx, 1); chip.classList.remove('ativo'); chip.setAttribute('aria-pressed', 'false'); }
        else { onb.interesses.push(tag); chip.classList.add('ativo'); chip.setAttribute('aria-pressed', 'true'); }
        renderOnbPreview();
    }));
    $$('.onb-pstep').forEach(el => el.addEventListener('click', () => {
        const alvo = Number(el.dataset.step);
        if (alvo === onb.passo) return;
        if (alvo > onb.passo) for (let i = onb.passo; i < alvo; i++) { if (!validarPasso(i)) return; }
        irPasso(alvo, alvo > onb.passo ? 'proximo' : 'voltar');
    }));
    $('onb-proximo')?.addEventListener('click', proxPasso);
    $('onb-voltar')?.addEventListener('click', passoAnterior);
    $('onb-btn-criar')?.addEventListener('click', () => {
        if (!validarPasso(1)) { irPasso(1, 'voltar'); return; }
        validarPasso(2); validarPasso(3); concluirOnboarding();
    });
}

function abrirOnboarding() {
    irPasso(1); renderOnbPreview();
    $('onb-tela').classList.add('ativo');
    document.body.style.overflow = 'hidden';
    setTimeout(() => { const tela = $('onb-tela'); if (tela) tela.scrollTo({ top: 0, behavior: 'auto' }); $('onb-nome')?.focus(); }, 100);
}

function mostrarLoading(callback) {
    const tela = $('tela-carregamento');
    const barra = $('preenchimento');
    const txt = $('texto-carregando');
    const barraAria = $('barra-carr-aria');
    if (!tela || !barra || !txt) { if (callback) callback(); return; }
    tela.classList.remove('escondido');
    tela.style.display = 'grid';
    barra.style.width = '0%';
    txt.textContent = TRADUCOES[idiomaAtual]['loading.txt'];
    const frases = ['loading.f1','loading.f2','loading.f3','loading.f4','loading.f5'];
    let p = 0, idx = 0;
    const DURACAO_TOTAL = 1200;
    const INTERVALO = 100;
    const INCREMENTO = 100 / (DURACAO_TOTAL / INTERVALO);
    const inicio = Date.now();
    const t = setInterval(() => {
        p = Math.min(p + INCREMENTO, 100);
        barra.style.width = p.toFixed(2) + '%';
        if (barraAria) barraAria.setAttribute('aria-valuenow', Math.round(p));
        const novoIdx = Math.min(Math.floor((p / 100) * frases.length), frases.length - 1);
        if (novoIdx !== idx) { idx = novoIdx; txt.textContent = (TRADUCOES[idiomaAtual][frases[idx]] || txt.textContent); }
        if (p >= 100) {
            clearInterval(t);
            const esperar = Math.max(0, DURACAO_TOTAL - (Date.now() - inicio));
            setTimeout(() => { tela.classList.add('escondido'); setTimeout(() => { tela.style.display = 'none'; }, 500); if (callback) callback(); }, esperar + 300);
        }
    }, INTERVALO);
}

let snackTimer = null;
function snack(txt) {
    if (!EL.snackbar) EL.snackbar = $('snackbar'); if (!EL.snackbar) return;
    if (seg.modoDiscreto) return;
    EL.snackbar.textContent = txt;
    EL.snackbar.classList.add('ativo');
    clearTimeout(snackTimer);
    snackTimer = setTimeout(() => EL.snackbar.classList.remove('ativo'), 2200);
}
let toastTimer = null;
function mostrarToast(titulo, texto) {
    if (!EL.toast) EL.toast = $('toast'); if (!EL.toast) return;
    $('toast-titulo').textContent = titulo;
    $('toast-texto').textContent = seg.ocultarPrevia ? '••••••••••' : texto;
    EL.toast.classList.add('ativo');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => EL.toast.classList.remove('ativo'), 2800);
}

async function hashPin(pin) {
    try {
        const enc = new TextEncoder();
        const buf = await crypto.subtle.digest('SHA-256', enc.encode(pin + '::community::cn_v1'));
        return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2,'0')).join('');
    } catch (e) {
        let h = 5381; const s = pin + '::community::cn_v1';
        for (let i = 0; i < s.length; i++) h = ((h*33) ^ s.charCodeAt(i)) >>> 0;
        return 'fb_' + h.toString(16);
    }
}
function segLog(tipo, msg) { seg.log.unshift({ tipo, msg, ts: Date.now() }); if (seg.log.length > 40) seg.log.length = 40; }
function horaCurta(ts) { const d = new Date(ts); return d.toLocaleDateString() + ' ' + d.toLocaleTimeString('pt-BR', { hour:'2-digit', minute:'2-digit' }); }

let pinResolve = null, pinBuffer = '', pinMinLen = 4, pinAutoOkLen = 6;
function renderPinDots() { const box = $('pin-dots'); if (!box) return; let html = ''; for (let i = 0; i < pinBuffer.length; i++) html += '<span class="pin-dot on"></span>'; for (let i = pinBuffer.length; i < 6; i++) html += '<span class="pin-dot"></span>'; box.innerHTML = html; box.setAttribute('aria-label', pinBuffer.length + ' de 6 dígitos inseridos'); }
function pedirPin(opts) {
    opts = opts || {}; pinMinLen = opts.minLen || 4; pinBuffer = '';
    $('pin-titulo').textContent = opts.titulo || TRADUCOES[idiomaAtual]['pin.titulo'];
    $('pin-sub').textContent = opts.sub || TRADUCOES[idiomaAtual]['pin.sub'];
    $('pin-erro').textContent = '';
    const ic = $('pin-h-icon'); if (ic) ic.innerHTML = '<i class="fas ' + (opts.icone || 'fa-lock') + '"></i>';
    renderPinDots(); abrirModal('modal-pin');
    return new Promise(resolve => { pinResolve = resolve; });
}
function fecharPinModal(resultado) { const r = pinResolve; pinResolve = null; fecharModal('modal-pin'); pinBuffer = ''; if (r) r(resultado); }
function pinTecla(k) {
    if (k === 'del') { pinBuffer = pinBuffer.slice(0, -1); renderPinDots(); $('pin-erro').textContent = ''; return; }
    if (k === 'ok') { if (pinBuffer.length < pinMinLen) { $('pin-erro').textContent = '⚠️ Senha muito curta'; return; } fecharPinModal(pinBuffer); return; }
    if (/^[0-9]$/.test(k) && pinBuffer.length < 6) { pinBuffer += k; renderPinDots(); $('pin-erro').textContent = ''; if (pinBuffer.length === pinAutoOkLen) setTimeout(() => { if (pinResolve) fecharPinModal(pinBuffer); }, 100); }
}
function configurarPinModal() {
    const pad = $('pin-pad');
    if (pad) pad.addEventListener('click', (e) => { const b = e.target.closest('.pin-key'); if (!b) return; pinTecla(b.dataset.pk); });
    $('pin-fechar')?.addEventListener('click', () => fecharPinModal(null));
    document.addEventListener('keydown', (e) => {
        if ($('modal-pin')?.classList.contains('ativo')) {
            if (/^[0-9]$/.test(e.key)) pinTecla(e.key);
            else if (e.key === 'Backspace') pinTecla('del');
            else if (e.key === 'Enter') pinTecla('ok');
            else if (e.key === 'Escape') fecharPinModal(null);
        }
    });
}
async function criarSenha() {
    const novo = await pedirPin({ titulo:'🔑 Criar senha', icone:'fa-key' }); if (!novo) return;
    const conf = await pedirPin({ titulo:'🔑 Confirme a senha', icone:'fa-check' }); if (!conf) return;
    if (novo !== conf) { snack('❌ Senhas diferentes'); anunciar('As senhas não coincidem'); return; }
    seg.pinHash = await hashPin(novo); seg.pedirAoAbrir = true;
    segLog('pin_criado', 'PIN'); salvarSeg(); atualizarUISeg(); snack('🔒 Senha criada');
    anunciar('Senha criada com sucesso');
}
async function alterarSenha() {
    const atual = await pedirPin({ titulo:'🔓 Senha atual', icone:'fa-unlock' }); if (!atual) return;
    const hash = await hashPin(atual);
    if (hash !== seg.pinHash) { segLog('pin_falha', 'fail'); salvarSeg(); snack('❌ Senha incorreta'); return; }
    const novo = await pedirPin({ titulo:'🔑 Nova senha', icone:'fa-key' }); if (!novo) return;
    const conf = await pedirPin({ titulo:'🔑 Confirme', icone:'fa-check' }); if (!conf) return;
    if (novo !== conf) { snack('❌ Senhas diferentes'); return; }
    seg.pinHash = await hashPin(novo); segLog('pin_alterado', 'PIN'); salvarSeg(); atualizarUISeg(); snack('🔐 Senha alterada');
    anunciar('Senha alterada com sucesso');
}
async function removerSenha() {
    const atual = await pedirPin({ titulo:'🔓 Confirme a senha', icone:'fa-unlock' }); if (!atual) return;
    const hash = await hashPin(atual);
    if (hash !== seg.pinHash) { segLog('pin_falha', 'fail'); salvarSeg(); snack('❌ Senha incorreta'); return; }
    seg.pinHash = null; seg.pedirAoAbrir = false; seg.bloquearAoSair = false;
    segLog('pin_removido', 'off'); salvarSeg(); atualizarUISeg(); snack('🔓 Senha removida');
    anunciar('Senha removida');
}

let lockBuffer = '';
function renderLockDots() { const box = $('lock-dots'); if (!box) return; let html = ''; for (let i = 0; i < lockBuffer.length; i++) html += '<span class="pin-dot on"></span>'; for (let i = lockBuffer.length; i < 6; i++) html += '<span class="pin-dot"></span>'; box.innerHTML = html; box.setAttribute('aria-label', lockBuffer.length + ' de 6 dígitos inseridos'); }
function mostrarLock() { if (!seg.pinHash) return; lockBuffer = ''; $('lock-erro').textContent = ''; renderLockDots(); $('lock-tela').classList.add('ativo'); document.body.style.overflow = 'hidden'; setTimeout(() => $('lock-pad')?.querySelector('button')?.focus(), 100); }
function esconderLock() { $('lock-tela').classList.remove('ativo'); document.body.style.overflow = ''; resetAutoLock(); }
async function tentarDesbloquear() {
    if (!seg.pinHash) return;
    if (lockBuffer.length < 4) return;
    const hash = await hashPin(lockBuffer);
    if (hash === seg.pinHash) { segLog('desbloqueio_ok', 'ok'); salvarSeg(); esconderLock(); anunciar('Desbloqueado'); return; }
    if (lockBuffer.length >= 6) {
        $('lock-erro').textContent = '❌ Senha incorreta'; segLog('desbloqueio_falha', 'fail'); salvarSeg();
        anunciar('Senha incorreta');
        lockBuffer = ''; setTimeout(renderLockDots, 200);
    }
}
function lockTecla(k) {
    if (k === 'del') { lockBuffer = lockBuffer.slice(0, -1); renderLockDots(); return; }
    if (k === 'ok') { tentarDesbloquear(); return; }
    if (/^[0-9]$/.test(k) && lockBuffer.length < 6) { lockBuffer += k; renderLockDots(); $('lock-erro').textContent = ''; tentarDesbloquear(); }
}
function configurarLock() {
    const pad = $('lock-pad');
    if (pad) pad.addEventListener('click', (e) => { const b = e.target.closest('.pin-key'); if (!b) return; lockTecla(b.dataset.lk); });
    $('lock-esqueci')?.addEventListener('click', async () => {
        if (!confirm('Tem certeza que deseja remover a senha?')) return;
        if (!confirm('Confirma novamente? A senha será apagada.')) return;
        seg.pinHash = null; seg.pedirAoAbrir = false; seg.bloquearAoSair = false;
        segLog('pin_removido', 'off'); salvarSeg(); esconderLock(); atualizarUISeg();
    });
    document.addEventListener('keydown', (e) => {
        if (!$('lock-tela').classList.contains('ativo')) return;
        if (/^[0-9]$/.test(e.key)) lockTecla(e.key);
        else if (e.key === 'Backspace') lockTecla('del');
        else if (e.key === 'Enter') lockTecla('ok');
    });
}

let autoLockTimer = null;
function resetAutoLock() {
    if (autoLockTimer) { clearTimeout(autoLockTimer); autoLockTimer = null; }
    if (!seg.pinHash || !seg.pedirAoAbrir) return;
    if (seg.bloqueioAuto <= 0) return;
    autoLockTimer = setTimeout(() => { if ($('lock-tela').classList.contains('ativo')) return; mostrarLock(); }, seg.bloqueioAuto * 60000);
}
function configurarAutoLock() {
    ['click','keypress','touchstart','scroll'].forEach(ev => document.addEventListener(ev, () => { if (!$('lock-tela').classList.contains('ativo')) resetAutoLock(); }, { passive: true }));
    let saiu = false;
    document.addEventListener('visibilitychange', () => {
        if (document.hidden) { if (seg.pinHash && seg.bloquearAoSair) saiu = true; }
        else { if (saiu) { saiu = false; if (!$('lock-tela').classList.contains('ativo')) mostrarLock(); } else resetAutoLock(); }
    });
    resetAutoLock();
}

function atualizarUISeg() {
    const temSenha = !!seg.pinHash;
    const t = TRADUCOES[idiomaAtual];
    const badge = $('badge-seg-status'), segBtn = $('side-seguranca');
    if (badge) badge.textContent = temSenha ? 'ATIVO' : t['seg.sem_senha'];
    if (segBtn) segBtn.classList.toggle('sem-pin', !temSenha);
    const card = $('seg-status-card'), icone = $('seg-status-icone'), tit = $('seg-status-titulo'), sub = $('seg-status-sub');
    if (card && tit && sub && icone) {
        if (temSenha) { card.classList.add('protegido'); icone.className = 'fas fa-lock'; tit.textContent = t['seg.senha'] + ' ativa'; sub.textContent = 'Sua conta está protegida'; }
        else { card.classList.remove('protegido'); icone.className = 'fas fa-lock-open'; tit.textContent = t['seg.sem_senha']; sub.textContent = 'Sua conta está desprotegida'; }
    }
    const box = $('seg-acoes-pin');
    if (box) {
        if (!temSenha) {
            box.innerHTML = '<button class="btn-liquido verde bloco" id="seg-btn-criar"><span><i class="fas fa-key" aria-hidden="true"></i> Criar senha</span></button>';
            $('seg-btn-criar').addEventListener('click', criarSenha, { passive: true });
        } else {
            box.innerHTML = '<button class="btn-liquido ciano bloco" id="seg-btn-alterar"><span><i class="fas fa-pen" aria-hidden="true"></i> Alterar senha</span></button>' +
                            '<button class="btn-liquido danger bloco" id="seg-btn-remover"><span><i class="fas fa-trash" aria-hidden="true"></i> Remover senha</span></button>';
            $('seg-btn-alterar').addEventListener('click', alterarSenha, { passive: true });
            $('seg-btn-remover').addEventListener('click', removerSenha, { passive: true });
        }
    }
    const op = $('seg-opcoes-pin');
    if (op) {
        if (!temSenha) op.innerHTML = '<div class="seg-vazio"><i class="fas fa-info-circle" aria-hidden="true"></i><p>Crie uma senha para ativar as opções avançadas.</p></div>';
        else op.innerHTML =
            '<div class="seg-op"><i class="fas fa-door-open" aria-hidden="true"></i><div><strong>Pedir ao abrir</strong><small>Solicita senha ao iniciar</small></div><button class="seg-toggle' + (seg.pedirAoAbrir ? ' on' : '') + '" data-toggle="pedirAoAbrir" role="switch" aria-checked="' + (seg.pedirAoAbrir ? 'true' : 'false') + '" aria-label="Pedir senha ao abrir"></button></div>' +
            '<div class="seg-op"><i class="fas fa-right-from-bracket" aria-hidden="true"></i><div><strong>Bloquear ao sair</strong><small>Ao trocar de aba</small></div><button class="seg-toggle' + (seg.bloquearAoSair ? ' on' : '') + '" data-toggle="bloquearAoSair" role="switch" aria-checked="' + (seg.bloquearAoSair ? 'true' : 'false') + '" aria-label="Bloquear ao sair"></button></div>' +
            '<div class="seg-op"><i class="fas fa-clock" aria-hidden="true"></i><div><strong>Auto bloqueio</strong><small>Após inatividade</small></div><label class="sr-only" for="seg-select-auto">Tempo de auto bloqueio</label><select class="seg-select" id="seg-select-auto">' +
                '<option value="0"' + (seg.bloqueioAuto === 0 ? ' selected' : '') + '>Nunca</option>' +
                '<option value="1"' + (seg.bloqueioAuto === 1 ? ' selected' : '') + '>1 min</option>' +
                '<option value="5"' + (seg.bloqueioAuto === 5 ? ' selected' : '') + '>5 min</option>' +
                '<option value="15"' + (seg.bloqueioAuto === 15 ? ' selected' : '') + '>15 min</option>' +
                '<option value="30"' + (seg.bloqueioAuto === 30 ? ' selected' : '') + '>30 min</option>' +
            '</select></div>';
    }
    $$('.seg-toggle').forEach(tg => { const k = tg.dataset.toggle; if (!k) return; tg.classList.toggle('on', !!seg[k]); tg.setAttribute('aria-checked', seg[k] ? 'true' : 'false'); });
    renderSessoes(); renderLog();
}

function renderSessoes() {
    const box = $('seg-sessoes-lista'); if (!box) return;
    const ua = navigator.userAgent;
    let device = 'Dispositivo', ico = 'fa-mobile-screen';
    if (/Android/i.test(ua)) device = 'Android';
    else if (/iPhone|iPad|iPod/i.test(ua)) device = 'iPhone / iPad';
    else if (/Windows/i.test(ua)) { device = 'Windows'; ico = 'fa-desktop'; }
    else if (/Macintosh|Mac OS/i.test(ua)) { device = 'Mac'; ico = 'fa-desktop'; }
    let nav = 'Navegador';
    if (/Chrome/i.test(ua) && !/Edg/i.test(ua)) nav = 'Chrome';
    else if (/Firefox/i.test(ua)) nav = 'Firefox';
    else if (/Safari/i.test(ua) && !/Chrome/i.test(ua)) nav = 'Safari';
    else if (/Edg/i.test(ua)) nav = 'Edge';
    box.innerHTML = '<div class="seg-sessao atual"><i class="ico fas ' + ico + '" aria-hidden="true"></i><div><strong>' + device + '</strong><small>' + nav + ' — atual</small></div></div>';
}

function renderLog() {
    const box = $('seg-log-lista'); if (!box) return;
    if (!seg.log.length) { box.innerHTML = '<div class="seg-vazio"><i class="fas fa-info-circle" aria-hidden="true"></i><p>Nenhum evento registrado.</p></div>'; return; }
    const icons = { pin_criado:'fa-key', pin_alterado:'fa-key', pin_removido:'fa-lock-open', desbloqueio_ok:'fa-unlock', desbloqueio_falha:'fa-triangle-exclamation', pin_falha:'fa-triangle-exclamation' };
    box.innerHTML = seg.log.map(e => {
        const ic = icons[e.tipo] || 'fa-circle-info';
        return '<div class="seg-log-item"><i class="fas ' + ic + '" aria-hidden="true"></i><div><strong>' + escapeHtml(e.msg) + '</strong><small>' + horaCurta(e.ts) + '</small></div></div>';
    }).join('');
}

function configurarSegurancaModal() {
    $$('.seg-tab').forEach(t => t.addEventListener('click', () => {
        const alvo = t.dataset.segTab;
        $$('.seg-tab').forEach(x => {
            const ativo = x.dataset.segTab === alvo;
            x.classList.toggle('ativo', ativo);
            x.setAttribute('aria-selected', ativo ? 'true' : 'false');
        });
        $$('.seg-painel').forEach(p => p.classList.toggle('ativo', p.dataset.segPainel === alvo));
    }));
    document.addEventListener('click', (e) => {
        const t = e.target.closest('.seg-toggle'); if (!t) return;
        const k = t.dataset.toggle; if (!k || !(k in seg)) return;
        e.stopPropagation();
        seg[k] = !seg[k];
        t.classList.toggle('on', !!seg[k]);
        t.setAttribute('aria-checked', seg[k] ? 'true' : 'false');
        salvarSeg();
        if (k === 'pedirAoAbrir' || k === 'bloqueioAuto') resetAutoLock();
    });
    document.addEventListener('change', (e) => { if (e.target.id === 'seg-select-auto') { seg.bloqueioAuto = parseInt(e.target.value) || 0; salvarSeg(); resetAutoLock(); } });
    $('seg-encerrar-outras')?.addEventListener('click', () => { if (!confirm('Encerrar todas as outras sessões?')) return; segLog('sessao_encerrada', 'X'); salvarSeg(); renderLog(); });
    $('seg-limpar-log')?.addEventListener('click', () => { if (!confirm('Limpar histórico?')) return; seg.log = []; salvarSeg(); renderLog(); });
    $('side-seguranca')?.addEventListener('click', () => {
        abrirModal('modal-seguranca');
        $('sidebar')?.classList.remove('aberta');
        const ov = $('overlay-sidebar'); if (ov) { ov.classList.remove('ativo'); ov.hidden = true; }
        $('btn-hamburger')?.setAttribute('aria-expanded', 'false');
        document.body.style.overflow = '';
        atualizarUISeg();
    });
}

function iniciarContador() {
    const d = $('dias'), h = $('horas'), m = $('minutos'), s = $('segundos'); if (!d) return;
    const DATA = new Date('2026-10-16T00:00:00').getTime();
    const fmt = n => n < 10 ? '0' + n : '' + n;
    function tick() {
        const diff = DATA - Date.now();
        if (diff <= 0) { d.textContent = h.textContent = m.textContent = s.textContent = '00'; return; }
        d.textContent = fmt(Math.floor(diff / 86400000));
        h.textContent = fmt(Math.floor((diff % 86400000) / 3600000));
        m.textContent = fmt(Math.floor((diff % 3600000) / 60000));
        s.textContent = fmt(Math.floor((diff % 60000) / 1000));
    }
    tick(); setInterval(tick, 1000);
}

function atualizarBolaAlvo(item) {
    if (!EL.nav || !EL.navBola || !item) return;
    const ir = item.getBoundingClientRect();
    const nr = EL.nav.getBoundingClientRect();
    if (!ir.width || !nr.width) return;
    const tam = Math.max(ir.width, ir.height) * 0.96;
    EL.navBola.style.left = ((ir.left - nr.left) + (ir.width - tam) / 2) + 'px';
    EL.navBola.style.top = ((ir.top - nr.top) + (ir.height - tam) / 2) + 'px';
    EL.navBola.style.width = tam + 'px';
    EL.navBola.style.height = tam + 'px';
}
function configurarNav() {
    EL.nav = $('nav-liquida'); if (!EL.nav) return;
    EL.navBola = $('nav-bola');
    $$('.nav-item[data-nav]', EL.nav).forEach(b => b.addEventListener('click', () => mostrarAba(b.dataset.nav)));
    requestAnimationFrame(() => { const at = EL.nav.querySelector('.nav-item.ativo'); if (at) atualizarBolaAlvo(at); });
    window.addEventListener('resize', () => { const at = EL.nav.querySelector('.nav-item.ativo'); if (at) atualizarBolaAlvo(at); }, { passive: true });
}
function mostrarAba(nome) {
    if (!nome) return;
    $$('.conteudo-aba').forEach(a => { a.classList.remove('visivel'); a.hidden = true; });
    const alvo = $('aba-' + nome);
    if (alvo) {
        alvo.classList.add('visivel');
        alvo.hidden = false;
        alvo.focus({ preventScroll: true });
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
    $$('.nav-item[data-nav]').forEach(i => {
        const ativo = i.dataset.nav === nome;
        i.classList.toggle('ativo', ativo);
        if (ativo) i.setAttribute('aria-current', 'page');
        else i.removeAttribute('aria-current');
    });
    $$('.sidebar-item[data-ir]').forEach(i => {
        const ativo = i.dataset.ir === nome;
        i.classList.toggle('ativo', ativo);
        if (ativo) i.setAttribute('aria-current', 'page');
        else i.removeAttribute('aria-current');
    });
    const item = document.querySelector('.nav-item[data-nav="' + nome + '"]');
    if (item) atualizarBolaAlvo(item);
    if (nome === 'perfil') { atualizarPerfil(); atualizarInfoBackup(); }
    setTimeout(injetarEfeitosBrilho, 120);
}

function configurarSidebar() {
    const btn = $('btn-hamburger'), sidebar = $('sidebar'), overlay = $('overlay-sidebar'), fechar = $('sidebar-fechar');
    if (!btn || !sidebar || !overlay) return;
    EL.sidebar = sidebar;
    let aberto = false;
    function set(v) {
        aberto = v;
        sidebar.classList.toggle('aberta', v);
        overlay.classList.toggle('ativo', v);
        overlay.hidden = !v;
        sidebar.setAttribute('aria-hidden', v ? 'false' : 'true');
        btn.setAttribute('aria-expanded', v ? 'true' : 'false');
        EL.body.style.overflow = v ? 'hidden' : '';
        if (v) { const f = sidebar.querySelector('button, a'); f?.focus(); }
    }
    btn.addEventListener('click', () => set(!aberto));
    fechar?.addEventListener('click', () => { set(false); btn.focus(); });
    overlay.addEventListener('click', () => { set(false); btn.focus(); });
    $$('.sidebar-item[data-ir]').forEach(i => i.addEventListener('click', () => { mostrarAba(i.dataset.ir); setTimeout(() => set(false), 100); }));
    $$('[data-ir-btn]').forEach(b => b.addEventListener('click', () => mostrarAba(b.dataset.irBtn)));
    $('side-feedback')?.addEventListener('click', () => { abrirModal('modal-feedback'); setTimeout(() => set(false), 180); });
    $('side-info')?.addEventListener('click', () => { abrirModal('modal-info-app'); setTimeout(() => set(false), 180); });
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && aberto) { set(false); btn.focus(); } });
}

let ultimoFocoAntesModal = null;
function abrirModal(id) {
    const m = $(id); if (!m) return;
    ultimoFocoAntesModal = document.activeElement;
    m.classList.add('ativo');
    setTimeout(() => { const f = m.querySelector('input, button, [tabindex]:not([tabindex="-1"])'); f?.focus(); }, 80);
    setTimeout(injetarEfeitosBrilho, 50);
}
function fecharModal(id) {
    const m = $(id); if (!m) return;
    m.classList.remove('ativo');
    if (ultimoFocoAntesModal && typeof ultimoFocoAntesModal.focus === 'function') ultimoFocoAntesModal.focus();
    ultimoFocoAntesModal = null;
}
function fecharTodosModais() { $$('.modal').forEach(m => { m.classList.remove('ativo'); }); }
function configurarModais() {
    $$('[data-fechar]').forEach(b => b.addEventListener('click', () => { b.closest('.modal')?.classList.remove('ativo'); }));
    $$('.modal').forEach(m => m.addEventListener('click', (e) => { if (e.target === m) m.classList.remove('ativo'); }));
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            fecharTodosModais();
            $('sheet-criar')?.classList.remove('ativo');
            $('btn-criar-central')?.classList.remove('ativo');
        }
    });
}

function configurarSheet() {
    const btn = $('btn-criar-central'); if (!btn) return;
    btn.addEventListener('click', () => {
        const s = $('sheet-criar'); if (!s) return;
        const ativo = s.classList.toggle('ativo');
        btn.classList.toggle('ativo', ativo);
        btn.setAttribute('aria-expanded', ativo ? 'true' : 'false');
    });
    $('fechar-sheet')?.addEventListener('click', () => {
        $('sheet-criar')?.classList.remove('ativo');
        btn.classList.remove('ativo');
        btn.setAttribute('aria-expanded', 'false');
    });
    $$('.sheet-o').forEach(o => o.addEventListener('click', () => {
        const t = o.dataset.criar;
        $('sheet-criar')?.classList.remove('ativo');
        btn.classList.remove('ativo');
        btn.setAttribute('aria-expanded', 'false');
        if (t === 'grupo') abrirModal('modal-grupo');
        else if (t === 'comunidade') abrirModal('modal-comunidade');
        else if (t === 'link') abrirModal('modal-link');
        else if (t === 'contato') abrirModal('modal-contato');
    }));
}

let grupoAv = '🐻';
function configurarCriarGrupo() {
    $$('#grupo-avs .avatar-op').forEach(a => a.addEventListener('click', () => {
        $$('#grupo-avs .avatar-op').forEach(x => { x.classList.remove('ativo'); x.setAttribute('aria-checked', 'false'); });
        a.classList.add('ativo'); a.setAttribute('aria-checked', 'true');
        grupoAv = a.dataset.av;
    }));
    $('criar-grupo-btn')?.addEventListener('click', () => {
        const nome = $('grupo-nome').value.trim(); if (!nome) { snack('⚠️ Informe um nome'); return; }
        const id = gerarId();
        dados.grupos.push({ id, tipo:'grupo', nome, avatar:grupoAv, link:'communitynews.app/join/' + id, desc: $('grupo-desc').value.trim() || 'Grupo', membros:[{ nome:dados.eu.nome, uid:dados.eu.uid, admin:true }], admins:[dados.eu.nome], dono:dados.eu.nome, cor:dados.eu.cor, capa:null, mensagens:[] });
        salvar(); fecharModal('modal-grupo'); $('grupo-nome').value=''; $('grupo-desc').value='';
        atualizarListaContatos(); atualizarSideGrupos(); snack('✅ Grupo criado'); anunciar('Grupo ' + nome + ' criado');
    });
}
let comuAv = '🌐';
function configurarCriarComunidade() {
    $$('#comu-avs .avatar-op').forEach(a => a.addEventListener('click', () => {
        $$('#comu-avs .avatar-op').forEach(x => { x.classList.remove('ativo'); x.setAttribute('aria-checked', 'false'); });
        a.classList.add('ativo'); a.setAttribute('aria-checked', 'true');
        comuAv = a.dataset.av;
    }));
    $('criar-comu-btn')?.addEventListener('click', () => {
        const nome = $('comu-nome').value.trim(); if (!nome) { snack('⚠️ Informe um nome'); return; }
        const id = gerarId();
        dados.comunidades.push({ id, tipo:'comunidade', nome, avatar:comuAv, link:'communitynews.app/c/' + id, desc: $('comu-desc').value.trim() || 'Comunidade', membros:[{ nome:dados.eu.nome, uid:dados.eu.uid, admin:true }], admins:[dados.eu.nome], dono:dados.eu.nome, cor:dados.eu.cor, capa:null, mensagens:[] });
        salvar(); fecharModal('modal-comunidade'); $('comu-nome').value=''; $('comu-desc').value='';
        atualizarListaContatos(); snack('✅ Comunidade criada');
    });
}
function configurarEntrarLink() {
    $('entrar-link-btn')?.addEventListener('click', () => {
        const link = $('input-link').value.trim(); if (!link) { snack('⚠️ Cole um link'); return; }
        const todos = dados.grupos.concat(dados.comunidades);
        const achou = todos.find(x => x.link === link || link.indexOf(x.id) !== -1);
        if (achou) {
            if (!achou.membros.some(m => (m.nome || m) === dados.eu.nome)) achou.membros.push({ nome:dados.eu.nome, uid:dados.eu.uid, admin:false });
            salvar(); fecharModal('modal-link'); $('input-link').value=''; atualizarListaContatos(); snack('✅ Você entrou');
        } else snack('❌ Link inválido');
    });
}
function configurarCriarContato() {
    $('criar-contato-btn')?.addEventListener('click', () => {
        const nome = $('contato-nome').value.trim(); if (!nome) { snack('⚠️ Informe um nome'); return; }
        const id = gerarId();
        dados.contatos.push({ id, tipo:'contato', nome, avatar:'👤', link:null, desc:'', membros:[{ nome:dados.eu.nome, uid:dados.eu.uid }], cor:dados.eu.cor, capa:null, mensagens:[] });
        salvar(); fecharModal('modal-contato'); $('contato-nome').value='';
        atualizarListaContatos(); abrirConversa(id); snack('✅ Conversa criada');
    });
}

function atualizarListaContatos(filtro) {
    const wrap = $('chat-contatos'); if (!wrap) return;
    filtro = filtro || '';
    const lf = filtro.toLowerCase();
    const lista = todosItens().filter(x => x.nome.toLowerCase().indexOf(lf) !== -1);
    if (lista.length === 0) {
        wrap.innerHTML = '<div style="padding:2rem 1rem;text-align:center;color:var(--texto-secundario);font-size:.85rem"><i class="fas fa-inbox" aria-hidden="true" style="font-size:2rem;display:block;margin-bottom:.75rem;opacity:.4"></i>Nenhuma conversa</div>';
        return;
    }
    const frag = document.createDocumentFragment();
    const ativoId = dados.ativo;
    lista.forEach(c => {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'chat-ctt' + (ativoId === c.id ? ' ativo' : '');
        btn.setAttribute('role', 'listitem');
        btn.setAttribute('aria-current', ativoId === c.id ? 'true' : 'false');
        const msgs = c.mensagens;
        const ult = msgs.length ? msgs[msgs.length-1] : null;
        let txt = 'Sem mensagens';
        if (ult) {
            if (ult.tipo === 'imagem') txt = '📷 Imagem';
            else if (ult.tipo === 'audio') txt = '🎤 Áudio';
            else if (ult.tipo === 'arquivo') txt = '📎 Arquivo';
            else if (ult.tipo === 'chamada') txt = '📞 Chamada';
            else txt = ult.texto || '';
        }
        const hora = ult ? new Date(ult.ts).toLocaleTimeString('pt-BR', { hour:'2-digit', minute:'2-digit' }) : '';
        const isGrupo = c.tipo !== 'contato';
        let avHtml = '';
        if (isGrupo) avHtml = '<span aria-hidden="true">' + (c.avatar || '👥') + '</span>';
        else avHtml = c.avatarId ? '<i class="fas ' + obterAvatar(c.avatarId).ic + '" aria-hidden="true"></i>' : '<span aria-hidden="true">👤</span>';
        btn.innerHTML = '<div class="chat-av ' + (isGrupo ? 'grupo' : '') + '">' + avHtml + '</div><div class="chat-info"><strong>' + escapeHtml(c.nome) + '</strong><small>' + escapeHtml(txt.slice(0,40)) + '</small></div><div class="chat-m"><small>' + hora + '</small></div>';
        btn.addEventListener('click', () => abrirConversa(c.id));
        frag.appendChild(btn);
    });
    wrap.innerHTML = '';
    wrap.appendChild(frag);
}

function atualizarSideGrupos() {
    const wrap = $('side-grupos'); if (!wrap) return;
    wrap.innerHTML = '';
    const frag = document.createDocumentFragment();
    dados.grupos.concat(dados.comunidades).forEach(g => {
        const b = document.createElement('button');
        b.className = 'sidebar-item btn-liquido';
        b.innerHTML = '<span aria-hidden="true">' + (g.avatar || '👥') + '</span><span>' + escapeHtml(g.nome) + '</span>';
        b.addEventListener('click', () => { mostrarAba('chat'); setTimeout(() => abrirConversa(g.id), 120); });
        frag.appendChild(b);
    });
    wrap.appendChild(frag);
}

function abrirConversa(id) {
    const c = todosItens().find(x => x.id === id); if (!c) return;
    dados.ativo = id; salvar();
    $('chat-vazio').style.display = 'none';
    $('chat-ativo').style.display = 'flex';
    const av = $('conv-av');
    if (c.tipo !== 'contato') { av.innerHTML = c.avatar || '👥'; av.className = 'chat-av grupo'; }
    else { av.innerHTML = c.avatarId ? '<i class="fas ' + obterAvatar(c.avatarId).ic + '"></i>' : '👤'; av.className = 'chat-av'; }
    $('conv-nome').textContent = c.nome;
    $('conv-status').textContent = c.tipo === 'contato' ? 'online' : c.membros.length + ' membros';
    renderMensagens();
    $('chat-app').classList.add('conv-aberta');
    atualizarListaContatos($('busca-conv').value);
    atualizarBtnSilenciar();
    anunciar('Conversa aberta: ' + c.nome);
}

function renderMensagens() {
    const wrap = $('chat-msgs'); if (!wrap) return;
    const c = todosItens().find(x => x.id === dados.ativo); if (!c) return;
    if (c.mensagens.length === 0) { wrap.innerHTML = '<div class="chat-vazio" style="padding:2rem"><i class="fas fa-comment-dots" aria-hidden="true" style="font-size:2rem"></i><p>Nenhuma mensagem ainda</p></div>'; return; }
    const frag = document.createDocumentFragment();
    const hoje = new Date().toLocaleDateString('pt-BR');
    let ultimaData = '';
    c.mensagens.forEach(m => {
        const data = new Date(m.ts).toLocaleDateString('pt-BR');
        if (data !== ultimaData) { ultimaData = data; const d = document.createElement('div'); d.className = 'chat-data'; d.innerHTML = '<span>' + (data === hoje ? 'Hoje' : data) + '</span>'; frag.appendChild(d); }
        if (m.autor === 'sistema') { const b = document.createElement('div'); b.className = 'balao sis'; b.textContent = m.texto; frag.appendChild(b); return; }
        const eu = m.autor === 'eu';
        const b = document.createElement('div');
        b.className = 'balao ' + (eu ? 'eu' : 'outro');
        b.dataset.id = m.id;
        const hora = new Date(m.ts).toLocaleTimeString('pt-BR', { hour:'2-digit', minute:'2-digit' });
        let conteudo = '';
        if (m.tipo === 'imagem' && m.url) conteudo = '<img src="' + m.url + '" alt="Imagem enviada" loading="lazy" data-lb="' + m.url + '">';
        else if (m.tipo === 'audio' && m.url) conteudo = '<audio controls src="' + m.url + '" preload="none"></audio>';
        else if (m.tipo === 'video' && m.url) conteudo = '<video controls src="' + m.url + '" preload="none"></video>';
        else if (m.tipo === 'arquivo' && m.url) conteudo = '<a class="balao-arquivo" href="' + m.url + '" download="' + escapeHtml(m.nomeArquivo || 'arquivo') + '" target="_blank" rel="noopener"><i class="fas fa-file" aria-hidden="true"></i><div><div class="nome">' + escapeHtml(m.nomeArquivo || 'arquivo') + '</div><div class="tam">' + (m.tamanho ? formatarTamanho(m.tamanho) : '') + '</div></div></a>';
        else if (m.tipo === 'chamada') conteudo = '<i class="fas fa-phone" aria-hidden="true"></i> ' + escapeHtml(m.texto || '');
        else conteudo = escapeHtml(m.texto || '');
        let html = '';
        if (!eu && c.tipo !== 'contato') html += '<div class="balao-autor">' + escapeHtml(m.nome || 'Membro') + '</div>';
        html += '<div class="balao-txt">' + conteudo + '</div>';
        html += '<div class="balao-info">' + (m.editado ? '<span class="editado">editado</span>' : '') + '<span>' + hora + '</span>' + (eu ? '<i class="fas fa-check-double" aria-hidden="true"></i>' : '') + '</div>';
        if (eu) html += '<div class="balao-menu"><button class="bt-edit" aria-label="Editar mensagem"><i class="fas fa-pen" aria-hidden="true"></i></button><button class="bt-del" aria-label="Apagar mensagem"><i class="fas fa-trash" aria-hidden="true"></i></button></div>';
        b.innerHTML = html;
        if (eu) {
            b.querySelector('.bt-edit')?.addEventListener('click', (e) => { e.stopPropagation(); editarMensagem(c.id, m.id); });
            b.querySelector('.bt-del')?.addEventListener('click', (e) => { e.stopPropagation(); apagarMensagem(c.id, m.id); });
        }
        frag.appendChild(b);
    });
    wrap.innerHTML = '';
    wrap.appendChild(frag);
    wrap.scrollTop = wrap.scrollHeight;
}

function editarMensagem(chatId, msgId) {
    const c = todosItens().find(x => x.id === chatId); if (!c) return;
    const m = c.mensagens.find(x => x.id === msgId); if (!m) return;
    const novo = prompt('Editar mensagem:', m.texto); if (novo === null) return;
    m.texto = novo.trim(); m.editado = true; m.ts = Date.now();
    salvar(); renderMensagens();
}
function apagarMensagem(chatId, msgId) {
    const c = todosItens().find(x => x.id === chatId); if (!c) return;
    const idx = c.mensagens.findIndex(x => x.id === msgId);
    if (idx >= 0) { c.mensagens.splice(idx, 1); salvar(); renderMensagens(); }
}

function enviarMensagem() {
    const inp = $('input-msg');
    const txt = inp.value.trim();
    if (!txt || !dados.ativo) return;
    const c = todosItens().find(x => x.id === dados.ativo); if (!c) return;
    c.mensagens.push({ id:gerarId(), texto:txt, autor:'eu', nome:dados.eu.nome, ts:Date.now(), tipo:'texto' });
    inp.value = ''; inp.style.height = 'auto';
    salvar(); renderMensagens(); atualizarListaContatos($('busca-conv').value);
}

function ligarUploads() {
    $('btn-anexo-img')?.addEventListener('click', () => $('file-img').click());
    $('btn-anexo-arquivo')?.addEventListener('click', () => $('file-geral').click());
    $('file-img')?.addEventListener('change', async (e) => {
        const file = e.target.files[0]; if (!file) return;
        if (file.size > 10485760) { snack('⚠️ Arquivo muito grande'); return; }
        const c = todosItens().find(x => x.id === dados.ativo); if (!c) return;
        const url = await base64(file);
        c.mensagens.push({ id:gerarId(), tipo:'imagem', url, autor:'eu', nome:dados.eu.nome, ts:Date.now() });
        salvar(); renderMensagens(); atualizarListaContatos($('busca-conv').value);
        e.target.value = '';
    });
    $('file-geral')?.addEventListener('change', async (e) => {
        const file = e.target.files[0]; if (!file) return;
        const c = todosItens().find(x => x.id === dados.ativo); if (!c) return;
        const upEl = $('upload-progress');
        $('up-nome').textContent = file.name;
        $('up-barra').style.width = '0%'; $('up-pct').textContent = '0%';
        upEl.classList.add('ativo');
        for (let i = 0; i < 5; i++) { await new Promise(r => setTimeout(r, 40)); const pct = Math.round(((i+1)/5)*100); $('up-barra').style.width = pct + '%'; $('up-pct').textContent = pct + '%'; }
        const url = await base64(file);
        c.mensagens.push({ id:gerarId(), tipo:'arquivo', url, nomeArquivo:file.name, tamanho:file.size, autor:'eu', nome:dados.eu.nome, ts:Date.now() });
        salvar(); renderMensagens(); atualizarListaContatos($('busca-conv').value);
        upEl.classList.remove('ativo'); e.target.value = '';
    });
    $('up-cancelar')?.addEventListener('click', () => { $('upload-progress').classList.remove('ativo'); });
}

let mediaRecorder = null, audioChunks = [], gravandoTimer = null, gravandoSegundos = 0;
function ligarAudio() {
    const btn = $('btn-microfone'); if (!btn) return;
    btn.addEventListener('click', async () => {
        const info = $('gravando-info');
        if (mediaRecorder && mediaRecorder.state === 'recording') { mediaRecorder.stop(); return; }
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            mediaRecorder = new MediaRecorder(stream);
            audioChunks = []; gravandoSegundos = 0;
            mediaRecorder.ondataavailable = (e) => { if (e.data.size > 0) audioChunks.push(e.data); };
            mediaRecorder.onstop = async () => {
                const blob = new Blob(audioChunks, { type: 'audio/webm' });
                const c = todosItens().find(x => x.id === dados.ativo);
                if (!c) { stream.getTracks().forEach(t => t.stop()); btn.classList.remove('gravando'); info.classList.remove('ativo'); clearInterval(gravandoTimer); return; }
                const url = await base64(blob);
                c.mensagens.push({ id:gerarId(), tipo:'audio', url, duracao:gravandoSegundos, autor:'eu', nome:dados.eu.nome, ts:Date.now() });
                salvar(); renderMensagens(); atualizarListaContatos($('busca-conv').value);
                stream.getTracks().forEach(t => t.stop());
                btn.classList.remove('gravando'); info.classList.remove('ativo'); clearInterval(gravandoTimer);
                btn.setAttribute('aria-label', 'Gravar áudio');
            };
            mediaRecorder.start();
            btn.classList.add('gravando');
            btn.setAttribute('aria-label', 'Parar gravação');
            info.classList.add('ativo');
            gravandoTimer = setInterval(() => { gravandoSegundos++; const min = Math.floor(gravandoSegundos / 60); const seg = String(gravandoSegundos % 60).padStart(2, '0'); $('gravando-tempo').textContent = min + ':' + seg; if (gravandoSegundos >= 60) mediaRecorder.stop(); }, 1000);
        } catch (e) { snack('⚠️ Microfone indisponível'); }
    });
}

let localStream = null, chamadaAtual = null;
async function iniciarChamada(tipo) {
    tipo = tipo || 'video';
    const c = todosItens().find(x => x.id === dados.ativo);
    if (!c) return;
    if (c.tipo === 'grupo' || c.tipo === 'comunidade') { snack('Chamadas individuais apenas'); return; }
    try { localStream = await navigator.mediaDevices.getUserMedia({ audio: true, video: tipo === 'video' ? { width: 1280, height: 720 } : false }); } catch (e) { snack('⚠️ Permissões necessárias'); return; }
    $('chamada-tela').classList.add('ativo');
    $('chamada-nome').textContent = c.nome;
    $('chamada-status').textContent = '✓';
    $('video-local').srcObject = localStream;
    if (tipo !== 'video') $('video-local').style.display = 'none';
    chamadaAtual = { id:gerarId(), contato:c.id, tipo, iniciada:Date.now() };
    anunciar('Chamada iniciada com ' + c.nome);
}
function encerrarChamada() {
    if (localStream) { localStream.getTracks().forEach(t => t.stop()); localStream = null; }
    $('chamada-tela').classList.remove('ativo');
    $('video-local').srcObject = null;
    $('video-remoto').srcObject = null;
    if (chamadaAtual && dados.ativo) {
        const c = todosItens().find(x => x.id === dados.ativo);
        if (c) { const dur = Math.round((Date.now() - chamadaAtual.iniciada) / 1000); c.mensagens.push({ id:gerarId(), tipo:'chamada', texto:'(' + dur + 's)', autor:'sistema', ts:Date.now() }); salvar(); renderMensagens(); }
    }
    chamadaAtual = null;
    anunciar('Chamada encerrada');
}
function ligarChamadas() {
    $('btn-chamada-voz')?.addEventListener('click', () => iniciarChamada('audio'));
    $('btn-chamada-video')?.addEventListener('click', () => iniciarChamada('video'));
    $('ch-encerrar')?.addEventListener('click', encerrarChamada);
    $('ch-mute')?.addEventListener('click', function () {
        if (!localStream) return;
        const t = localStream.getAudioTracks()[0]; if (!t) return;
        t.enabled = !t.enabled;
        this.classList.toggle('mudo', !t.enabled);
        this.setAttribute('aria-pressed', !t.enabled ? 'true' : 'false');
        this.innerHTML = t.enabled ? '<i class="fas fa-microphone" aria-hidden="true"></i>' : '<i class="fas fa-microphone-slash" aria-hidden="true"></i>';
    });
    $('ch-camera')?.addEventListener('click', function () {
        if (!localStream) return;
        const t = localStream.getVideoTracks()[0]; if (!t) return;
        t.enabled = !t.enabled;
        this.classList.toggle('mudo', !t.enabled);
        this.setAttribute('aria-pressed', !t.enabled ? 'true' : 'false');
    });
}

function atualizarBtnSilenciar() {
    const c = todosItens().find(x => x.id === dados.ativo);
    const btn = $('btn-silenciar'); if (!c || !btn) return;
    const mudo = c.silenciado === true;
    btn.classList.toggle('mudo', mudo);
    btn.setAttribute('aria-pressed', mudo ? 'true' : 'false');
    btn.querySelector('i').className = mudo ? 'fas fa-bell-slash' : 'fas fa-bell';
}
$('btn-silenciar')?.addEventListener('click', () => { const c = todosItens().find(x => x.id === dados.ativo); if (!c) return; c.silenciado = !c.silenciado; salvar(); atualizarBtnSilenciar(); });

const EMOJIS = {
    'A': ['😀','😃','😄','😁','😆','😅','🤣','😂','🙂','😉','😊','😍','🤩','😘','😋','😜','🤗','🤔','😐','😑','🙄','😏'],
    'B': ['👍','👎','👌','✌️','🤞','🤟','🤘','🤙','👈','👉','👆','👇','☝️','👋','✋','👏','🙌','🤝','🙏','💪','✊','👊'],
    'C': ['❤️','🧡','💛','💚','💙','💜','🖤','🤍','🤎','💔','💕','💞','💓','💗','💖','💘','💝'],
    'D': ['🎮','🕹️','🎯','🎲','🃏','🎰','🎳','🎨','🎭','🎬','🎤','🎧','🎼','🎵']
};
function renderEmojis() {
    const pan = $('emoji-pan'); if (!pan) return;
    let html = '';
    for (const g in EMOJIS) {
        if (!Object.prototype.hasOwnProperty.call(EMOJIS, g)) continue;
        html += '<div class="emoji-g"><div class="emoji-gt">' + g + '</div><div class="emoji-grid">';
        EMOJIS[g].forEach(e => { html += '<button type="button" class="emoji-i" data-e="' + e + '" aria-label="Emoji ' + e + '">' + e + '</button>'; });
        html += '</div></div>';
    }
    pan.innerHTML = html;
    pan.addEventListener('click', (e) => { const btn = e.target.closest('.emoji-i'); if (!btn) return; const inp = $('input-msg'); inp.value += btn.dataset.e; inp.focus(); });
}

let avatarPerfilSel = 'user';
let corPerfilSel = '#3b82f6';

function atualizarPerfil() {
    const eu = dados.eu;
    $('perfil-nome-txt').textContent = eu.nome;
    $('perfil-bio-txt').textContent = eu.bio || (TRADUCOES[idiomaAtual]['perfil.sem_bio']);
    const fraseEl = $('perfil-frase-txt');
    if (fraseEl) fraseEl.textContent = eu.frase ? '"' + eu.frase + '"' : '';
    const interEl = $('perfil-interesses');
    if (interEl) interEl.innerHTML = (eu.interesses || []).map(t => '<span class="perfil-tag">' + escapeHtml(t) + '</span>').join('');
    $('stat-g').textContent = dados.grupos.length;
    $('stat-c').textContent = dados.comunidades.length;
    $('stat-a').textContent = dados.contatos.length;
    $('link-pf-user').value = eu.link || 'communitynews.app/@voce';
    const av = $('perfil-av');
    if (eu.avatarFoto) { $('perfil-av-txt').innerHTML = '<img src="' + eu.avatarFoto + '" alt="Avatar" style="width:100%;height:100%;object-fit:cover">'; av.style.background = '#222'; }
    else { const a = obterAvatar(eu.avatarId || 'user'); $('perfil-av-txt').innerHTML = '<i class="fas ' + a.ic + '" aria-hidden="true"></i>'; av.style.background = a.cor; }
    const capa = $('perfil-capa');
    if (eu.capa) capa.style.background = "url('" + eu.capa + "') center/cover no-repeat";
    else capa.style.background = eu.cor || '#3b82f6';
}
function hslParaHex(h) {
    const s = 1, l = 0.5;
    const c = (1 - Math.abs(2*l - 1)) * s;
    const x = c * (1 - Math.abs(((h/60) % 2) - 1));
    const m = l - c/2;
    let r=0, g=0, b=0;
    if (h < 60) { r=c; g=x; } else if (h < 120) { r=x; g=c; }
    else if (h < 180) { g=c; b=x; } else if (h < 240) { g=x; b=c; }
    else if (h < 300) { r=x; b=c; } else { r=c; b=x; }
    const toHex = v => Math.round((v+m)*255).toString(16).padStart(2, '0');
    return '#' + toHex(r) + toHex(g) + toHex(b);
}
function renderEdAvs() {
    const wrap = $('ed-avs'); if (!wrap) return;
    wrap.innerHTML = AVATARES.map(a => '<button type="button" class="avatar-op" data-avid="' + a.id + '" style="background:' + a.cor + ';color:#fff" role="radio" aria-checked="false" aria-label="' + a.label + '"><i class="fas ' + a.ic + '" aria-hidden="true"></i></button>').join('');
    wrap.querySelectorAll('.avatar-op').forEach(op => op.addEventListener('click', () => {
        wrap.querySelectorAll('.avatar-op').forEach(x => { x.classList.remove('ativo'); x.setAttribute('aria-checked', 'false'); });
        op.classList.add('ativo');
        op.setAttribute('aria-checked', 'true');
        avatarPerfilSel = op.dataset.avid;
    }));
}
function configurarPerfil() {
    renderEdAvs();
    $('btn-editar-perfil')?.addEventListener('click', () => {
        $('ed-nome').value = dados.eu.nome;
        $('ed-bio').value = dados.eu.bio || '';
        corPerfilSel = dados.eu.cor || '#3b82f6';
        avatarPerfilSel = dados.eu.avatarId || 'user';
        $$('#ed-avs .avatar-op').forEach(a => {
            const ativo = a.dataset.avid === avatarPerfilSel;
            a.classList.toggle('ativo', ativo);
            a.setAttribute('aria-checked', ativo ? 'true' : 'false');
        });
        $$('#color-paleta .cor').forEach(c => {
            const ativo = c.dataset.cor === corPerfilSel;
            c.classList.toggle('ativo', ativo);
            c.setAttribute('aria-checked', ativo ? 'true' : 'false');
        });
        $('color-preview').textContent = corPerfilSel;
        $('color-preview').style.background = corPerfilSel;
        $('color-hex').value = corPerfilSel;
        abrirModal('modal-perfil');
    });
    $('color-slider')?.addEventListener('input', (e) => {
        const cor = hslParaHex(parseInt(e.target.value));
        corPerfilSel = cor;
        $('color-preview').textContent = cor;
        $('color-preview').style.background = cor;
        $('color-hex').value = cor;
        $$('#color-paleta .cor').forEach(c => c.classList.remove('ativo'));
    });
    $$('#color-paleta .cor').forEach(c => c.addEventListener('click', () => {
        $$('#color-paleta .cor').forEach(x => { x.classList.remove('ativo'); x.setAttribute('aria-checked', 'false'); });
        c.classList.add('ativo'); c.setAttribute('aria-checked', 'true');
        corPerfilSel = c.dataset.cor;
        $('color-preview').textContent = corPerfilSel;
        $('color-preview').style.background = corPerfilSel;
        $('color-hex').value = corPerfilSel;
    }));
    $('color-hex')?.addEventListener('input', (e) => {
        const v = e.target.value;
        if (/^#[0-9a-fA-F]{6}$/.test(v)) {
            corPerfilSel = v;
            $('color-preview').textContent = v;
            $('color-preview').style.background = v;
        }
    });
    $('salvar-perfil-btn')?.addEventListener('click', () => {
        dados.eu.nome = $('ed-nome').value.trim() || 'Você';
        dados.eu.bio = $('ed-bio').value.trim();
        dados.eu.avatarId = avatarPerfilSel;
        dados.eu.avatarFoto = null;
        dados.eu.cor = corPerfilSel;
        salvar(); fecharModal('modal-perfil'); atualizarPerfil(); atualizarBoasVindas();
        anunciar('Perfil atualizado');
    });
    $('btn-trocar-capa')?.addEventListener('click', () => {
        const inp = document.createElement('input');
        inp.type = 'file'; inp.accept = 'image/*';
        inp.addEventListener('change', (e) => {
            const f = e.target.files[0]; if (!f) return;
            const r = new FileReader();
            r.onload = (ev) => { dados.eu.capa = ev.target.result; salvar(); atualizarPerfil(); };
            r.readAsDataURL(f);
        });
        inp.click();
    });
    $('btn-trocar-av')?.addEventListener('click', () => {
        const inp = document.createElement('input');
        inp.type = 'file'; inp.accept = 'image/*';
        inp.addEventListener('change', (e) => {
            const f = e.target.files[0]; if (!f) return;
            const r = new FileReader();
            r.onload = (ev) => { dados.eu.avatarFoto = ev.target.result; salvar(); atualizarPerfil(); };
            r.readAsDataURL(f);
        });
        inp.click();
    });
    $('copiar-link-pf')?.addEventListener('click', () => {
        const inp = $('link-pf-user');
        inp.select();
        try { navigator.clipboard.writeText(inp.value); snack('📋 Link copiado'); anunciar('Link copiado'); } catch (e) { document.execCommand('copy'); }
    });
    $('btn-compartilhar-perfil')?.addEventListener('click', () => {
        if (navigator.share) navigator.share({ title: 'Community News', text: 'Meu perfil', url: dados.eu.link }).catch(() => {});
        else snack('📋 Compartilhamento indisponível');
    });
    $('conv-info-click')?.addEventListener('click', abrirInfoGrupo);
    $('conv-info-click')?.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); abrirInfoGrupo(); } });
    $('conv-opcoes')?.addEventListener('click', abrirInfoGrupo);
}
function atualizarBoasVindas() {
    const el = $('boas-vindas-txt'); if (!el) return;
    const nome = (dados.eu.nome || '').trim();
    const t = TRADUCOES[idiomaAtual];
    el.textContent = nome && nome !== 'Você' ? t['home.bem_vindo'] + ' ' + nome : t['home.bem_vindo'];
}

function abrirInfoGrupo() {
    const c = todosItens().find(x => x.id === dados.ativo); if (!c) return;
    const ehGrupo = c.tipo !== 'contato';
    const body = $('info-corpo');
    $('info-titulo').textContent = c.nome;
    let html = '<div style="display:flex;gap:.75rem;align-items:center;margin-bottom:1rem"><div class="chat-av ' + (ehGrupo ? 'grupo' : '') + '" style="width:60px;height:60px;font-size:1.6rem" aria-hidden="true">' + (ehGrupo ? (c.avatar || '👥') : '👤') + '</div><div style="flex:1"><strong style="font-size:1.1rem;color:var(--azul)">' + escapeHtml(c.nome) + '</strong><p style="font-size:.84rem;color:var(--texto-secundario);margin:.2rem 0 0">' + escapeHtml(c.desc || '') + '</p></div></div>';
    if (ehGrupo && c.link) html += '<label for="lk-info">🔗 Link do grupo</label><div style="display:flex;gap:.4rem;margin-bottom:1rem"><input type="text" readonly value="' + c.link + '" id="lk-info" style="flex:1;padding:.65rem .9rem;border-radius:10px;border:1px solid var(--borda);background:var(--fundo-campo);color:var(--texto);font-family:monospace;font-size:.8rem"><button type="button" id="cp-link" class="btn-liquido ciano mini icon square" aria-label="Copiar link"><i class="fas fa-copy" aria-hidden="true"></i></button></div>';
    if (ehGrupo) {
        html += '<h4 style="margin-top:1rem">Membros (' + c.membros.length + ')</h4>';
        c.membros.forEach(m => {
            const nome = m.nome || m;
            const isAdmin = (c.admins || []).indexOf(nome) !== -1;
            const euMesmo = nome === dados.eu.nome;
            html += '<div style="display:flex;align-items:center;gap:.6rem;padding:.5rem;border-radius:10px;background:rgba(var(--azul-rgb),.05);margin-bottom:.25rem"><div class="chat-av" style="width:32px;height:32px;font-size:.9rem" aria-hidden="true">👤</div><span style="flex:1">' + escapeHtml(nome) + (isAdmin ? ' <span style="color:var(--azul);font-size:.72rem">(admin)</span>' : '') + '</span>';
            if ((c.admins || []).indexOf(dados.eu.nome) !== -1 && !euMesmo) html += '<button class="btn-liquido icon mini square act-admin" data-nome="' + escapeHtml(nome) + '" aria-label="Alternar admin"><i class="fas ' + (isAdmin ? 'fa-user-minus' : 'fa-user-shield') + '" aria-hidden="true"></i></button><button class="btn-liquido icon mini square act-ban" data-nome="' + escapeHtml(nome) + '" aria-label="Remover membro"><i class="fas fa-user-slash" aria-hidden="true"></i></button>';
            html += '</div>';
        });
    }
    body.innerHTML = html;
    body.querySelector('#cp-link')?.addEventListener('click', () => {
        const inp = body.querySelector('#lk-info');
        inp.select();
        try { navigator.clipboard.writeText(inp.value); snack('📋 Copiado'); } catch (e) { document.execCommand('copy'); }
    });
    body.querySelectorAll('.act-admin').forEach(b => b.addEventListener('click', () => { const nome = b.dataset.nome; c.admins = c.admins || []; const idx = c.admins.indexOf(nome); if (idx >= 0) c.admins.splice(idx, 1); else c.admins.push(nome); salvar(); abrirInfoGrupo(); renderMensagens(); }));
    body.querySelectorAll('.act-ban').forEach(b => b.addEventListener('click', () => { const nome = b.dataset.nome; c.membros = c.membros.filter(m => (m.nome || m) !== nome); c.admins = (c.admins || []).filter(a => a !== nome); salvar(); abrirInfoGrupo(); renderMensagens(); }));
    abrirModal('modal-info-grupo');
}

const JOGOS = [
    { img:'imagens/gta5.png', titulo:'GTA V', sub:'Rockstar • 2013', texto:'Los Santos.', link:'https://www.rockstargames.com/gta-v', btn:'ciano' },
    { img:'imagens/gta6.png', titulo:'GTA VI', sub:'Rockstar • 2025', texto:'Leonida.', link:'https://www.rockstargames.com/VI', btn:'azul' },
    { img:'imagens/eldenring.png', titulo:'Elden Ring', sub:'FromSoftware • 2022', texto:'RPG.', link:'https://en.bandainamcoent.eu/elden-ring/elden-ring', btn:'azul' },
    { img:'imagens/witcher3.png', titulo:'The Witcher 3', sub:'CD Projekt • 2015', texto:'Geralt.', link:'https://thewitcher.com/en/witcher3', btn:'ciano' },
    { img:'imagens/rdr2.png', titulo:'Red Dead 2', sub:'Rockstar • 2018', texto:'Van der Linde.', link:'https://www.rockstargames.com/reddeadredemption2', btn:'ciano' },
    { img:'imagens/mariokart8.png', titulo:'Mario Kart 8', sub:'Nintendo • 2017', texto:'Deluxe.', link:'https://www.nintendo.com/store/products/mario-kart-8-deluxe-switch/', btn:'azul' },
    { img:'imagens/dragonquest11.png', titulo:'Dragon Quest XI', sub:'Square Enix • 2017', texto:'RPG.', link:'https://dragonquest.square-enix-games.com/', btn:'azul' },
    { img:'imagens/nfsheat.png', titulo:'NFS Heat', sub:'Ghost/EA • 2019', texto:'Night race.', link:'https://www.ea.com/games/need-for-speed/need-for-speed-heat', btn:'ciano' },
    { img:'imagens/silenthill2.png', titulo:'Silent Hill 2', sub:'Konami • 2024', texto:'Remake.', link:'https://www.konami.com/games/silenthill/2remake/', btn:'azul' },
    { img:'imagens/fivenightsatfreddys.png', titulo:'FNAF', sub:'Scott Cawthon • 2014', texto:'Night.', link:'https://www.scottgames.com/', btn:'ciano' },
    { img:'imagens/poppyplaytime.png', titulo:'Poppy Playtime', sub:'MOB Games • 2021', texto:'Horror.', link:'https://www.poppyplaytime.com/', btn:'azul' },
    { img:'imagens/roblox.png', titulo:'Roblox', sub:'Roblox Corp • 2006', texto:'Platform.', link:'https://www.roblox.com/', btn:'ciano' }
];
const LOJAS = [
    { img:'imagens/steam.png', nome:'Steam', desc:'PC', link:'https://store.steampowered.com/', btn:'azul' },
    { img:'imagens/epicgames.png', nome:'Epic Games', desc:'Free', link:'https://store.epicgames.com/', btn:'ciano' },
    { img:'imagens/playstation.png', nome:'PlayStation', desc:'PS4/PS5', link:'https://store.playstation.com/', btn:'azul' },
    { img:'imagens/xbox.png', nome:'Xbox', desc:'Xbox', link:'https://www.xbox.com/pt-BR/', btn:'ciano' },
    { img:'imagens/nintendo.png', nome:'Nintendo', desc:'eShop', link:'https://www.nintendo.com/pt-br/store/', btn:'azul' },
    { img:'imagens/playstore.png', nome:'Google Play', desc:'Android', link:'https://play.google.com/store', btn:'ciano' },
    { img:'imagens/appstore.png', nome:'App Store', desc:'iPhone', link:'https://www.apple.com/app-store/', btn:'azul' },
    { img:'imagens/eaapp.png', nome:'EA App', desc:'EA', link:'https://www.ea.com/ea-app', btn:'ciano' },
    { img:'imagens/ubisoft.png', nome:'Ubisoft', desc:'Ubi', link:'https://store.ubi.com/', btn:'azul' }
];

let slideAtivo = 0;
function configurarSlide() {
    const trilho = $('trilho'), dotsBox = $('dots'); if (!trilho || !dotsBox) return;
    const slides = JOGOS.slice(0, 8);
    const frag = document.createDocumentFragment();
    slides.forEach((it, i) => {
        const b = document.createElement('button');
        b.type = 'button';
        b.className = 'cartao-slide';
        b.setAttribute('aria-label', 'Ver ' + it.titulo);
        b.innerHTML = '<img src="' + it.img + '" alt="Capa de ' + it.titulo + '" loading="lazy" onerror="this.src=\'imagens/logo.png\'"><span class="slide-info"><span class="slide-tag">Jogo</span><strong>' + it.titulo + '</strong></span>';
        b.addEventListener('click', () => selecionarSlide(i));
        frag.appendChild(b);
    });
    trilho.appendChild(frag);
    slides.forEach((it, i) => {
        const d = document.createElement('button');
        d.type = 'button';
        d.className = 'slide-dot' + (i === 0 ? ' on' : '');
        d.setAttribute('role', 'tab');
        d.setAttribute('aria-label', 'Slide ' + (i + 1) + ': ' + it.titulo);
        d.setAttribute('aria-selected', i === 0 ? 'true' : 'false');
        d.addEventListener('click', () => irSlide(i));
        dotsBox.appendChild(d);
    });
    let rafScroll = false;
    trilho.addEventListener('scroll', () => {
        if (rafScroll) return; rafScroll = true;
        requestAnimationFrame(() => {
            rafScroll = false;
            const centro = trilho.scrollLeft + trilho.clientWidth / 2;
            let melhor = 0, menor = Infinity;
            const kids = trilho.children;
            for (let i = 0; i < kids.length; i++) { const c = kids[i].offsetLeft + kids[i].offsetWidth / 2; const d = Math.abs(c - centro); if (d < menor) { menor = d; melhor = i; } }
            slideAtivo = melhor;
            const dots = dotsBox.children;
            for (let i = 0; i < dots.length; i++) {
                const on = i === melhor;
                dots[i].classList.toggle('on', on);
                dots[i].setAttribute('aria-selected', on ? 'true' : 'false');
            }
        });
    }, { passive: true });
    $('prevSlide')?.addEventListener('click', () => irSlide(Math.max(0, slideAtivo - 1)));
    $('nextSlide')?.addEventListener('click', () => irSlide(Math.min(slides.length - 1, slideAtivo + 1)));
}
function irSlide(i) { const t = $('trilho'); if (!t) return; const c = t.children[i]; if (!c) return; const a = c.offsetLeft - (t.clientWidth - c.offsetWidth) / 2; t.scrollTo({ left: a, behavior: 'smooth' }); }
function selecionarSlide(i) { const it = JOGOS[i]; if (!it) return; $('descTag').textContent = 'Jogo'; $('descTitulo').textContent = it.titulo; $('descTexto').textContent = it.texto; const lk = $('descLink'); if (lk) lk.href = it.link; $('slideDesc').hidden = false; const kids = $('trilho').children; for (let n = 0; n < kids.length; n++) kids[n].classList.toggle('ativo', n === i); irSlide(i); }
function renderJogos() {
    const grid = $('jogo-grid'); if (!grid) return;
    grid.innerHTML = '';
    const frag = document.createDocumentFragment();
    JOGOS.forEach(j => {
        const div = document.createElement('article');
        div.className = 'jogo-card vidro cartao-animado';
        div.innerHTML = '<img class="jogo-img" src="' + j.img + '" alt="Capa de ' + j.titulo + '" loading="lazy" onerror="this.src=\'imagens/logo.png\'"><span class="jogo-sub">' + j.sub + '</span><h3>' + j.titulo + '</h3><p>' + j.texto + '</p><div class="jogo-botoes"><a class="btn-liquido ' + j.btn + '" href="' + j.link + '" target="_blank" rel="noopener"><span><i class="fas fa-arrow-up-right-from-square" aria-hidden="true"></i> ' + (TRADUCOES[idiomaAtual]['jogos.site']) + '</span></a></div>';
        frag.appendChild(div);
    });
    grid.appendChild(frag);
}
function renderLojas() {
    const grid = $('loja-grid'); if (!grid) return;
    grid.innerHTML = '';
    const frag = document.createDocumentFragment();
    LOJAS.forEach(l => {
        const div = document.createElement('article');
        div.className = 'loja-card vidro cartao-animado';
        div.innerHTML = '<img src="' + l.img + '" alt="Logo ' + l.nome + '" loading="lazy" onerror="this.src=\'imagens/logo.png\'"><strong>' + l.nome + '</strong><small>' + l.desc + '</small><a class="btn-liquido ' + l.btn + '" href="' + l.link + '" target="_blank" rel="noopener"><span><i class="fas fa-store" aria-hidden="true"></i> Abrir</span></a>';
        frag.appendChild(div);
    });
    grid.appendChild(frag);
}

function configurarAvaliacao() {
    const ROSTOS = {
        0:{ cor:'#34343d', txt:'—', f:'<circle cx="36" cy="46" r="3.6" fill="#8a8a99" stroke="none"/><circle cx="64" cy="46" r="3.6" fill="#8a8a99" stroke="none"/><path d="M39 67h22" stroke="#8a8a99"/>' },
        1:{ cor:'#ff5c5c', txt:'1 estrela', f:'<path d="M27 33l17 8M73 33L56 41"/><circle cx="37" cy="48" r="3.6" fill="#3b2f2f" stroke="none"/><circle cx="63" cy="48" r="3.6" fill="#3b2f2f" stroke="none"/><path d="M35 72q15-14 30 0"/>' },
        2:{ cor:'#ff8a4c', txt:'2 estrelas', f:'<path d="M28 36l15 6M72 36L57 42"/><circle cx="37" cy="48" r="3.6" fill="#3b2f2f" stroke="none"/><circle cx="63" cy="48" r="3.6" fill="#3b2f2f" stroke="none"/><path d="M38 69q12-8 24 0"/>' },
        3:{ cor:'#d9cba0', txt:'3 estrelas', f:'<circle cx="36" cy="46" r="3.6" fill="#3b2f2f" stroke="none"/><circle cx="64" cy="46" r="3.6" fill="#3b2f2f" stroke="none"/><path d="M38 66h24"/>' },
        4:{ cor:'#9b5cff', txt:'4 estrelas', blush:1, f:'<circle cx="36" cy="44" r="3.8" fill="#2d1b4e" stroke="none"/><circle cx="64" cy="44" r="3.8" fill="#2d1b4e" stroke="none"/><path d="M34 58q16 18 32 0" stroke="#2d1b4e"/>' },
        5:{ cor:'#00c3ff', txt:'5 estrelas', blush:1, f:'<path d="M28 47q8-11 16 0M56 47q8-11 16 0"/><path d="M31 58q19 26 38 0z" fill="#003a52" stroke="#003a52" stroke-linejoin="round"/><path d="M42 68q8 7 16 0" fill="#5fdcff" stroke="none"/>' }
    };
    const ESTRELA = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.2l2.9 6.1 6.7.8-4.9 4.6 1.3 6.6L12 17l-6 3.3 1.3-6.6L2.4 9.1l6.7-.8z" stroke-linejoin="round"/></svg>';
    const rosto = $('rosto'), feicoes = $('feicoes'), blush = $('blush'), rotulo = $('rotulo');
    const grupo = $('estrelas'), enviar = $('enviar'), obrigado = $('obrigado'), campo = $('comentario'), painel = $('aval-wrap');
    if (!rosto || !grupo) return;
    let travada = 0; let estrelasHtml = '';
    for (let n = 1; n <= 5; n++) estrelasHtml += '<button type="button" data-nota="' + n + '" role="radio" aria-checked="false" aria-label="' + n + ' estrela' + (n > 1 ? 's' : '') + '">' + ESTRELA + '</button>';
    grupo.innerHTML = estrelasHtml;
    const btns = grupo.querySelectorAll('button');
    btns.forEach((b, idx) => {
        const n = idx + 1;
        b.addEventListener('mouseenter', () => mostrar(n));
        b.addEventListener('focus', () => mostrar(n));
        b.addEventListener('click', () => {
            travada = n;
            mostrar(n);
            btns.forEach((x, i) => x.setAttribute('aria-checked', i < n ? 'true' : 'false'));
            enviar.disabled = false;
        });
    });
    function mostrar(n) {
        const r = ROSTOS[n];
        rosto.style.setProperty('--cor', r.cor);
        painel.style.setProperty('--cor', r.cor);
        rotulo.textContent = r.txt;
        feicoes.innerHTML = r.f;
        blush.setAttribute('opacity', r.blush ? 1 : 0);
        btns.forEach((b, i) => { b.classList.toggle('on', i < n); });
    }
    enviar.addEventListener('click', () => {
        try { const lista = JSON.parse(localStorage.getItem('avaliacoesCommunityNews') || '[]'); lista.push({ nota:travada, comentario:campo.value.trim().slice(0,200), quando:new Date().toISOString() }); localStorage.setItem('avaliacoesCommunityNews', JSON.stringify(lista)); } catch (e) {}
        obrigado.hidden = false; enviar.disabled = true; campo.value = '';
        anunciar('Avaliação enviada. Obrigado!');
    });
    mostrar(0);
}

let fbTipo = 'sugestao';
document.querySelectorAll('#fb-tipos .fb-chip').forEach(c => c.addEventListener('click', () => {
    document.querySelectorAll('#fb-tipos .fb-chip').forEach(x => { x.classList.remove('ativo'); x.setAttribute('aria-checked', 'false'); });
    c.classList.add('ativo'); c.setAttribute('aria-checked', 'true');
    fbTipo = c.dataset.tipo;
}));
const ESTRELA_SVG = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.2l2.9 6.1 6.7.8-4.9 4.6 1.3 6.6L12 17l-6 3.3 1.3-6.6L2.4 9.1l6.7-.8z" stroke-linejoin="round"/></svg>';
const fbEstrelas = $('fb-estrelas');
let fbNota = 0;
if (fbEstrelas) {
    let html = ''; for (let n = 1; n <= 5; n++) html += '<button type="button" data-nota="' + n + '" role="radio" aria-checked="false" aria-label="' + n + ' estrela' + (n > 1 ? 's' : '') + '">' + ESTRELA_SVG + '</button>';
    fbEstrelas.innerHTML = html;
    const btns = fbEstrelas.querySelectorAll('button');
    function pintar(n) { btns.forEach((b, i) => b.classList.toggle('on', i < n)); }
    btns.forEach((b, i) => {
        const n = i + 1;
        b.addEventListener('mouseenter', () => pintar(n));
        b.addEventListener('focus', () => pintar(n));
        b.addEventListener('click', () => {
            fbNota = n;
            pintar(n);
            btns.forEach((x, j) => x.setAttribute('aria-checked', j < n ? 'true' : 'false'));
            atualizarBotaoFeedback();
        });
    });
    fbEstrelas.addEventListener('mouseleave', () => pintar(fbNota));
}
const fbTexto = $('fb-texto'), fbContador = $('fb-contador'), fbEnviar = $('fb-enviar');
function atualizarBotaoFeedback() { if (!fbTexto || !fbEnviar) return; const txt = fbTexto.value.trim(); fbEnviar.disabled = !(txt.length >= 5 && fbNota > 0); }
if (fbTexto) fbTexto.addEventListener('input', () => { fbContador.textContent = fbTexto.value.length; atualizarBotaoFeedback(); });
if (fbEnviar) {
    fbEnviar.addEventListener('click', () => {
        const txt = fbTexto.value.trim(); if (txt.length < 5) return; if (fbNota === 0) return;
        try { const lista = JSON.parse(localStorage.getItem('feedbacksCommunityNews') || '[]'); lista.push({ tipo:fbTipo, nota:fbNota, texto:txt, quando:new Date().toISOString() }); localStorage.setItem('feedbacksCommunityNews', JSON.stringify(lista)); } catch (e) {}
        $('fb-form-area').style.display = 'none'; $('fb-sucesso').classList.add('ativo');
        anunciar('Feedback enviado. Obrigado!');
        setTimeout(() => { fbTexto.value = ''; fbContador.textContent = '0'; fbNota = 0; if (fbEstrelas) fbEstrelas.querySelectorAll('button').forEach(b => b.classList.remove('on')); document.querySelectorAll('#fb-tipos .fb-chip').forEach((x, i) => { x.classList.toggle('ativo', i === 0); x.setAttribute('aria-checked', i === 0 ? 'true' : 'false'); }); fbTipo = 'sugestao'; atualizarBotaoFeedback(); }, 600);
    });
}
$('fb-fechar-sucesso')?.addEventListener('click', () => { $('fb-sucesso').classList.remove('ativo'); $('fb-form-area').style.display = ''; fecharModal('modal-feedback'); });

function configurarRolagem() {
    $('btn-topo')?.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
    $('btn-fim')?.addEventListener('click', () => window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' }));
}

let appIniciado = false;
function iniciarApp() {
    if (appIniciado) return;
    appIniciado = true;
    EL.telaCarr = $('tela-carregamento');
    EL.barraCarr = $('preenchimento');
    EL.textoCarr = $('texto-carregando');
    EL.snackbar = $('snackbar');
    EL.toast = $('toast');
    EL.a11yStatus = $('a11y-status');

    carregarTemaSalvo();
    configurarSyncTema();
    carregar();
    carregarSeg();
    carregarVip();

    carregarIdiomaSalvo();
    configurarIdiomas();

    iniciarContador();
    configurarNav();
    configurarSidebar();
    configurarTemas();
    configurarSheet();
    configurarModais();
    configurarPinModal();
    configurarSegurancaModal();
    configurarLock();
    configurarCriarGrupo();
    configurarCriarComunidade();
    configurarEntrarLink();
    configurarCriarContato();
    configurarPerfil();
    configurarSlide();
    configurarOnboarding();
    configurarVip();
    configurarApagarPerfil();
    renderJogos();
    renderLojas();
    configurarAvaliacao();
    configurarRolagem();
    ligarUploads();
    ligarAudio();
    ligarChamadas();
    configurarAutoLock();

    injetarEfeitosBrilho();

    atualizarListaContatos();
    atualizarSideGrupos();
    renderEmojis();
    atualizarPerfil();
    atualizarBoasVindas();
    atualizarUISeg();

    $('busca-conv')?.addEventListener('input', (e) => atualizarListaContatos(e.target.value));
    $('btn-enviar')?.addEventListener('click', enviarMensagem);
    $('input-msg')?.addEventListener('keypress', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); enviarMensagem(); } });
    $('input-msg')?.addEventListener('input', (e) => { e.target.style.height = 'auto'; e.target.style.height = Math.min(e.target.scrollHeight, 100) + 'px'; });
    $('btn-emoji')?.addEventListener('click', () => {
        const pan = $('emoji-pan');
        const aberto = pan?.classList.toggle('ativo');
        $('btn-emoji').setAttribute('aria-expanded', aberto ? 'true' : 'false');
    });
    $('voltar-conv')?.addEventListener('click', () => { $('chat-app')?.classList.remove('conv-aberta'); });
    $('novo-grupo')?.addEventListener('click', () => abrirModal('modal-grupo'));
    $('novo-contato')?.addEventListener('click', () => abrirModal('modal-contato'));
    $('fechar-lightbox')?.addEventListener('click', () => { $('lightbox')?.classList.remove('ativo'); });
    $('btn-feedback')?.addEventListener('click', () => abrirModal('modal-feedback'));
    $('btn-info')?.addEventListener('click', () => abrirModal('modal-info-app'));

    document.addEventListener('click', (e) => {
        const pan = $('emoji-pan'), btn = $('btn-emoji');
        if (pan && pan.classList.contains('ativo') && !pan.contains(e.target) && e.target !== btn) {
            pan.classList.remove('ativo');
            btn?.setAttribute('aria-expanded', 'false');
        }
    });

    window.abrirLightbox = (url) => {
        $('lightbox-img').src = url;
        $('lightbox').classList.add('ativo');
        setTimeout(() => $('fechar-lightbox')?.focus(), 100);
    };
    $('chat-msgs')?.addEventListener('click', (e) => {
        const img = e.target.closest('img[data-lb]');
        if (img) window.abrirLightbox(img.dataset.lb);
    });

    mostrarLoading(() => {
        if (!onboardingCompleto()) setTimeout(() => abrirOnboarding(), 250);
        else if (seg.pinHash && seg.pedirAoAbrir) setTimeout(() => mostrarLock(), 300);
    });
}

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', iniciarApp, { once: true });
else iniciarApp();

})();


})();
/* ================= TEMAS • UPGRADE (js) ================= */
;(function(){
  'use strict';
  var H=document.documentElement,APP=H.dataset.app,PG=H.dataset.pg,K='estilo_visual';
  var NAME={chat:'Community Chat',news:'Community News',registro:'Registro de Notas'}[APP]||document.title;
  var EVENT=new Date('2026-10-16T00:00:00').getTime(),EVT_LABEL='16 de outubro de 2026';
  var TILES=[['padrao','Padrão'],['claro','Claro'],['escuro','Escuro'],['retro90','Anos 90'],['cartoon','Cartoon 2D'],['d3','Modo 3D']];
  var SUB={padrao:APP==='chat'?'Segue o sistema':'Original',claro:'Luz',escuro:'Noite',retro90:'Pixel DOS',cartoon:'Desenho',d3:'Volume'};
  var DEF={padrao:['#00f2fe','#4facfe'],claro:['#0076ff','#00b4ff'],escuro:['#a78bfa','#60a5fa'],retro90:['#0000d0','#00ffff'],cartoon:['#ff4f79','#ffd23f'],d3:['#8a5cff','#00e5ff']};
  var APPVARS={chat:['--primaria','--primaria-rgb','--secundaria','--secundaria-rgb','--grad-led'],news:['--azul','--azul-claro','--cor-card'],registro:['--accent','--accent-ink']}[APP]||[];
  function lg(k){try{return localStorage.getItem(k)}catch(e){return null}}
  function sv(k,v){try{localStorage.setItem(k,v)}catch(e){}}
  function rm(k){try{localStorage.removeItem(k)}catch(e){}}
  /* ---- cor ---- */
  function hsl2hex(h,s,l){h=((h%360)+360)%360;s/=100;l/=100;var a=s*Math.min(l,1-l);function f(n){var k=(n+h/30)%12,c=l-a*Math.max(-1,Math.min(k-3,9-k,1));return Math.round(255*c).toString(16).padStart(2,'0')}return '#'+f(0)+f(8)+f(4)}
  function rgb(h){return parseInt(h.slice(1,3),16)+','+parseInt(h.slice(3,5),16)+','+parseInt(h.slice(5,7),16)}
  function lum(h){var v=rgb(h).split(',').map(function(x){x/=255;return x<=.03928?x/12.92:Math.pow((x+.055)/1.055,2.4)});return .2126*v[0]+.7152*v[1]+.0722*v[2]}
  function ink(h){return lum(h)>.32?'#111111':'#ffffff'}
  function hueOf(h){var r=parseInt(h.slice(1,3),16)/255,g=parseInt(h.slice(3,5),16)/255,b=parseInt(h.slice(5,7),16)/255,mx=Math.max(r,g,b),mn=Math.min(r,g,b),d=mx-mn,x=0;if(d){x=mx===r?((g-b)/d)%6:mx===g?(b-r)/d+2:(r-g)/d+4;x*=60;if(x<0)x+=360}return x}
  function pal(m){
    var t=lg('te_t_'+m);if(t===null||t==='')return{c:DEF[m],custom:false};
    t=Math.max(0,Math.min(100,+t||0));var h=t*3.6,a,b;
    if(m==='retro90'){var hh=190+t*.6;a=hsl2hex(hh,100,34);b=hsl2hex(180+(hh-190)*.25,100,58)}
    else if(m==='claro'){a=hsl2hex(h,85,42);b=hsl2hex(h+45,90,50)}
    else if(m==='cartoon'){a=hsl2hex(h,100,58);b=hsl2hex(h+55,100,62)}
    else if(m==='d3'){a=hsl2hex(h,85,58);b=hsl2hex(h+50,100,62)}
    else{a=hsl2hex(h,85,56);b=hsl2hex(h+45,95,62)}
    return{c:[a,b],custom:true};
  }
  function tOf(m){var t=lg('te_t_'+m);if(t!==null&&t!=='')return +t;var hu=hueOf(DEF[m][0]);return m==='retro90'?Math.max(0,Math.min(100,(hu-190)/.6)):hu/3.6}
  function track(m){return m==='retro90'?'linear-gradient(90deg,'+hsl2hex(190,100,34)+','+hsl2hex(250,100,34)+')':'linear-gradient(90deg,'+[0,60,120,180,240,300,360].map(function(h){return hsl2hex(h,85,55)}).join(',')+')'}
  /* ---- estado ---- */
  function sysEscuro(){return !!(window.matchMedia&&matchMedia('(prefers-color-scheme: dark)').matches)}
  function estilo(){var e=lg(K);return /^(retro90|cartoon|d3)$/.test(e)?e:'padrao'}
  function base(){
    if(APP==='chat')return lg('cc_auto')==='1'?'padrao':(H.getAttribute('data-tema')==='claro'?'claro':'escuro');
    if(APP==='news'){var t=H.getAttribute('data-tema');return /^(claro|escuro)$/.test(t)?t:'padrao'}
    var r=lg('reg_tema');return /^(claro|escuro)$/.test(r)?r:'padrao';
  }
  function modo(){var e=estilo();return e!=='padrao'?e:base()}
  function setBase(id){
    if(APP==='registro'){sv('reg_tema',id);if(id==='padrao')H.removeAttribute('data-tema');else H.setAttribute('data-tema',id);return}
    var alvo=id;
    if(APP==='chat'){sv('cc_auto',id==='padrao'?'1':'0');alvo=id==='padrao'?(sysEscuro()?'escuro':'claro'):id}
    var b=document.querySelector('.tema-btn[data-tema="'+alvo+'"]');
    if(b){b.click()}else{H.setAttribute('data-tema',alvo);sv(APP==='chat'?'cc_tema':'tema',APP==='news'?'modo-'+alvo:alvo)}
  }
  function pintar(){
    var m=modo(),p=pal(m),c=p.c,tg=[H,document.body],b3=/^(padrao|claro|escuro)$/.test(m);
    H.dataset.modo=m;
    H.style.setProperty('--te-a',c[0]);H.style.setProperty('--te-b',c[1]);H.style.setProperty('--te-a-rgb',rgb(c[0]));H.style.setProperty('--te-b-rgb',rgb(c[1]));
    H.style.setProperty('--te-a-ink',ink(c[0]));H.style.setProperty('--te-b-ink',ink(c[1]));
    tg.forEach(function(el){APPVARS.forEach(function(v){el.style.removeProperty(v)})});
    if(p.custom&&b3){H.setAttribute('data-custom','1');tg.forEach(function(el){
      if(APP==='chat'){el.style.setProperty('--primaria',c[0]);el.style.setProperty('--primaria-rgb',rgb(c[0]));el.style.setProperty('--secundaria',c[1]);el.style.setProperty('--secundaria-rgb',rgb(c[1]));el.style.setProperty('--grad-led','linear-gradient(135deg,'+c[0]+','+c[1]+')')}
      else if(APP==='news'){el.style.setProperty('--azul',c[0]);el.style.setProperty('--azul-claro',c[1]);el.style.setProperty('--cor-card',c[0])}
      else{el.style.setProperty('--accent',c[0]);el.style.setProperty('--accent-ink',ink(c[0]))}
    })}else H.removeAttribute('data-custom');
    marcar();
  }
  function aplicar(id){
    if(/^(retro90|cartoon|d3)$/.test(id))sv(K,id);else{sv(K,'padrao');setBase(id)}
    H.setAttribute('data-estilo',estilo());pintar();
  }
  function trocar(id,x,y){
    if(!document.startViewTransition||(window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches)){aplicar(id);return}
    H.style.setProperty('--tx',x+'px');H.style.setProperty('--ty',y+'px');H.classList.add('te-reveal');
    var t=document.startViewTransition(function(){aplicar(id)}),fim=function(){H.classList.remove('te-reveal')};
    (t.finished||Promise.resolve()).then(fim,fim);
  }
  /* ---- seletor ---- */
  var cards=[];
  function montarCard(){
    var card=document.createElement('div');card.className='te-card';
    var h='<h3>🎨 Temas e estilos</h3><p>Escolha o visual e arraste a barra para mudar a cor do tema. Fica salvo.</p><div class="te-grid">';
    TILES.forEach(function(t){h+='<button type="button" class="te-tile" data-e="'+t[0]+'"><div class="te-pv pv-'+t[0]+'"></div><div><strong>'+t[1]+'</strong><small>'+SUB[t[0]]+'</small></div></button>'});
    h+='</div><div class="te-hue"><span>🎚️ Cor</span><input type="range" min="0" max="100" step="1" aria-label="Cor do tema"><button type="button" class="te-reset" title="Voltar à cor original" aria-label="Cor original">↺</button></div>';
    if(APP!=='news')h+='<div class="te-count"><b>🎃 Evento de Halloween — '+EVT_LABEL+'</b><div class="te-cd"></div></div>';
    card.innerHTML=h;
    card.querySelectorAll('.te-tile').forEach(function(b){b.onclick=function(e){var r=b.getBoundingClientRect();trocar(b.dataset.e,e.clientX||r.left+r.width/2,e.clientY||r.top+r.height/2)}});
    var rg=card.querySelector('input[type=range]');
    rg.oninput=function(){sv('te_t_'+modo(),rg.value);pintar()};
    card.querySelector('.te-reset').onclick=function(){rm('te_t_'+modo());pintar()};
    cards.push(card);return card;
  }
  function marcar(){
    var m=modo();
    cards.forEach(function(c){
      c.querySelectorAll('.te-tile').forEach(function(b){b.classList.toggle('sel',b.dataset.e===m)});
      var rg=c.querySelector('input[type=range]');rg.style.setProperty('--te-track',track(m));if(document.activeElement!==rg)rg.value=Math.round(tOf(m));
    });
  }
  /* ---- contagem / aba flutuante ---- */
  var evt;
  function tick(){
    var d=EVENT-Date.now(),h='',rot;
    if(d<=0){h='<div class="te-cd-fim" style="grid-column:1/-1">🎃 O evento começou!</div>';rot='AGORA!';if(d<-864e5&&evt){evt.remove();evt=null}}
    else{var s=Math.floor(d/1000),dd=Math.floor(s/86400),hh=Math.floor(s%86400/3600),v=[dd,hh,Math.floor(s%3600/60),s%60],l=['Dias','Horas','Min','Seg'];
      v.forEach(function(n,i){h+='<div><strong>'+String(n).padStart(2,'0')+'</strong><small>'+l[i]+'</small></div>'});rot=dd+'d '+hh+'h'}
    document.querySelectorAll('.te-cd').forEach(function(el){el.innerHTML=h});
    var t=document.querySelector('#te-evt .ab-txt');if(t)t.textContent=rot;
  }
  function abaEvento(){
    evt=document.createElement('aside');evt.id='te-evt';evt.setAttribute('aria-label','Evento de Halloween');
    evt.innerHTML='<button type="button" class="evt-tab" aria-expanded="false" aria-label="Evento de Halloween"><span class="ab-ico">🎃</span><span class="ab-txt">…</span></button><div class="evt-panel" hidden><button type="button" class="evt-x" aria-label="Fechar">✕</button><strong>🎃 Evento de Halloween</strong><small>'+EVT_LABEL+'</small><div class="te-cd"></div></div>';
    document.body.appendChild(evt);
    var tab=evt.querySelector('.evt-tab'),pn=evt.querySelector('.evt-panel'),y0=null,top0=0,moved=false;
    var pos=parseFloat(lg('te_evt_top'));evt.style.top=(isNaN(pos)?38:Math.max(8,Math.min(82,pos)))+'%';
    function abrir(on){pn.hidden=!on;tab.setAttribute('aria-expanded',on);sv('te_evt_open',on?'1':'0')}
    abrir(lg('te_evt_open')==='1');
    tab.addEventListener('pointerdown',function(e){y0=e.clientY;top0=evt.getBoundingClientRect().top;moved=false;tab.setPointerCapture(e.pointerId)});
    tab.addEventListener('pointermove',function(e){if(y0===null)return;var dy=e.clientY-y0;if(Math.abs(dy)>6)moved=true;if(moved){var pc=Math.max(8,Math.min(82,(top0+dy)/innerHeight*100));evt.style.top=pc+'%'}});
    tab.addEventListener('pointerup',function(){if(y0===null)return;y0=null;if(moved)sv('te_evt_top',parseFloat(evt.style.top));else abrir(pn.hidden)});
    evt.querySelector('.evt-x').onclick=function(){abrir(false)};
  }
  /* ---- abertura com logo ---- */
  function splash(){
    var m=modo(),dur=m==='retro90'?3600:3000;
    var logo=APP==='news'?'<img src="imagens/comunnitynews.png" alt="">':'<span class="lg">'+(APP==='chat'?'💬':'📒')+'</span>';
    var s=document.createElement('div');s.id='te-splash';s.setAttribute('aria-hidden','true');s.style.setProperty('--sp-dur',dur+'ms');
    s.innerHTML='<div class="sp-box"><div class="sp-logo">'+logo+'</div><h2>'+NAME+'</h2><div class="sp-bar"><i></i></div><div class="sp-txt">'+(m==='retro90'?'Carregando programa':'Carregando')+'</div></div>';
    document.body.appendChild(s);
    setTimeout(function(){s.classList.add('out');setTimeout(function(){s.remove()},650)},dur+200);
  }
  function modalRegistro(){
    var md=document.createElement('div');md.id='te-modal';var c=montarCard();
    var x=document.createElement('button');x.className='te-x';x.type='button';x.textContent='✕';x.setAttribute('aria-label','Fechar');c.appendChild(x);md.appendChild(c);document.body.appendChild(md);
    function abrir(){md.classList.add('on')}function fechar(){md.classList.remove('on')}
    x.onclick=fechar;md.addEventListener('click',function(e){if(e.target===md)fechar()});document.addEventListener('keydown',function(e){if(e.key==='Escape')fechar()});
    var bt=document.createElement('button');bt.id='te-open';bt.type='button';bt.textContent='⚙️ Configurações';bt.onclick=abrir;
    var who=document.querySelector('.who');if(who)who.insertBefore(bt,who.querySelector('a,button')||null);else{bt.className='fixo';document.body.appendChild(bt)}
    var tb=document.createElement('div');tb.id='te-taskbar';tb.innerHTML='<button type="button">▣ Iniciar</button><span class="tab">'+document.title+'</span><span class="clock"></span>';
    tb.querySelector('button').onclick=abrir;document.body.appendChild(tb);
    var ck=tb.querySelector('.clock');function relogio(){var d=new Date();ck.textContent=String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0')}relogio();setInterval(relogio,15000);
  }
  function init(){
    H.setAttribute('data-estilo',estilo());
    if(APP==='registro'){var r=lg('reg_tema');if(/^(claro|escuro)$/.test(r))H.setAttribute('data-tema',r);modalRegistro()}
    else if(PG==='app'){
      var alvo=APP==='news'?document.querySelector('#aba-config .sec-config'):(document.querySelector('.temas')&&document.querySelector('.temas').closest('.linha'));
      if(alvo){var c=montarCard();if(APP==='news')alvo.insertBefore(c,alvo.firstChild);else alvo.insertAdjacentElement('afterend',c)}
    }
    abaEvento();pintar();tick();setInterval(tick,1000);splash();
    if(APP==='chat'&&PG==='app'){var a=function(){if(lg('cc_auto')==='1')setBase('padrao');pintar()};setTimeout(a,400);if(window.matchMedia)matchMedia('(prefers-color-scheme: dark)').addEventListener('change',a)}
    document.addEventListener('click',function(e){setTimeout(pintar,90);
      var a=e.target.closest&&e.target.closest('a[href]');
      if(a&&!e.defaultPrevented&&a.target!=='_blank'&&a.origin===location.origin&&/\.html$/i.test(a.pathname)&&a.pathname!==location.pathname&&!e.ctrlKey&&!e.metaKey){e.preventDefault();document.body.classList.add('te-leave');setTimeout(function(){location.href=a.href},190)}});
    document.addEventListener('keydown',function(e){if(e.altKey&&e.key.toLowerCase()==='t'){var m=modo(),i=(TILES.findIndex(function(t){return t[0]===m})+1)%TILES.length;trocar(TILES[i][0],innerWidth/2,innerHeight/2)}});
  }
  H.setAttribute('data-estilo',estilo());
  if(document.body)init();else document.addEventListener('DOMContentLoaded',init);
})();
