/* guia.js — Guia do app: botão "?", central de ajuda e tour passo a passo (spotlight).
   Os passos/tópicos desta tela ficam em DATA (gerados por app). Sem dependências. */
(function(){'use strict';
const D=document,H=D.documentElement,P=H.dataset.pg,K='gd_seen_'+H.dataset.app+'_'+P;
const DATA={"steps": {"login": [[".login-card", "Bem-vindo!", "Aqui você entra ou cria sua conta. Use as abas do cartão para alternar."], ["#btn-google-login", "Entrada rápida", "Modo local: informe só um nome para entrar sem cadastro."], [".acoes-flutuantes", "Feedback e informações", "Mande sugestões ou veja informações do app a qualquer momento."]], "app": [["#btn-hamburger", "Menu lateral", "Abre o menu com todas as áreas do app."], ["#nav-liquida", "Navegação rápida", "Troque entre Início, Jogos, Eventos, Chat e mais com um toque."], ["#conteudo-principal", "Conteúdo", "As notícias e recursos da aba escolhida aparecem aqui."], ["#btn-idioma-topo", "Idioma", "Troque entre português, inglês e espanhol na hora."], ["#btn-feedback", "Feedback", "Envie sua opinião para melhorar o app."]]}, "topics": [["Evento de Halloween","De 16/10 a 01/11 o app ganha o visual Halloween em todos os modos. Toque na pílula 🎃 no topo para ver o cronômetro de encerramento e personalizar paleta, efeitos e intensidade."],["Criar conta e entrar", "Na tela inicial escolha <b>Criar conta</b> (apelido, e-mail e senha) ou <b>Entrar</b>. A conta fica salva só neste aparelho. O botão do Google é o modo local: pede apenas um nome."], ["Navegar pelas abas", "Use a barra de navegação rápida e o menu lateral para ir entre Início, Jogos, Eventos, Chat, Perfil, VIP e Configurações."], ["Chat e comunidades", "Na aba Chat envie mensagens, emojis, imagens e arquivos, e use os botões de chamada de voz e vídeo."], ["Perfil e personalização", "Em Perfil edite foto, bio e links. Em Configurações troque idioma (PT, EN, ES) e tema, incluindo o de Halloween."], ["Backup e privacidade", "Em Configurações você pode apagar o perfil e restaurar pelo backup. Seus dados ficam no navegador: limpar o cache apaga tudo."], ["Enviar feedback", "O botão de balão no canto da tela abre o formulário de feedback; o botão de informação mostra detalhes do app."]], "title": "Guia do Community News", "lead": "Notícias de games, eventos, chat e comunidades num só lugar. Veja como usar cada parte.", "delay": 3200};
const steps=DATA.steps[P]||[];
const $=(t,c,h)=>{const n=D.createElement(t);if(c)n.className=c;if(h!=null)n.innerHTML=h;return n};
/* primeiro elemento visível que casa com o seletor */
const vis=s=>{if(!s)return null;for(const e of D.querySelectorAll(s)){const r=e.getBoundingClientRect();
  if(r.width>4&&r.height>4&&getComputedStyle(e).visibility!=='hidden')return e}return null};
let i=0,ov,spot,tip,panel,btn,nudge,last,seen=()=>{try{localStorage.setItem(K,'1')}catch(e){}};

function start(){closePanel();end();last=D.activeElement;if(nudge)nudge.remove();
  ov=$('div','gd-ov');spot=$('div','gd-spot');ov.append(spot);
  tip=$('div','gd-tip');tip.setAttribute('role','dialog');tip.setAttribute('aria-label','Tour do app');
  tip.addEventListener('click',e=>{const a=e.target.dataset.a;if(a==='x')end(true);else if(a==='b')go(-1);else if(a==='n')go(1)});
  D.body.append(ov,tip);i=0;show();
  addEventListener('resize',place);addEventListener('scroll',place,true);D.addEventListener('keydown',key)}
function key(e){if(!tip)return;if(e.key==='Escape')end(true);else if(e.key==='ArrowRight')go(1);else if(e.key==='ArrowLeft')go(-1)}
function go(d){i+=d;if(i>=steps.length)return end(true);if(i<0)i=0;show()}
function show(){const s=steps[i],t=vis(s[0]),n=steps.length;
  tip.innerHTML='<small>Passo '+(i+1)+' de '+n+'</small><h4>'+s[1]+'</h4><p>'+s[2]+
   (s[0]&&!t?'<br><em>Este item aparece em outra parte do app.</em>':'')+'</p>'+
   '<div class="gd-dots">'+steps.map((_,k)=>'<i'+(k===i?' class="on"':'')+'></i>').join('')+'</div>'+
   '<div class="gd-act"><button type="button" data-a="x">Pular</button><span></span>'+
   '<button type="button" data-a="b"'+(i?'':' disabled')+'>Voltar</button>'+
   '<button type="button" data-a="n" class="gd-main">'+(i===n-1?'Concluir':'Próximo')+'</button></div>';
  if(t)t.scrollIntoView({block:'center',behavior:'smooth'});
  place();setTimeout(place,380);tip.querySelector('.gd-main').focus({preventScroll:true})}
/* posiciona o destaque (anima por transition) e o cartão de texto sem sair da tela */
function place(){if(!tip||!steps[i])return;const t=vis(steps[i][0]),vw=innerWidth,vh=innerHeight,tw=tip.offsetWidth,th=tip.offsetHeight;
  let x=vw/2-tw/2,y=vh/2-th/2;
  if(t){const r=t.getBoundingClientRect(),p=8;
    Object.assign(spot.style,{top:r.top-p+'px',left:r.left-p+'px',width:r.width+p*2+'px',height:r.height+p*2+'px'});
    y=r.bottom+p+14+th<vh?r.bottom+p+14:Math.max(12,r.top-p-14-th);x=Math.min(Math.max(12,r.left),vw-tw-12)}
  else Object.assign(spot.style,{top:vh/2+'px',left:vw/2+'px',width:'0px',height:'0px'});
  tip.style.transform='translate('+Math.round(x)+'px,'+Math.round(y)+'px)'}
function end(done){if(!tip)return;ov.remove();tip.remove();ov=tip=null;
  removeEventListener('resize',place);removeEventListener('scroll',place,true);D.removeEventListener('keydown',key);
  if(done)seen();if(last&&last.focus)last.focus()}

/* Central de ajuda */
function openPanel(){if(panel)return;if(nudge)nudge.remove();last=D.activeElement;
  panel=$('div','gd-panel');panel.setAttribute('role','dialog');panel.setAttribute('aria-modal','true');panel.setAttribute('aria-label','Guia do app');
  panel.innerHTML='<div class="gd-card"><header><h3>'+DATA.title+'</h3><button type="button" class="gd-x" aria-label="Fechar guia">✕</button></header>'+
   '<p class="gd-lead">'+DATA.lead+'</p>'+(steps.length?'<button type="button" class="gd-main gd-go">▶ Iniciar tour desta tela</button>':'')+
   DATA.topics.map(t=>'<details><summary>'+t[0]+'</summary><p>'+t[1]+'</p></details>').join('')+'</div>';
  panel.addEventListener('click',e=>{if(e.target===panel||e.target.classList.contains('gd-x'))closePanel();else if(e.target.classList.contains('gd-go'))start()});
  panel.addEventListener('keydown',e=>{if(e.key==='Escape')closePanel()});
  D.body.append(panel);(panel.querySelector('.gd-go')||panel.querySelector('.gd-x')).focus()}
function closePanel(){if(!panel)return;panel.remove();panel=null;if(last&&last.focus)last.focus()}

function init(){
  btn=$('button','gd-btn','?');btn.type='button';btn.setAttribute('aria-label','Abrir guia do app');btn.title='Guia do app';
  btn.onclick=openPanel;D.body.append(btn);
  let s=null;try{s=localStorage.getItem(K)}catch(e){}
  if(!s&&steps.length)setTimeout(()=>{if(tip||panel)return;
    nudge=$('div','gd-nudge','<b>👋 Primeira vez aqui?</b><span>Faça um tour rápido de 1 minuto.</span><div><button type="button" class="gd-main">Ver tour</button><button type="button">Agora não</button></div>');
    nudge.setAttribute('role','status');const b=nudge.querySelectorAll('button');
    b[0].onclick=start;b[1].onclick=()=>{seen();nudge.remove()};D.body.append(nudge)},DATA.delay||2200)}
D.readyState==='loading'?D.addEventListener('DOMContentLoaded',init):init();
window.Guia={tour:start,ajuda:openPanel};
})();
