/* evento.js — Evento de Halloween (16/10 → 01/11/2026).
   Durante o evento: paleta Halloween em TODOS os modos (via CSS), pílula fixa com cronômetro de
   encerramento até 01/11, painel de personalização (paleta, efeitos, intensidade) e, no News,
   desbloqueio do tema Halloween nativo. Fora do período não faz nada e remove tudo ao terminar. */
(function(){'use strict';
const D=document,H=D.documentElement,K='ev_cfg';
const START=new Date('2026-10-16T00:00:00').getTime(),END=new Date('2026-11-01T00:00:00').getTime();
const PAL={abobora:['Abóbora','#ff7a18','#8b3dff'],bruxa:['Bruxa','#a855f7','#ff7a18'],
  fantasma:['Fantasma','#34d399','#7c3aed'],sangue:['Sangue','#ef4444','#fb923c']};
const DEF={pal:'abobora',fx:true,fog:true,glow:true,lvl:50};
let cfg=load(),on=false,pill,pop,fx,fog,spawn,last;
function load(){let c={};try{c=JSON.parse(localStorage.getItem(K))||{}}catch(e){}
  c=Object.assign({},DEF,c);if(!PAL[c.pal])c.pal=DEF.pal;return c}
const save=()=>{try{localStorage.setItem(K,JSON.stringify(cfg))}catch(e){}};
const rgb=h=>parseInt(h.slice(1,3),16)+','+parseInt(h.slice(3,5),16)+','+parseInt(h.slice(5,7),16);
const el=(t,c,h)=>{const n=D.createElement(t);if(c)n.className=c;if(h!=null)n.innerHTML=h;return n};
const pad=n=>String(n).padStart(2,'0');
const LAB=['Dias','Horas','Min','Seg'];
const blocks=(cls,vcls)=>LAB.map((l,i)=>'<div class="'+cls+'"><div class="'+vcls+'" data-ev-n="'+i+'">00</div><small>'+l+'</small></div>').join('');

/* paleta + efeitos conforme a personalização */
function paint(){const p=PAL[cfg.pal],s=H.style;
  s.setProperty('--ev-a',p[1]);s.setProperty('--ev-a-rgb',rgb(p[1]));s.setProperty('--ev-b',p[2]);s.setProperty('--ev-b-rgb',rgb(p[2]));
  s.setProperty('--ev-lvl',cfg.lvl/100);H.toggleAttribute('data-ev-glow',cfg.glow);
  if(fog)fog.hidden=!cfg.fog;clearInterval(spawn);
  if(fx&&cfg.fx&&!matchMedia('(prefers-reduced-motion:reduce)').matches)spawn=setInterval(drop,2800-cfg.lvl*24);
  if(pop)pop.querySelectorAll('[data-pal]').forEach(b=>b.setAttribute('aria-checked',b.dataset.pal===cfg.pal))}
function drop(){if(D.hidden||fx.childElementCount>16)return;
  const e=el('span','ev-b',['🦇','🎃','👻','🕸️'][Math.random()*4|0]);
  e.style.cssText='left:'+(Math.random()*100)+'%;font-size:'+(14+Math.random()*14)+'px;--dx:'+(Math.random()*120-60)+'px;animation-duration:'+(9+Math.random()*7)+'s';
  e.onanimationend=()=>e.remove();fx.append(e)}

/* cronômetro de encerramento (1x por segundo) */
function tick(){const n=Date.now(),a=n>=START&&n<END;if(a!==on)(a?enable:disable)();if(!on)return;
  const s=Math.max(0,Math.floor((END-n)/1000)),t=[Math.floor(s/86400),Math.floor(s%86400/3600),Math.floor(s%3600/60),s%60];
  const txt=(t[0]?t[0]+'d ':'')+pad(t[1])+':'+pad(t[2])+':'+pad(t[3]);
  D.querySelectorAll('[data-ev-t]').forEach(x=>x.textContent=txt);
  D.querySelectorAll('[data-ev-n]').forEach(x=>x.textContent=pad(t[+x.dataset.evN]));
  const pr=Math.min(100,(n-START)/(END-START)*100).toFixed(2)+'%';
  D.querySelectorAll('[data-ev-p]').forEach(x=>x.style.width=pr)}

function enable(){on=true;H.dataset.evento='halloween';
  fx=el('div','ev-fx');fx.setAttribute('aria-hidden','true');fog=el('div','ev-fog');fog.setAttribute('aria-hidden','true');
  pill=el('button','ev-pill','🎃 <b>Halloween</b> <span data-ev-t>--</span>');pill.type='button';
  pill.setAttribute('aria-expanded','false');pill.setAttribute('aria-label','Evento de Halloween: ver cronômetro e personalizar');
  pill.onclick=()=>pop.hidden?openPop():closePop();
  pop=el('div','ev-pop');pop.hidden=true;pop.setAttribute('role','dialog');pop.setAttribute('aria-label','Evento de Halloween');
  pop.innerHTML='<h3>🎃 Evento de Halloween</h3><p>De 16/10 a 01/11. O evento fica fixo até o fim.</p><p class="ev-l">Encerra em</p>'+
   '<div class="ev-cd">'+blocks('ev-bl','ev-v')+'</div><div class="ev-bar" role="presentation"><i data-ev-p></i></div>'+
   '<h4>Personalizar</h4><div class="ev-pals" role="radiogroup" aria-label="Paleta de cores">'+
   Object.keys(PAL).map(k=>'<button type="button" role="radio" data-pal="'+k+'" aria-checked="false"><i style="background:linear-gradient(135deg,'+PAL[k][1]+','+PAL[k][2]+')"></i>'+PAL[k][0]+'</button>').join('')+'</div>'+
   '<label class="ev-chk"><input type="checkbox" data-k="fx"> Morcegos e abóboras caindo</label>'+
   '<label class="ev-chk"><input type="checkbox" data-k="fog"> Névoa</label>'+
   '<label class="ev-chk"><input type="checkbox" data-k="glow"> Brilho nos cartões</label>'+
   '<label class="ev-rg">Intensidade dos efeitos<input type="range" min="0" max="100" data-k="lvl" aria-label="Intensidade dos efeitos"></label>'+
   '<div class="ev-row"><button type="button" data-reset>Restaurar padrão</button><button type="button" data-close class="ev-main">Fechar</button></div>';
  pop.querySelectorAll('[data-k]').forEach(i=>{const k=i.dataset.k;if(i.type==='checkbox')i.checked=cfg[k];else i.value=cfg[k]});
  pop.addEventListener('input',e=>{const k=e.target.dataset.k;if(!k)return;cfg[k]=e.target.type==='checkbox'?e.target.checked:+e.target.value;save();paint()});
  pop.addEventListener('click',e=>{const t=e.target.closest('button');if(!t)return;
    if(t.dataset.pal){cfg.pal=t.dataset.pal;save();paint()}
    else if('close' in t.dataset)closePop();
    else if('reset' in t.dataset){cfg=Object.assign({},DEF);save();pop.querySelectorAll('[data-k]').forEach(i=>{const k=i.dataset.k;if(i.type==='checkbox')i.checked=cfg[k];else i.value=cfg[k]});paint()}});
  pop.addEventListener('keydown',e=>{if(e.key==='Escape')closePop()});
  D.body.append(fx,fog,pill,pop);
  /* News: troca a contagem antiga da Home pelo cronômetro de encerramento */
  D.querySelectorAll('.caixa-contador').forEach(c=>c.append(Object.assign(el('div','ev-home',
    '<h3>🎃 Halloween 2026 — encerra em</h3><div class="contador-evento" role="timer">'+blocks('bloco-tempo','valor-tempo')+'</div><p class="ev-sub">De 16/10 a 01/11. Aproveite!</p>'))));
  /* News: libera o tema Halloween nativo e o aplica na primeira vez */
  D.querySelectorAll('.tema-btn[data-tema="halloween"]').forEach(b=>{b.disabled=false;b.removeAttribute('aria-disabled');
    b.classList.remove('tema-bloqueado');b.querySelectorAll('.lock-ico').forEach(i=>i.remove());
    let done=null;try{done=localStorage.getItem('ev_auto')}catch(e){}
    if(!done&&b.offsetParent!==null||!done&&D.querySelector('#aba-config')){try{localStorage.setItem('ev_auto','1')}catch(e){}setTimeout(()=>b.click(),700)}});
  paint();tick()}
function disable(){on=false;delete H.dataset.evento;H.removeAttribute('data-ev-glow');clearInterval(spawn);
  [fx,fog,pill,pop].forEach(n=>n&&n.remove());D.querySelectorAll('.ev-home').forEach(n=>n.remove());
  ['--ev-a','--ev-a-rgb','--ev-b','--ev-b-rgb','--ev-lvl'].forEach(v=>H.style.removeProperty(v))}
function openPop(){last=D.activeElement;pop.hidden=false;pill.setAttribute('aria-expanded','true');pop.querySelector('[data-pal]').focus()}
function closePop(){pop.hidden=true;pill.setAttribute('aria-expanded','false');pill.focus()}

function init(){tick();setInterval(tick,1000)}
D.readyState==='loading'?D.addEventListener('DOMContentLoaded',init):init();
})();
